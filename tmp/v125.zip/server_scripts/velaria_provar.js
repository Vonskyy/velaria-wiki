// ============================================================
//  Velária MMORPG — /provar: pegar qualquer armadura ou arma para TESTE (só operadores)
//  Pasta: kubejs/server_scripts/  (recarrega com /reload)
//
//  /provar modo                 liga/desliga o modo teste: o Juramento não derruba itens de outra
//                               Ordem e as travas de tier das armaduras não valem (só para você)
//  /provar conjunto <id>        as 4 peças de um conjunto (ex.: vacuita_elemental, estanho_pesada)
//  /provar ordem <ordem>        os 10 conjuntos da Ordem (2 linhas x 5 tiers) + armas/focos
//  /provar tier <1-5>           a linha Guardiã e a de Ataque de todas as Ordens nesse tier
//  /provar lista <ordem>        mostra os ids dos conjuntos da Ordem (clique para pegar)
//  /provar vestir <id>          veste o conjunto direto no corpo
//  /provar virar <ordem>        troca sua Ordem de verdade: stage + origem do Juramento + árvore de habilidades
//  /provar pontos <n>           dá n pontos na árvore de habilidades da sua Ordem
//                               (a origem tem trava própria de equipar que o modo teste não desliga)
// ============================================================

const VPV = {
  pecas: ['helmet', 'chestplate', 'leggings', 'boots'],
  conjuntos: () => global.VELARIA_ARMADURAS || [],
  armas: () => global.VELARIA_ARMAS_ORDEM || []
}

function vpvDar(p, id) { p.give(Item.of(id)) }
function vpvConjunto(p, a) { VPV.pecas.forEach(s => vpvDar(p, `kubejs:${a.id}_${s}`)) }
function vpvLinha(a) { return a.estilo === 'b' ? `Ataque · ${a.linha}` : 'Guardiã' }

ServerEvents.commandRegistry(event => {
  let { commands: Commands, arguments: Arguments } = event
  let txt = (ctx, n) => Arguments.STRING.getResult(ctx, n)

  event.register(Commands.literal('provar')
    .requires(s => s.hasPermission(2))
    .then(Commands.literal('modo').executes(ctx => {
      let p = ctx.source.player
      if (p.stages.has('velaria_teste')) {
        p.stages.remove('velaria_teste')
        p.tell(Text.yellow('Modo teste DESLIGADO: Juramento e travas de tier valem de novo.'))
      } else {
        p.stages.add('velaria_teste')
        p.tell(Text.green('Modo teste LIGADO: você pode vestir e segurar equipamento de qualquer Ordem e tier.'))
        p.tell(Text.gray('Para lançar magia do Iron\'s sem ser Mago, use o modo criativo.'))
      }
      return 1
    }))
    .then(Commands.literal('conjunto').then(Commands.argument('id', Arguments.STRING.create(event)).executes(ctx => {
      let p = ctx.source.player
      let id = txt(ctx, 'id')
      let a = VPV.conjuntos().find(x => x.id === id)
      if (!a) { p.tell(Text.red(`Conjunto "${id}" não existe. Use /provar lista <ordem>.`)); return 0 }
      vpvConjunto(p, a)
      p.tell(Text.green(`${a.nome} T${a.tier} (${vpvLinha(a)}): 4 peças entregues.`))
      return 1
    })))
    .then(Commands.literal('ordem').then(Commands.argument('ordem', Arguments.STRING.create(event)).executes(ctx => {
      let p = ctx.source.player
      let o = txt(ctx, 'ordem')
      let lista = VPV.conjuntos().filter(x => x.ordem === o)
      if (lista.length === 0) { p.tell(Text.red('Ordem inválida. Ex.: guerreiro, paladino, berserker, ladino, arqueiro, bruxo, monge, lamina_arcana, sacerdote, mago, druida')); return 0 }
      lista.forEach(a => vpvConjunto(p, a))
      VPV.armas().filter(a => a.ordem === o).forEach(a => vpvDar(p, `kubejs:${a.id}`))
      p.tell(Text.green(`${lista.length} conjuntos e as armas da Ordem entregues (o que não coube caiu no chão).`))
      return 1
    })))
    .then(Commands.literal('tier').then(Commands.argument('tier', Arguments.INTEGER.create(event)).executes(ctx => {
      let p = ctx.source.player
      let t = Arguments.INTEGER.getResult(ctx, 'tier')
      let lista = VPV.conjuntos().filter(x => x.tier === t)
      lista.forEach(a => vpvConjunto(p, a))
      p.tell(Text.green(`${lista.length} conjuntos de tier ${t} entregues (o que não coube caiu no chão).`))
      return 1
    })))
    .then(Commands.literal('vestir').then(Commands.argument('id', Arguments.STRING.create(event)).executes(ctx => {
      let p = ctx.source.player
      let a = VPV.conjuntos().find(x => x.id === txt(ctx, 'id'))
      if (!a) { p.tell(Text.red('Conjunto não encontrado. Use /provar lista <ordem>.')); return 0 }
      let slots = { helmet: 'head', chestplate: 'chest', leggings: 'legs', boots: 'feet' }
      VPV.pecas.forEach(s => p.server.runCommandSilent(`item replace entity ${p.username} armor.${slots[s]} with kubejs:${a.id}_${s}`))
      p.tell(Text.green(`${a.nome} T${a.tier} (${vpvLinha(a)}) vestido. Se sumir do corpo, use /provar virar ${a.ordem}.`))
      return 1
    })))
    .then(Commands.literal('virar').then(Commands.argument('ordem', Arguments.STRING.create(event)).executes(ctx => {
      let p = ctx.source.player
      let o = txt(ctx, 'ordem')
      if (!VPV.conjuntos().some(x => x.ordem === o)) { p.tell(Text.red('Ordem inválida.')); return 0 }
      ;['guerreiro','paladino','sacerdote','mago','ladino','arqueiro','berserker','bruxo','druida','monge','lamina_arcana'].forEach(x => p.stages.remove(`velaria_ordem_${x}`))
      p.stages.add(`velaria_ordem_${o}`)
      p.server.runCommandSilent(`origin set ${p.username} velaria:ordem velaria:ordem_${o}`)
      p.server.runCommandSilent(`origin set ${p.username} velaria:graca velaria:graca_nenhuma`)
      if (VG.velariaArvoreDaOrdem) VG.velariaArvoreDaOrdem(p, o)
      p.tell(Text.green(`Agora você é da Ordem ${o} (stage e origem). Escolha a Graça de novo se quiser.`))
      return 1
    })))
    .then(Commands.literal('pontos').then(Commands.argument('n', Arguments.INTEGER.create(event)).executes(ctx => {
      let p = ctx.source.player
      let o = VG.velariaOrdem ? VG.velariaOrdem(p) : null
      if (!o) { p.tell(Text.red('Você não tem Ordem. Use /provar virar <ordem>.')); return 0 }
      let n = Arguments.INTEGER.getResult(ctx, 'n')
      p.server.runCommandSilent(`puffish_skills points add ${p.username} velaria:ordem_${o} ${n}`)
      p.tell(Text.green(`${n} ponto(s) na árvore da sua Ordem. Abra com K.`))
      return 1
    })))
    .then(Commands.literal('lista').then(Commands.argument('ordem', Arguments.STRING.create(event)).executes(ctx => {
      let p = ctx.source.player
      let o = txt(ctx, 'ordem')
      let lista = VPV.conjuntos().filter(x => x.ordem === o)
      if (lista.length === 0) { p.tell(Text.red('Ordem inválida.')); return 0 }
      lista.sort((a, b) => a.tier - b.tier || (a.estilo < b.estilo ? -1 : 1)).forEach(a =>
        p.tell(Text.of(`T${a.tier} ${a.id}`).aqua().clickRunCommand(`/provar conjunto ${a.id}`)
          .hover(`Clique para pegar · ${vpvLinha(a)}`).append(Text.gray(` · ${vpvLinha(a)}`))))
      return 1
    })))
  )
})
