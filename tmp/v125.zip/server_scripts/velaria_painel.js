// ============================================================
//  Velária MMORPG — PAINEL DE ADMIN (/painel)
//  Uma tela de baú no lugar dos comandos de teste: Ordem, Graça, Linhagem, Ofício, tier,
//  pontos da árvore, armaduras e atalhos do mundo. Só para op (nível 2).
//  Usa as mesmas funções dos comandos (/provar, /origin, /velaria, /puffish_skills).
// ============================================================

const VPN = {
  ordens: ['guerreiro', 'paladino', 'sacerdote', 'mago', 'ladino', 'arqueiro', 'berserker', 'bruxo', 'druida', 'monge', 'lamina_arcana'],
  gracas: ['espada', 'katana', 'espada_longa', 'adaga', 'lanca', 'martelo', 'machado', 'foice', 'manopla', 'arco', 'besta',
    'cajado_arcano', 'cajado_sagrado', 'natureza', 'sinais', 'nenhuma'],
  linhagens: ['humano', 'anao', 'elfo', 'draconato', 'tritao', 'gigante', 'pequenino', 'vampiro', 'orc', 'feerico', 'forjado', 'salamandrino', 'drow'],
  oficios: ['minerador', 'lenhador', 'ferreiro', 'cozinheiro', 'mercador', 'fazendeiro', 'herbalista', 'criador', 'pescador', 'pedreiro', 'explorador', 'domador', 'errante'],
  bonito: s => s.split('_').map(x => x.charAt(0).toUpperCase() + x.slice(1)).join(' ')
}

function vpnFechar(p) { try { p.closeMenu() } catch (e) { try { p.doCloseContainer() } catch (e2) { try { p.server.runCommandSilent(`execute as ${p.username} run kubejs dummy`) } catch (e3) { } } } }
// p = quem está com o painel aberto (admin), a = jogador sendo gerenciado
function vpnCmd(a, c) { a.server.runCommandSilent(c.replace(/@p/g, a.username)) }
function vpnAbrir(p, f) { vpnFechar(p); p.server.scheduleInTicks(1, () => f(p)) }
function vpnAlvo(p) {
  let n = String(p.persistentData.getString('velaria_painel_alvo') || '')
  let a = null
  if (n) p.server.players.forEach(j => { if (String(j.username) === n) a = j })
  return a || p
}
function vpnBotao(gui, x, y, item, nome, cor, lore, acao) {
  let s = gui.getSlot(x, y)
  s.setItem(vmItem(item, nome, cor, lore || []))
  if (acao) s.setLeftClicked(acao)
}
function vpnVoltar(gui, p, y) { vpnBotao(gui, 0, y, 'minecraft:arrow', 'Voltar', 'yellow', [], () => vpnAbrir(p, vpnPrincipal)) }

// lista de jogadores online: escolha quem gerenciar
function vpnJogadores(p) {
  let lista = p.server.players.toArray().slice(0, 27)
  p.openChestGUI(Text.gold('Gerenciar jogador'), 4, gui => {
    lista.forEach((j, k) => {
      let i = vmInfo(j)
      let ord = i.ordem && i.VO ? i.VO.ordens[i.ordem].nome : 'sem Ordem'
      let s = gui.getSlot(k % 9, Math.floor(k / 9))
      s.setItem(vmCabeca(j.username, j.username, 'yellow', [[`${ord} · Tier ${i.tier}`, 'white'], [i.linhagem, 'gray'], ['Clique para gerenciar', 'green']]))
      s.setLeftClicked(() => { p.persistentData.putString('velaria_painel_alvo', j.username); vpnAbrir(p, vpnPrincipal) })
    })
    vpnVoltar(gui, p, 3)
  })
}

// lista genérica: até 27 opções em 3 linhas, clique aplica e volta ao painel
function vpnLista(p, titulo, ids, icone, nomeDe, aplicar, atual) {
  p.openChestGUI(Text.gold(titulo), 4, gui => {
    ids.forEach((id, k) => {
      let escolhido = id === atual
      vpnBotao(gui, k % 9, Math.floor(k / 9), escolhido ? 'minecraft:lime_dye' : icone(id), nomeDe(id), escolhido ? 'green' : 'white',
        [[escolhido ? 'Atual' : 'Clique para aplicar', escolhido ? 'green' : 'gray']],
        () => { aplicar(id); vpnAbrir(p, vpnPrincipal) })
    })
    vpnVoltar(gui, p, 3)
  })
}

function vpnPrincipal(p) {
  try { vpnPrincipal0(p) } catch (e) { p.tell(Text.red(`Painel: ${e}`)); console.error(`[Velária] painel: ${e}`) }
}
function vpnPrincipal0(p) {
  let a = vpnAlvo(p)
  let i = vmInfo(a)
  let VO = i.VO
  p.openChestGUI(Text.gold(`Painel · ${a.username}`), 5, gui => {
    // linha 0: identidade
    vpnBotao(gui, 1, 0, 'minecraft:shield', `Ordem: ${i.ordem && VO ? VO.ordens[i.ordem].nome : 'nenhuma'}`, 'gold',
      [['Troca Ordem, origem do Juramento e árvore', 'gray']],
      () => vpnAbrir(p, q => vpnLista(q, 'Escolha a Ordem', VPN.ordens, o => VO && VO.ordens[o] ? VO.ordens[o].icone : 'minecraft:iron_sword',
        o => VO && VO.ordens[o] ? VO.ordens[o].nome : VPN.bonito(o),
        o => vpnCmd(a, `execute as @p run provar virar ${o}`), i.ordem)))
    vpnBotao(gui, 3, 0, 'minecraft:nether_star', `Graça: ${i.graca && VO ? VO.caminhos[i.graca].deus : 'nenhuma'}`, 'aqua',
      [['Bênção do deus da arma', 'gray']],
      () => vpnAbrir(p, q => vpnLista(q, 'Escolha a Graça', VPN.gracas, g => g === 'nenhuma' ? 'minecraft:glass_bottle' : 'minecraft:nether_star',
        g => VO && VO.caminhos[g] ? `${VO.caminhos[g].nome} (${VO.caminhos[g].deus})` : VPN.bonito(g),
        g => vpnCmd(a, `origin set @p velaria:graca velaria:graca_${g}`), i.graca)))
    vpnBotao(gui, 5, 0, 'minecraft:name_tag', 'Linhagem', 'yellow', [[i.linhagem, 'white']],
      () => vpnAbrir(p, q => vpnLista(q, 'Escolha a Linhagem', VPN.linhagens, () => 'minecraft:name_tag', l => VM.linhagens[`linhagem_${l}`] || VPN.bonito(l),
        l => vpnCmd(a, `origin set @p neoorigins:origin velaria:linhagem_${l}`), null)))
    vpnBotao(gui, 7, 0, 'minecraft:iron_pickaxe', 'Ofício', 'yellow', [[i.oficio, 'white']],
      () => vpnAbrir(p, q => vpnLista(q, 'Escolha o Ofício', VPN.oficios, () => 'minecraft:iron_pickaxe', o => VPN.bonito(o),
        o => vpnCmd(a, `origin set @p neoorigins:class velaria:oficio_${o}`), null)))

    // linha 1: tier
    for (let t = 1; t <= 5; t++) {
      let tt = t
      vpnBotao(gui, 1 + t, 1, t === i.tier ? 'minecraft:lime_concrete' : 'minecraft:gray_concrete', `Tier ${t}`, t === i.tier ? 'green' : 'white',
        [[t === i.tier ? 'Atual' : 'Clique para mudar', 'gray']], () => { vpnCmd(a, `velaria tier @p ${tt}`); vpnAbrir(p, vpnPrincipal) })
    }
    vpnBotao(gui, 0, 1, 'minecraft:compass', 'Tier', 'gold', [['Escolha ao lado →', 'gray']])
    vpnBotao(gui, 8, 1, 'minecraft:player_head', 'Trocar jogador', 'aqua', [[`Gerenciando: ${a.username}`, 'white'], ['Clique para escolher outro', 'gray']], () => vpnAbrir(p, vpnJogadores))
    vpnBotao(gui, 0, 0, 'minecraft:ender_pearl', 'Ir até ele', 'aqua', [], () => { p.server.runCommandSilent(`tp ${p.username} ${a.username}`); vpnFechar(p) })

    // linha 2: árvore
    vpnBotao(gui, 0, 2, 'minecraft:enchanted_book', 'Árvore da Ordem', 'light_purple', [['Abra com K', 'gray']])
    ;[1, 5, 18].forEach((n, k) => vpnBotao(gui, 2 + k, 2, 'minecraft:experience_bottle', `+${n} ponto(s)`, 'green', [],
      () => { vpnCmd(a, `execute as @p run provar pontos ${n}`); vpnFechar(p) }))
    vpnBotao(gui, 6, 2, 'minecraft:tnt', 'Resetar árvore', 'red', [['Devolve os pontos, tira habilidades, Caminhos e Maestria', 'gray']],
      () => { if (i.ordem && VG.velariaResetarArvore) VG.velariaResetarArvore(a, i.ordem); vpnFechar(p) })
    vpnBotao(gui, 8, 2, 'minecraft:writable_book', 'Tomos de Técnica', 'gold', [['Devolve os tomos aprendidos', 'gray']],
      () => { vpnCmd(a, 'execute as @p run tecnica'); vpnFechar(p) })

    // linha 3: armaduras e teste
    vpnBotao(gui, 1, 3, 'minecraft:armor_stand', 'Armaduras da Ordem', 'gold', [['Clique num conjunto para vestir', 'gray']],
      () => vpnAbrir(p, vpnArmaduras))
    vpnBotao(gui, 0, 3, a.stages.has('velaria_teste') ? 'minecraft:lime_dye' : 'minecraft:gray_dye',
      `Modo teste: ${a.stages.has('velaria_teste') ? 'ligado' : 'desligado'}`, 'yellow', [['Veste e segura itens de qualquer Ordem', 'gray']],
      () => { vpnCmd(a, 'execute as @p run provar modo'); vpnAbrir(p, vpnPrincipal) })
    vpnBotao(gui, 0, 4, 'minecraft:grass_block', a.isCreative() ? 'Modo: criativo' : 'Modo: sobrevivência', 'white', [['Alterna', 'gray']],
      () => { vpnCmd(a, `gamemode ${a.isCreative() ? 'survival' : 'creative'} @p`); vpnAbrir(p, vpnPrincipal) })
    vpnBotao(gui, 2, 3, 'minecraft:iron_chestplate', 'Armadura vestida', 'gold', [['Ver e tirar as peças do jogador', 'gray']], () => vpnAbrir(p, vpnVestida))
    vpnBotao(gui, 4, 3, 'minecraft:iron_sword', 'Caminhos', 'gold', [['Liga e desliga as armas da Ordem', 'gray']], () => vpnAbrir(p, vpnCaminhos))
    vpnBotao(gui, 6, 3, 'minecraft:amethyst_shard', 'Escola do Mago', 'light_purple', [['Só vale para a Ordem do Mago', 'gray']], () => vpnAbrir(p, vpnEscola))
    vpnBotao(gui, 8, 3, 'minecraft:emerald', `Honra: ${i.honra.h}`, i.honra.cor, [['Clique: +10   ·   Shift+clique: −10', 'gray']], null)
    gui.getSlot(8, 3).setLeftClicked(() => { a.persistentData.putInt('velaria_honra', a.persistentData.getInt('velaria_honra') + 10); vpnAbrir(p, vpnPrincipal) })
    try { gui.getSlot(8, 3).setShiftLeftClicked(() => { a.persistentData.putInt('velaria_honra', a.persistentData.getInt('velaria_honra') - 10); vpnAbrir(p, vpnPrincipal) }) } catch (e) { }
    vpnBotao(gui, 7, 4, 'minecraft:golden_apple', 'Curar e saciar', 'green', [],
      () => { vpnCmd(a, 'effect give @p minecraft:instant_health 1 10 true'); vpnCmd(a, 'effect give @p minecraft:saturation 1 10 true'); vpnFechar(p) })

    // linha 4: mundo
    vpnBotao(gui, 1, 4, 'minecraft:clock', 'Dia', 'yellow', [], () => { vpnCmd(a, 'time set noon'); vpnFechar(p) })
    vpnBotao(gui, 2, 4, 'minecraft:zombie_head', 'Boneco de treino', 'yellow', [['Zumbi parado com 1000 de vida', 'gray'], ['(precisa dificuldade Fácil)', 'dark_gray']],
      () => { vpnCmd(a, `execute at @p run summon minecraft:zombie ^ ^ ^3 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Boneco"',attributes:[{id:"minecraft:generic.max_health",base:1000}],Health:1000f}`); vpnFechar(p) })
    vpnBotao(gui, 3, 4, 'minecraft:bone', 'Remover bonecos', 'gray', [], () => { vpnCmd(a, 'kill @e[name=Boneco]'); vpnFechar(p) })
    vpnBotao(gui, 5, 4, 'minecraft:iron_sword', 'Dificuldade: Fácil', 'white', [], () => { vpnCmd(a, 'difficulty easy'); vpnFechar(p) })
    vpnBotao(gui, 6, 4, 'minecraft:poppy', 'Dificuldade: Pacífico', 'white', [], () => { vpnCmd(a, 'difficulty peaceful'); vpnFechar(p) })
    vpnBotao(gui, 4, 4, 'minecraft:lava_bucket', 'Limpar inventário', 'red', [['Apaga tudo do seu inventário', 'gray']],
      () => { vpnCmd(a, 'clear @p'); vpnFechar(p) })
    vpnBotao(gui, 8, 4, 'minecraft:barrier', 'Fechar', 'red', [], () => vpnFechar(p))
  })
}

function vpnArmaduras(p) {
  let a0 = vpnAlvo(p)
  let o = VG.velariaOrdem ? VG.velariaOrdem(a0) : null
  let lista = (global.VELARIA_ARMADURAS || []).filter(a => !o || a.ordem === o).slice(0, 27)
  p.openChestGUI(Text.gold('Armaduras da Ordem'), 4, gui => {
    lista.forEach((a, k) => {
      vpnBotao(gui, k % 9, Math.floor(k / 9), `kubejs:${a.id}_chestplate`, `${a.nome} T${a.tier}`, 'gold',
        [[vpvLinha(a), 'gray'], ['Clique para vestir', 'yellow']],
        () => { vpnCmd(a0, `execute as @p run provar vestir ${a.id}`); vpnFechar(p) })
    })
    vpnVoltar(gui, p, 3)
  })
}

// armadura que o jogador está vestindo: clique tira a peça e entrega a você
function vpnVestida(p) {
  let a = vpnAlvo(p)
  let slots = [['head', 'Cabeça'], ['chest', 'Peito'], ['legs', 'Pernas'], ['feet', 'Pés'], ['offhand', 'Mão secundária']]
  p.openChestGUI(Text.gold(`Armadura de ${a.username}`), 2, gui => {
    slots.forEach((s, k) => {
      let it = { head: a.headArmorItem, chest: a.chestArmorItem, legs: a.legsArmorItem, feet: a.feetArmorItem, offhand: a.offHandItem }[s[0]]
      let vazio = !it || it.isEmpty()
      let slot = gui.getSlot(2 + k, 0)
      slot.setItem(vazio ? vmItem('minecraft:gray_stained_glass_pane', `${s[1]}: vazio`, 'gray', []) : it.copy())
      if (!vazio) slot.setLeftClicked(() => {
        p.give(it.copy())
        p.server.runCommandSilent(s[0] === 'offhand' ? `item replace entity ${a.username} weapon.offhand with minecraft:air` : `item replace entity ${a.username} armor.${s[0]} with minecraft:air`)
        vpnAbrir(p, vpnVestida)
      })
    })
    vpnVoltar(gui, p, 1)
  })
}

// Caminhos da Ordem do jogador: clique liga/desliga
function vpnCaminhos(p) {
  let a = vpnAlvo(p)
  let i = vmInfo(a)
  let VO = i.VO
  let lista = i.ordem && VO ? VO.ordens[i.ordem].caminhos : []
  p.openChestGUI(Text.gold(`Caminhos de ${a.username}`), 2, gui => {
    lista.forEach((c, k) => {
      let on = a.stages.has(`velaria_caminho_${c}`)
      let cm = VO.caminhos[c]
      vpnBotao(gui, 2 + k * 2, 0, on ? 'minecraft:lime_dye' : 'minecraft:gray_dye', cm ? cm.nome : c, on ? 'green' : 'gray',
        [[on ? 'Liberado · clique para trancar' : 'Trancado · clique para liberar', 'gray']],
        () => { if (on) a.stages.remove(`velaria_caminho_${c}`); else a.stages.add(`velaria_caminho_${c}`); vpnAbrir(p, vpnCaminhos) })
    })
    vpnVoltar(gui, p, 1)
  })
}

// Escola do Mago
function vpnEscola(p) {
  let a = vpnAlvo(p)
  let M = global.VELARIA_MAGO
  let ks = M ? Object.keys(M.escolas) : []
  p.openChestGUI(Text.gold(`Escola de ${a.username}`), 2, gui => {
    ks.forEach((k, n) => {
      let on = a.stages.has(`velaria_escola_${k}`)
      vpnBotao(gui, 1 + n, 0, on ? 'minecraft:lime_dye' : 'minecraft:amethyst_shard', M.escolas[k].nome, on ? 'green' : 'white',
        [[on ? 'Escola atual' : 'Clique para trocar', 'gray']],
        () => { ks.forEach(x => a.stages.remove(`velaria_escola_${x}`)); a.stages.add(`velaria_escola_${k}`); vpnAbrir(p, vpnEscola) })
    })
    vpnVoltar(gui, p, 1)
  })
}

ServerEvents.commandRegistry(event => {
  let { commands: Commands } = event
  let { arguments: Arguments } = event
  let abrir = (p, alvo) => {
    p.persistentData.putString('velaria_painel_alvo', alvo)
    try { vpnPrincipal(p) } catch (e) { p.tell(Text.red(`Painel indisponível: ${e}`)) }
    return 1
  }
  event.register(Commands.literal('painel').requires(s => s.hasPermission(2))
    .executes(ctx => abrir(ctx.source.player, ctx.source.player.username))
    .then(Commands.literal('jogadores').executes(ctx => { vpnJogadores(ctx.source.player); return 1 }))
    .then(Commands.argument('jogador', Arguments.PLAYER.create(event))
      .executes(ctx => abrir(ctx.source.player, Arguments.PLAYER.getResult(ctx, 'jogador').username))))
})
