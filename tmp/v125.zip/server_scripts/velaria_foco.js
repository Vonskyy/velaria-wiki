// Velária — FOCO DE ARMA (árvore radial por armas, gen_arvores.py)
// Passivas de um braço da árvore só valem com a arma daquele braço na mão.
// Stages: velaria_foco_<caminho>_dano1/2, _vel1/2 e velaria_maestria_<caminho>.
const VFC = { dano: 0.05, vel: 0.04, mDano: 0.15, mVel: 0.08 }
const VFC_CAMINHOS = ['espada', 'katana', 'espada_longa', 'adaga', 'lanca', 'martelo', 'machado', 'foice', 'manopla', 'arco', 'besta',
  'cajado_arcano', 'cajado_sagrado', 'natureza', 'sinais', 'lamina_arcana']

function vfcBonus(p) {
  let item = p.mainHandItem
  for (let k = 0; k < VFC_CAMINHOS.length; k++) {
    let c = VFC_CAMINHOS[k]
    if (!item.hasTag(`velaria:caminho/${c}`)) continue
    let d = 0, v = 0
    for (let i = 1; i <= 2; i++) {
      if (p.stages.has(`velaria_foco_${c}_dano${i}`)) d += VFC.dano
      if (p.stages.has(`velaria_foco_${c}_vel${i}`)) v += VFC.vel
    }
    // só a primeira Maestria aprendida vale (sem linha de exclusão na árvore)
    let m = String(p.persistentData.getString('velaria_maestria') || '')
    if (!m) { for (let j = 0; j < VFC_CAMINHOS.length; j++) if (p.stages.has(`velaria_maestria_${VFC_CAMINHOS[j]}`)) { m = VFC_CAMINHOS[j]; p.persistentData.putString('velaria_maestria', m); break } }
    if (m === c && p.stages.has(`velaria_maestria_${c}`)) { d += VFC.mDano; v += VFC.mVel }
    return [d, v]
  }
  return [0, 0]
}

function vfcAplicar(p, attr, id, valor) {
  p.server.runCommandSilent(`attribute ${p.username} ${attr} modifier remove ${id}`)
  if (valor > 0) p.server.runCommandSilent(`attribute ${p.username} ${attr} modifier add ${id} ${valor.toFixed(3)} add_multiplied_base`)
}

PlayerEvents.tick(event => {
  let p = event.player
  if (p.age % 10 !== 0) return
  let r = vfcBonus(p)
  let d = r[0], v = r[1]
  let chave = `${d.toFixed(3)}|${v.toFixed(3)}`
  if (String(p.persistentData.getString('velaria_foco_ult') || '0.000|0.000') === chave) return
  p.persistentData.putString('velaria_foco_ult', chave)
  vfcAplicar(p, 'minecraft:generic.attack_damage', 'velaria:foco_dano', d)
  vfcAplicar(p, 'minecraft:generic.attack_speed', 'velaria:foco_vel', v)
})

// reset completo da árvore (painel): pontos, passivas de arma, Maestria e Caminhos da Ordem
VG.velariaResetarArvore = function (p, o) {
  p.server.runCommandSilent(`puffish_skills category erase ${p.username} velaria:ordem_${o}`)
  VFC_CAMINHOS.forEach(c => {
    ;['dano1', 'dano2', 'vel1', 'vel2'].forEach(t => p.stages.remove(`velaria_foco_${c}_${t}`))
    p.stages.remove(`velaria_maestria_${c}`)
    p.stages.remove(`velaria_caminho_${c}`)
  })
  p.persistentData.remove('velaria_maestria')
  p.persistentData.putString('velaria_foco_ult', '')
}
