// ============================================================
//  Velária MMORPG — ORDENS, CAMINHOS DE ARMA e GRAÇAS
//  Pasta: kubejs/server_scripts/  (recarrega com /reload)
//  Dados GERADOS por tools/build_scripts4.py; a lógica abaixo é fixa.
//
//  Como funciona:
//  - O jogador escolhe a Ordem na tela do NeoOrigins. O poder "Marca" põe o stage
//    velaria_ordem_<id>; se o comando do NeoOrigins falhar, o evento originChanged faz o mesmo.
//  - Juramento: itens de outras Ordens CAEM do inventário (a cada 2 s).
//  - Caminhos: cada Ordem tem 3 caminhos de arma. A arma de um caminho ainda trancado
//    sai da mão. Destranca na árvore "Caminhos" (Pufferfish's Skills): 1 ponto ao entrar
//    na Ordem e +1 a cada tier.
//  - Graça: escolhida na criação do personagem (4ª tela do NeoOrigins), um deus por caminho
//    ou "Sem Graça". A bênção menor vem do próprio NeoOrigins (sempre ativa). A bênção maior
//    liga aqui: com a arma do caminho do deus na mão (caminho destrancado). O nó "Devoção" dobra.
//    O poder do deus põe o stage velaria_graca_<caminho> (ou velaria_graca_nenhuma).
//  - Ofício: escolhido junto da Linhagem (2ª tela). Poder põe o stage velaria_oficio_<id>.
//  - Kit inicial: dado uma vez por Ordem.
//  Ainda NÃO testado em jogo.
// ============================================================

const VO = {
 "ordens": {
  "guerreiro": {
   "nome": "Legião de Ferro",
   "classe": "Guerreiro",
   "caminhos": [
    "espada_longa",
    "katana",
    "espada"
   ],
   "exclusivo": [
    "^rogues:warrior_",
    "^rogues:.*(double_axe|glaive)",
    "^armory_rpgs:.*onslaught"
   ],
   "arquetipo": "pesada",
   "kit": [
    [
     "kubejs:cobre_claymore",
     1
    ],
    [
     "kubejs:cobre_katana",
     1
    ],
    [
     "kubejs:cobre_sword",
     1
    ],
    [
     "minecraft:shield",
     1
    ],
    [
     "minecraft:leather_helmet",
     1
    ],
    [
     "minecraft:leather_chestplate",
     1
    ],
    [
     "minecraft:leather_leggings",
     1
    ],
    [
     "minecraft:leather_boots",
     1
    ],
    [
     "minecraft:bread",
     16
    ],
    [
     "minecraft:torch",
     32
    ],
    [
     "lightmanscurrency:coin_iron",
     5
    ],
    [
     "kubejs:insignia_guerreiro",
     2
    ]
   ]
  },
  "paladino": {
   "nome": "Ordem da Aurora",
   "classe": "Paladino",
   "caminhos": [
    "martelo",
    "espada",
    "lanca"
   ],
   "exclusivo": [
    "^paladins:paladin_",
    "^paladins:.*(claymore|great_hammer|kite_shield)",
    "^armory_rpgs:.*lightbringer"
   ],
   "arquetipo": "pesada",
   "kit": [
    [
     "kubejs:cobre_hammer",
     1
    ],
    [
     "kubejs:cobre_sword",
     1
    ],
    [
     "kubejs:cobre_spear",
     1
    ],
    [
     "minecraft:shield",
     1
    ],
    [
     "minecraft:leather_helmet",
     1
    ],
    [
     "minecraft:leather_chestplate",
     1
    ],
    [
     "minecraft:leather_leggings",
     1
    ],
    [
     "minecraft:leather_boots",
     1
    ],
    [
     "minecraft:bread",
     16
    ],
    [
     "minecraft:torch",
     32
    ],
    [
     "lightmanscurrency:coin_iron",
     5
    ],
    [
     "kubejs:insignia_paladino",
     2
    ]
   ]
  },
  "sacerdote": {
   "nome": "Chama Branca",
   "classe": "Sacerdote",
   "caminhos": [
    "cajado_sagrado",
    "martelo",
    "lanca"
   ],
   "exclusivo": [
    "^paladins:priest_",
    "^paladins:.*holy",
    "^armory_rpgs:.*absolution"
   ],
   "arquetipo": "leve",
   "kit": [
    [
     "kubejs:cobre_hammer",
     1
    ],
    [
     "kubejs:cobre_spear",
     1
    ],
    [
     "paladins:acolyte_wand",
     1
    ],
    [
     "minecraft:leather_helmet",
     1
    ],
    [
     "minecraft:leather_chestplate",
     1
    ],
    [
     "minecraft:leather_leggings",
     1
    ],
    [
     "minecraft:leather_boots",
     1
    ],
    [
     "minecraft:bread",
     16
    ],
    [
     "minecraft:torch",
     32
    ],
    [
     "lightmanscurrency:coin_iron",
     5
    ],
    [
     "kubejs:insignia_sacerdote",
     2
    ]
   ]
  },
  "mago": {
   "nome": "Círculo Arcano",
   "classe": "Mago",
   "caminhos": [
    "cajado_arcano"
   ],
   "exclusivo": [
    "^irons_spellbooks:.*(spell_book|staff|cane|lightning_rod|frosted_helve|wand)$",
    "^irons_spellbooks:scroll$",
    "^irons_spellbooks:.*_(helmet|chestplate|leggings|boots)$"
   ],
   "arquetipo": "leve",
   "kit": [
    [
     "kubejs:cobre_cajado",
     1
    ],
    [
     "kubejs:cobre_orbe",
     1
    ],
    [
     "irons_spellbooks:copper_spell_book",
     1
    ],
    [
     "minecraft:leather_helmet",
     1
    ],
    [
     "minecraft:leather_chestplate",
     1
    ],
    [
     "minecraft:leather_leggings",
     1
    ],
    [
     "minecraft:leather_boots",
     1
    ],
    [
     "minecraft:bread",
     16
    ],
    [
     "minecraft:torch",
     32
    ],
    [
     "lightmanscurrency:coin_iron",
     5
    ],
    [
     "kubejs:insignia_mago",
     2
    ]
   ]
  },
  "ladino": {
   "nome": "Irmandade do Véu",
   "classe": "Ladino",
   "caminhos": [
    "adaga",
    "espada",
    "besta"
   ],
   "exclusivo": [
    "^rogues:rogue_",
    "^rogues:.*(dagger|sickle)",
    "^armory_rpgs:.*slayer"
   ],
   "arquetipo": "media",
   "kit": [
    [
     "kubejs:cobre_dagger",
     1
    ],
    [
     "kubejs:cobre_sword",
     1
    ],
    [
     "minecraft:leather_helmet",
     1
    ],
    [
     "minecraft:leather_chestplate",
     1
    ],
    [
     "minecraft:leather_leggings",
     1
    ],
    [
     "minecraft:leather_boots",
     1
    ],
    [
     "minecraft:bread",
     16
    ],
    [
     "minecraft:torch",
     32
    ],
    [
     "lightmanscurrency:coin_iron",
     5
    ],
    [
     "kubejs:insignia_ladino",
     2
    ]
   ]
  },
  "arqueiro": {
   "nome": "Patrulheiros do Vento",
   "classe": "Arqueiro",
   "caminhos": [
    "arco",
    "besta",
    "lanca"
   ],
   "exclusivo": [
    "^archers:",
    "^armory_rpgs:.*riftstalker"
   ],
   "arquetipo": "media",
   "kit": [
    [
     "kubejs:cobre_spear",
     1
    ],
    [
     "minecraft:bow",
     1
    ],
    [
     "minecraft:arrow",
     32
    ],
    [
     "minecraft:leather_helmet",
     1
    ],
    [
     "minecraft:leather_chestplate",
     1
    ],
    [
     "minecraft:leather_leggings",
     1
    ],
    [
     "minecraft:leather_boots",
     1
    ],
    [
     "minecraft:bread",
     16
    ],
    [
     "minecraft:torch",
     32
    ],
    [
     "lightmanscurrency:coin_iron",
     5
    ],
    [
     "kubejs:insignia_arqueiro",
     2
    ]
   ]
  },
  "berserker": {
   "nome": "Clã da Fúria",
   "classe": "Berserker",
   "caminhos": [
    "machado",
    "martelo",
    "espada_longa"
   ],
   "exclusivo": [
    "^berserker_rpg:",
    "^armory_rpgs:.*warlord"
   ],
   "arquetipo": "pesada",
   "kit": [
    [
     "kubejs:cobre_double_axe",
     1
    ],
    [
     "kubejs:cobre_hammer",
     1
    ],
    [
     "kubejs:cobre_claymore",
     1
    ],
    [
     "minecraft:leather_helmet",
     1
    ],
    [
     "minecraft:leather_chestplate",
     1
    ],
    [
     "minecraft:leather_leggings",
     1
    ],
    [
     "minecraft:leather_boots",
     1
    ],
    [
     "minecraft:bread",
     16
    ],
    [
     "minecraft:torch",
     32
    ],
    [
     "lightmanscurrency:coin_iron",
     5
    ],
    [
     "kubejs:insignia_berserker",
     2
    ]
   ]
  },
  "bruxo": {
   "nome": "Escola do Lobo",
   "classe": "Bruxo (Witcher)",
   "caminhos": [
    "espada",
    "sinais",
    "besta"
   ],
   "exclusivo": [
    "^witcher_rpg:"
   ],
   "arquetipo": "media",
   "kit": [
    [
     "kubejs:cobre_sword",
     1
    ],
    [
     "minecraft:crossbow",
     1
    ],
    [
     "minecraft:arrow",
     16
    ],
    [
     "minecraft:leather_helmet",
     1
    ],
    [
     "minecraft:leather_chestplate",
     1
    ],
    [
     "minecraft:leather_leggings",
     1
    ],
    [
     "minecraft:leather_boots",
     1
    ],
    [
     "minecraft:bread",
     16
    ],
    [
     "minecraft:torch",
     32
    ],
    [
     "lightmanscurrency:coin_iron",
     5
    ],
    [
     "kubejs:insignia_bruxo",
     2
    ]
   ]
  },
  "druida": {
   "nome": "Círculo do Carvalho",
   "classe": "Druida",
   "caminhos": [
    "natureza",
    "foice",
    "lanca"
   ],
   "exclusivo": [
    "^druids:"
   ],
   "arquetipo": "leve",
   "kit": [
    [
     "druids:wand_nature",
     1
    ],
    [
     "kubejs:cobre_scythe",
     1
    ],
    [
     "kubejs:cobre_spear",
     1
    ],
    [
     "minecraft:leather_helmet",
     1
    ],
    [
     "minecraft:leather_chestplate",
     1
    ],
    [
     "minecraft:leather_leggings",
     1
    ],
    [
     "minecraft:leather_boots",
     1
    ],
    [
     "minecraft:bread",
     16
    ],
    [
     "minecraft:torch",
     32
    ],
    [
     "lightmanscurrency:coin_iron",
     5
    ],
    [
     "kubejs:insignia_druida",
     2
    ]
   ]
  },
  "monge": {
   "nome": "Mosteiro do Punho",
   "classe": "Monge",
   "caminhos": [
    "manopla",
    "lanca",
    "katana"
   ],
   "exclusivo": [
    "^forcemaster_rpg:"
   ],
   "arquetipo": "media",
   "kit": [
    [
     "kubejs:cobre_knuckle",
     1
    ],
    [
     "kubejs:cobre_spear",
     1
    ],
    [
     "kubejs:cobre_katana",
     1
    ],
    [
     "minecraft:leather_helmet",
     1
    ],
    [
     "minecraft:leather_chestplate",
     1
    ],
    [
     "minecraft:leather_leggings",
     1
    ],
    [
     "minecraft:leather_boots",
     1
    ],
    [
     "minecraft:bread",
     16
    ],
    [
     "minecraft:torch",
     32
    ],
    [
     "lightmanscurrency:coin_iron",
     5
    ],
    [
     "kubejs:insignia_monge",
     2
    ]
   ]
  },
  "lamina_arcana": {
   "nome": "Lâminas do Crepúsculo",
   "classe": "Lâmina Arcana",
   "caminhos": [
    "lamina_arcana",
    "katana",
    "espada_longa"
   ],
   "exclusivo": [
    "^spellblades?[a-z_]*:"
   ],
   "arquetipo": "media",
   "kit": [
    [
     "kubejs:cobre_katana",
     1
    ],
    [
     "kubejs:cobre_claymore",
     1
    ],
    [
     "minecraft:leather_helmet",
     1
    ],
    [
     "minecraft:leather_chestplate",
     1
    ],
    [
     "minecraft:leather_leggings",
     1
    ],
    [
     "minecraft:leather_boots",
     1
    ],
    [
     "minecraft:bread",
     16
    ],
    [
     "minecraft:torch",
     32
    ],
    [
     "lightmanscurrency:coin_iron",
     5
    ],
    [
     "kubejs:insignia_lamina_arcana",
     2
    ]
   ]
  }
 },
 "caminhos": {
  "espada": {
   "nome": "Espada",
   "deus": "Ares",
   "panteao": "grego",
   "attrs": [
    "minecraft:generic.attack_damage"
   ],
   "kjs": [
    "sword"
   ],
   "regex": [
    "^kubejs:.*_sword$",
    "^simplyswords:.*(rapier|cutlass|twinblade)"
   ]
  },
  "katana": {
   "nome": "Katana",
   "deus": "Susanoo",
   "panteao": "japonês",
   "attrs": [
    "minecraft:generic.attack_damage"
   ],
   "kjs": [
    "katana"
   ],
   "regex": [
    "katana"
   ]
  },
  "espada_longa": {
   "nome": "Espada Longa",
   "deus": "Tyr",
   "panteao": "nórdico",
   "attrs": [
    "minecraft:generic.attack_damage"
   ],
   "kjs": [
    "claymore"
   ],
   "regex": [
    "claymore",
    "greatsword",
    "great_sword",
    "longsword"
   ]
  },
  "adaga": {
   "nome": "Adagas",
   "deus": "Loki",
   "panteao": "nórdico",
   "attrs": [
    "minecraft:generic.attack_damage"
   ],
   "kjs": [
    "dagger"
   ],
   "regex": [
    "dagger",
    "(^|_|:)sai($|_)",
    "sickle",
    "knife",
    "chakram"
   ]
  },
  "lanca": {
   "nome": "Lança",
   "deus": "Atena",
   "panteao": "grego",
   "attrs": [
    "minecraft:generic.attack_damage"
   ],
   "kjs": [
    "spear"
   ],
   "regex": [
    "spear",
    "glaive",
    "halberd",
    "(^|_|:)lance($|_)"
   ]
  },
  "martelo": {
   "nome": "Martelo e Maça",
   "deus": "Thor",
   "panteao": "nórdico",
   "attrs": [
    "minecraft:generic.attack_damage"
   ],
   "kjs": [
    "hammer"
   ],
   "regex": [
    "hammer",
    "(^|_|:)mace($|_)"
   ]
  },
  "machado": {
   "nome": "Machado de Guerra",
   "deus": "Perun",
   "panteao": "eslavo",
   "attrs": [
    "minecraft:generic.attack_damage"
   ],
   "kjs": [
    "double_axe"
   ],
   "regex": [
    "double_axe",
    "greataxe",
    "great_axe",
    "battle_?axe",
    "^berserker_rpg:.*axe"
   ]
  },
  "foice": {
   "nome": "Foice",
   "deus": "Morrígan",
   "panteao": "celta",
   "attrs": [
    "minecraft:generic.attack_damage"
   ],
   "kjs": [
    "scythe"
   ],
   "regex": [
    "scythe"
   ]
  },
  "manopla": {
   "nome": "Manoplas",
   "deus": "Hanuman",
   "panteao": "hindu",
   "attrs": [
    "minecraft:generic.attack_damage"
   ],
   "kjs": [
    "knuckle"
   ],
   "regex": [
    "knuckle",
    "gauntlet",
    "(^|_|:)fist"
   ]
  },
  "arco": {
   "nome": "Arco",
   "deus": "Ártemis",
   "panteao": "grego",
   "attrs": [
    "ranged_weapon:damage"
   ],
   "kjs": [],
   "regex": [
    "(longbow|shortbow|_bow)$"
   ]
  },
  "besta": {
   "nome": "Besta",
   "deus": "Ullr",
   "panteao": "nórdico",
   "attrs": [
    "ranged_weapon:damage"
   ],
   "kjs": [],
   "regex": [
    "crossbow"
   ]
  },
  "cajado_arcano": {
   "nome": "Cajado Arcano",
   "deus": "Thoth",
   "panteao": "egípcio",
   "attrs": [
    "irons_spellbooks:spell_power"
   ],
   "kjs": [
    "cajado",
    "orbe"
   ],
   "regex": [
    "^irons_spellbooks:.*(staff|cane|lightning_rod|frosted_helve)$"
   ]
  },
  "cajado_sagrado": {
   "nome": "Cajado Sagrado",
   "deus": "Amaterasu",
   "panteao": "japonês",
   "attrs": [
    "spell_power:healing"
   ],
   "kjs": [],
   "regex": [
    "^paladins:.*(holy|staff|wand)"
   ]
  },
  "natureza": {
   "nome": "Bastão da Natureza",
   "deus": "Cernunnos",
   "panteao": "celta",
   "attrs": [
    "spell_power:nature",
    "spell_power:healing"
   ],
   "kjs": [],
   "regex": [
    "^druids:.*(staff|stave|wand)"
   ]
  },
  "lamina_arcana": {
   "nome": "Lâmina Arcana",
   "deus": "Hécate",
   "panteao": "grego",
   "attrs": [
    "minecraft:generic.attack_damage",
    "spell_power:arcane",
    "spell_power:fire",
    "spell_power:frost"
   ],
   "kjs": [],
   "regex": [
    "^spellblades?[a-z_]*:.*(blade|sword|claymore|glaive)"
   ]
  },
  "sinais": {
   "nome": "Espada e Sinais",
   "deus": "Veles",
   "panteao": "eslavo",
   "attrs": [
    "minecraft:generic.attack_damage"
   ],
   "kjs": [],
   "regex": [
    "^witcher_rpg:.*(sword|blade)"
   ]
  }
 },
 "arquetipos": {
  "pesada": "Pesada",
  "media": "Média",
  "leve": "Leve"
 }
}

// Se a árvore do Pufferfish's Skills não carregar, troque para true:
// o jogador destranca caminhos com /caminho <nome> usando os pontos guardados pelo script.
const VO_COMANDO_CAMINHO = false
VG.VELARIA_VO = VO
VG.VELARIA_COMANDO_CAMINHO = VO_COMANDO_CAMINHO

// ---------- TAGS ----------
ServerEvents.tags('item', event => {
  Object.keys(VO.caminhos).forEach(c => {
    let tag = `velaria:caminho/${c}`
    VO.caminhos[c].kjs.forEach(tipo => event.add(tag, `#velaria:arma/${tipo}`))
    VO.caminhos[c].regex.forEach(r => event.add(tag, new RegExp(r)))
    event.remove(tag, /^minecraft:/)
  })
  Object.keys(VO.ordens).forEach(o => {
    VO.ordens[o].exclusivo.forEach(r => event.add(`velaria:ordem/${o}`, new RegExp(r)))
  })
  Object.keys(VO.ordens).forEach(o => {
    let tag = `velaria:proibido/${o}`
    let meus = VO.ordens[o].caminhos
    Object.keys(VO.ordens).forEach(outra => { if (outra !== o) event.add(tag, `#velaria:ordem/${outra}`) })
    Object.keys(VO.caminhos).forEach(c => { if (meus.indexOf(c) < 0) event.add(tag, `#velaria:caminho/${c}`) })
    Object.keys(VO.arquetipos).forEach(a => { if (a !== VO.ordens[o].arquetipo) event.add(tag, `#velaria:armadura/${a}`) })
    // 1.1.19: o Mago usa o Iron's Spells; os cajados e mantos do Wizards ficam fora do jogo para todos
    event.add(tag, /^wizards:.*(staff|wand|robe)/)
  })
})

// ---------- Utilidades (compartilhadas com os outros scripts via global) ----------
VG.velariaOrdem = function (p) {
  let salva = String(p.persistentData.getString('velaria_ordem') || '')
  let tem = Object.keys(VO.ordens).filter(o => p.stages.has(`velaria_ordem_${o}`))
  if (tem.length === 0) return null
  if (tem.length === 1) return tem[0]
  // Mais de uma: vale a mais nova (a que ainda não está salva)
  let nova = tem.filter(o => o !== salva)
  return nova.length ? nova[0] : tem[0]
}

VG.velariaDarPontoCaminho = function (p, n) {
  let o = VG.velariaOrdem(p)
  if (!o) return
  let d = p.persistentData
  d.putInt('velaria_pontos', d.getInt('velaria_pontos') + n)
  p.server.runCommandSilent(`puffish_skills points add ${p.username} velaria:ordem_${o} ${n}`)  // árvore única da Ordem (Caminhos + Habilidades)
}

// Graça escolhida na tela do NeoOrigins. Retorna o caminho, 'nenhuma' ou null (ainda não escolheu).
VG.velariaGraca = function (p) {
  let d = p.persistentData
  let salva = String(d.getString('velaria_graca') || '')
  let ids = Object.keys(VO.caminhos).concat(['nenhuma'])
  let tem = ids.filter(c => p.stages.has(`velaria_graca_${c}`))
  if (tem.length === 0) return null
  let g = tem[0]
  if (tem.length > 1) {
    // Trocou de Graça: vale a mais nova (a que ainda não está salva)
    let nova = tem.filter(c => c !== salva)
    g = nova.length ? nova[0] : tem[0]
    tem.forEach(c => { if (c !== g) p.stages.remove(`velaria_graca_${c}`) })
  }
  if (salva !== g) {
    voDesligarGraca(p)
    d.putString('velaria_graca', g)
    voAnunciarGraca(p, g)
  }
  return g
}

function voAnunciarGraca(p, g) {
  let nome = p.username
  if (g === 'nenhuma') { p.tell(Text.gray('Você renunciou aos deuses. Nenhuma Graça te acompanha.')); return }
  let c = VO.caminhos[g]
  if (!c) return
  p.server.runCommandSilent(`title ${nome} times 10 80 20`)
  p.server.runCommandSilent(`title ${nome} subtitle {"text":"Bônus maior com ${c.nome.toLowerCase()} na mão","color":"gray"}`)
  p.server.runCommandSilent(`title ${nome} title {"text":"Graça de ${c.deus}","color":"aqua","bold":true}`)
  p.tell(Text.aqua(`${c.deus}, deus ${c.panteao}, abençoa você. Bênção maior com ${c.nome.toLowerCase()} na mão.`))
  let o = VG.velariaOrdem(p)
  if (o && VO.ordens[o].caminhos.indexOf(g) < 0)
    p.tell(Text.gray(`Sua Ordem não usa ${c.nome.toLowerCase()}: você fica só com a bênção menor de ${c.deus}.`))
}

VG.velariaOficio = function (p) {
  let s = String(p.persistentData.getString('velaria_oficio') || '')
  return s || null
}

function voValorGraca(p, attr) {
  let dobro = p.stages.has('velaria_devocao') ? 2 : 1
  if (attr.indexOf('minecraft:') === 0 || attr.indexOf('irons_spellbooks:') === 0) return [0.08 * dobro, 'add_multiplied_base']
  return [1.5 * dobro, 'add_value']
}

function voLigarGraca(p, c) {
  VO.caminhos[c].attrs.forEach(a => {
    let v = voValorGraca(p, a)
    p.server.runCommandSilent(`attribute ${p.username} ${a} modifier add velaria:graca ${v[0]} ${v[1]}`)
  })
  p.persistentData.putString('velaria_graca_ativa', c)
}

function voDesligarGraca(p) {
  let ativa = String(p.persistentData.getString('velaria_graca_ativa') || '')
  if (!ativa || !VO.caminhos[ativa]) return
  VO.caminhos[ativa].attrs.forEach(a =>
    p.server.runCommandSilent(`attribute ${p.username} ${a} modifier remove velaria:graca`))
  p.persistentData.putString('velaria_graca_ativa', '')
}

const VO_RUNAS = {
  // mago: o Iron's Spells usa mana, não runas (1.1.19)
  lamina_arcana: [['runes:small_rune_pouch', 1], ['runes:arcane_stone', 16], ['runes:fire_stone', 16], ['runes:frost_stone', 16]],
  sacerdote: [['runes:small_rune_pouch', 1], ['runes:healing_stone', 32]],
  paladino: [['runes:small_rune_pouch', 1], ['runes:healing_stone', 32]]
}

// Runas: magias do Spell Engine gastam runas a cada lançamento. Sem runas o mago não lança nada.
// Dadas uma vez por Ordem, também para quem já tinha recebido o kit antes desta regra.
function voDarRunas(p, o) {
  let runas = VO_RUNAS[o]
  let d = p.persistentData
  if (!runas || d.getBoolean(`velaria_runas_${o}`)) return
  d.putBoolean(`velaria_runas_${o}`, true)
  runas.forEach(it => p.server.runCommandSilent(`give ${p.username} ${it[0]} ${it[1]}`))
  p.tell(Text.lightPurple('Você recebeu runas e uma bolsa de runas: cada magia gasta 1 runa da escola dela.'))
  p.tell(Text.gray('Faça mais na bancada: pedra + ametista (arcana), carvão (fogo), bola de neve (gelo), pepita de ouro (cura).'))
}

// Árvore de habilidades da Ordem (gen_arvores.py): só a da sua Ordem fica aberta; pontos vêm de XP de combate
function voArvoreDaOrdem(p, o) {
  Object.keys(VO.ordens).forEach(x => {
    p.server.runCommandSilent(`puffish_skills category ${x === o ? 'unlock' : 'lock'} ${p.username} velaria:ordem_${x}`)
  })
}
VG.velariaArvoreDaOrdem = voArvoreDaOrdem

function voEntrarNaOrdem(p, o) {
  let d = p.persistentData
  let nome = p.username
  let server = p.server
  // Só uma Ordem por vez
  Object.keys(VO.ordens).forEach(x => { if (x !== o) p.stages.remove(`velaria_ordem_${x}`) })
  d.putString('velaria_ordem', o)

  // Árvore de caminhos: 1 ponto + 1 por tier já conquistado
  voArvoreDaOrdem(p, o)
  let tier = VG.velariaTier ? VG.velariaTier(p) : 1
  if (!d.getBoolean(`velaria_pontos_${o}`)) {
    d.putBoolean(`velaria_pontos_${o}`, true)
    VG.velariaDarPontoCaminho(p, tier)
  }

  // Kit inicial, uma vez por Ordem
  if (!d.getBoolean(`velaria_kit_${o}`)) {
    d.putBoolean(`velaria_kit_${o}`, true)
    VO.ordens[o].kit.forEach(it => server.runCommandSilent(`give ${nome} ${it[0]} ${it[1]}`))
    p.tell(Text.gold(`A ${VO.ordens[o].nome} te entregou o kit de iniciação.`))
  }

  voDarRunas(p, o)

  // Graça: escolhida na tela do NeoOrigins (não é mais sorteada)
  if (!VG.velariaGraca(p)) p.tell(Text.aqua('Escolha sua Graça divina na tela de criação do personagem.'))

  let cams = VO.ordens[o].caminhos.map(c => VO.caminhos[c].nome).join(', ')
  p.tell(Text.yellow(`Você jurou pela ${VO.ordens[o].nome}. Caminhos: ${cams}.`))
  p.tell(Text.gray('Abra a árvore de habilidades, aba "Caminhos", e gaste seu ponto para destrancar um caminho.'))
}

function voTirarDaMao(p, pilha, principal) {
  let copia = pilha.copy()
  if (principal) p.setMainHandItem(Item.empty)
  else p.setOffHandItem(Item.empty)
  for (let i = 9; i < 36; i++) {
    if (p.inventory.getItem(i).isEmpty()) { p.inventory.setItem(i, copia); return }
  }
  p.drop(copia, false)
}

// ---------- NeoOrigins: reforço caso o comando da Marca não rode ----------
if (typeof NeoOriginsEvents !== 'undefined') {
  NeoOriginsEvents.originChanged(event => {
    let novo = String(event.newOriginId || '')
    if (novo.startsWith('velaria:linhagem_')) event.player.persistentData.putString('velaria_linhagem', novo.substring(8))
    if (novo.startsWith('velaria:oficio_') && !novo.startsWith('velaria:oficio_marca_'))
      event.player.persistentData.putString('velaria_oficio', novo.substring('velaria:oficio_'.length))
    if (novo.startsWith('velaria:graca_')) {
      let g = novo.substring('velaria:graca_'.length)
      if (g === 'nenhuma' || VO.caminhos[g]) event.player.stages.add(`velaria_graca_${g}`)
    }
    if (!novo.startsWith('velaria:ordem_')) return
    let o = novo.substring('velaria:ordem_'.length)
    if (VO.ordens[o]) event.player.stages.add(`velaria_ordem_${o}`)
  })
}

// ---------- Checagem a cada 2 s ----------
PlayerEvents.tick(event => {
  let p = event.player
  if (p.server.tickCount % 40 !== 7) return
  let o = VG.velariaOrdem(p)
  if (!o) return
  let d = p.persistentData
  if (String(d.getString('velaria_ordem') || '') !== o || !d.getBoolean(`velaria_kit_${o}`)) voEntrarNaOrdem(p, o)
  else if (VO_RUNAS[o] && !d.getBoolean(`velaria_runas_${o}`)) voDarRunas(p, o)
  if (p.isCreative() || p.isSpectator() || p.stages.has('velaria_teste')) return

  // Juramento: itens de outras Ordens caem
  let proibido = `velaria:proibido/${o}`
  let caiu = 0
  for (let i = 0; i < p.inventory.getContainerSize(); i++) {
    let st = p.inventory.getItem(i)
    if (st.isEmpty() || !st.hasTag(proibido)) continue
    p.drop(st.copy(), false)
    p.inventory.setItem(i, Item.empty)
    caiu++
  }
  if (caiu > 0) p.displayClientMessage(Text.red(`Juramento da ${VO.ordens[o].nome}: ${caiu} item(ns) de outra Ordem caíram.`), true)

  // Caminhos trancados: a arma sai da mão
  VO.ordens[o].caminhos.forEach(c => {
    if (p.stages.has(`velaria_caminho_${c}`)) return
    let tag = `velaria:caminho/${c}`
    if (p.mainHandItem.hasTag(tag)) {
      voTirarDaMao(p, p.mainHandItem, true)
      p.displayClientMessage(Text.gold(`Caminho trancado: ${VO.caminhos[c].nome}. Destranque na árvore "Caminhos".`), true)
    }
    if (p.offHandItem.hasTag(tag)) voTirarDaMao(p, p.offHandItem, false)
  })

  // Graça: bênção maior liga com a arma do caminho do deus na mão
  let g = VG.velariaGraca(p)
  if (!g || !VO.caminhos[g] || VO.ordens[o].caminhos.indexOf(g) < 0) return
  let naMao = p.mainHandItem.hasTag(`velaria:caminho/${g}`) && p.stages.has(`velaria_caminho_${g}`)
  let ativa = String(d.getString('velaria_graca_ativa') || '')
  if (naMao && !ativa) voLigarGraca(p, g)
  else if (!naMao && ativa) voDesligarGraca(p)
})

PlayerEvents.loggedIn(event => {
  voDesligarGraca(event.player)
  // quem já tinha Ordem antes das árvores novas recebe a árvore ao entrar
  let o = VG.velariaOrdem(event.player)
  if (o) voArvoreDaOrdem(event.player, o)
})

// ---------- Tomo do Destino: escolher outra Graça ----------
ItemEvents.rightClicked('kubejs:tomo_destino', event => {
  let p = event.player
  let nome = p.username
  voDesligarGraca(p)
  Object.keys(VO.caminhos).concat(['nenhuma']).forEach(c => p.stages.remove(`velaria_graca_${c}`))
  p.persistentData.putString('velaria_graca', '')
  p.server.runCommandSilent(`neoorigins reset ${nome} velaria:graca`)
  p.server.runCommandSilent(`neoorigins gui ${nome}`)
  p.tell(Text.aqua('Os deuses te ouvem. Escolha outra Graça.'))
  if (!p.isCreative()) event.item.shrink(1)
})

// ---------- Comandos ----------
ServerEvents.commandRegistry(event => {
  let { commands: Commands, arguments: Arguments } = event

  event.register(Commands.literal('graca').executes(ctx => {
    let p = ctx.source.player
    let g = VG.velariaGraca(p)
    if (!g) p.tell(Text.gray('Você ainda não escolheu uma Graça. Ela aparece na tela de criação do personagem.'))
    else if (g === 'nenhuma') p.tell(Text.gray('Sem Graça: você renunciou aos deuses.'))
    else {
      let o = VG.velariaOrdem(p)
      let serve = o && VO.ordens[o].caminhos.indexOf(g) >= 0
      p.tell(Text.aqua(`Graça de ${VO.caminhos[g].deus}: bênção menor sempre ativa.`))
      p.tell(serve
        ? Text.aqua(`Bênção maior com ${VO.caminhos[g].nome.toLowerCase()} na mão` + (p.stages.has('velaria_devocao') ? ' (Devoção: dobrada).' : '.'))
        : Text.gray(`Bênção maior: sua Ordem não usa ${VO.caminhos[g].nome.toLowerCase()}.`))
    }
    return 1
  }))

  event.register(Commands.literal('caminho')
    .then(Commands.argument('nome', Arguments.STRING.create(event)).executes(ctx => {
      let p = ctx.source.player
      if (!VO_COMANDO_CAMINHO) { p.tell(Text.gray('Use a árvore de habilidades, aba "Caminhos".')); return 0 }
      let o = VG.velariaOrdem(p)
      let c = String(Arguments.STRING.getResult(ctx, 'nome'))
      if (!o || VO.ordens[o].caminhos.indexOf(c) < 0) {
        p.tell(Text.red(`Caminhos da sua Ordem: ${o ? VO.ordens[o].caminhos.join(', ') : 'nenhum'}`)); return 0
      }
      let d = p.persistentData
      if (d.getInt('velaria_pontos') < 1) { p.tell(Text.red('Sem pontos. Suba de tier para ganhar mais.')); return 0 }
      d.putInt('velaria_pontos', d.getInt('velaria_pontos') - 1)
      p.stages.add(`velaria_caminho_${c}`)
      p.tell(Text.gold(`Caminho destrancado: ${VO.caminhos[c].nome}.`))
      return 1
    })))

  event.register(Commands.literal('velaria').requires(s => s.hasPermission(2))
    .then(Commands.literal('ordem')
      .then(Commands.argument('alvo', Arguments.PLAYER.create(event))
        .then(Commands.argument('ordem', Arguments.STRING.create(event)).executes(ctx => {
          let alvo = Arguments.PLAYER.getResult(ctx, 'alvo')
          let o = String(Arguments.STRING.getResult(ctx, 'ordem'))
          if (!VO.ordens[o]) { ctx.source.player.tell(`Ordens: ${Object.keys(VO.ordens).join(', ')}`); return 0 }
          Object.keys(VO.ordens).forEach(x => alvo.stages.remove(`velaria_ordem_${x}`))
          alvo.stages.add(`velaria_ordem_${o}`)
          return 1
        }))))
    .then(Commands.literal('caminho')
      .then(Commands.argument('alvo', Arguments.PLAYER.create(event))
        .then(Commands.argument('caminho', Arguments.STRING.create(event)).executes(ctx => {
          let alvo = Arguments.PLAYER.getResult(ctx, 'alvo')
          alvo.stages.add(`velaria_caminho_${Arguments.STRING.getResult(ctx, 'caminho')}`)
          return 1
        })))))
})
