// ============================================================
//  Velária MMORPG — PAINEL DE ADMIN (/painel)
//  Uma tela de baú no lugar dos comandos de teste: Ordem, Graça, Linhagem, Ofício, tier,
//  pontos da árvore, armaduras e atalhos do mundo. Só para op (nível 2).
//  Usa as mesmas funções dos comandos (/provar, /origin, /velaria, /puffish_skills).
// ============================================================

const VPN = {
  ordens: ['guerreiro', 'paladino', 'sacerdote', 'mago', 'ladino', 'arqueiro', 'berserker', 'bruxo', 'druida', 'monge', 'lamina_arcana'],
  gracas: ['espada', 'katana', 'espada_longa', 'adaga', 'lanca', 'martelo', 'machado', 'foice', 'manopla', 'arco', 'besta',
    'cajado_arcano', 'cajado_sagrado', 'natureza', 'sinais', 'nenhuma'],
  linhagens: ['humano', 'anao', 'elfo', 'draconato', 'tritao', 'gigante', 'pequenino', 'vampiro', 'orc', 'feerico', 'forjado', 'salamandrino', 'drow'],
  oficios: ['minerador', 'lenhador', 'ferreiro', 'cozinheiro', 'mercador', 'fazendeiro', 'herbalista', 'criador', 'pescador', 'pedreiro', 'explorador', 'domador', 'errante'],
  bonito: s => s.split('_').map(x => x.charAt(0).toUpperCase() + x.slice(1)).join(' ')
}

function vpnCmd(p, c) { p.server.runCommandSilent(c.replace(/@p/g, p.username)) }
function vpnAbrir(p, f) { p.closeContainer(); p.server.scheduleInTicks(1, () => f(p)) }
function vpnBotao(gui, x, y, item, nome, cor, lore, acao) {
  let s = gui.getSlot(x, y)
  s.setItem(vmItem(item, nome, cor, lore || []))
  if (acao) s.setLeftClicked(acao)
}
function vpnVoltar(gui, p, y) { vpnBotao(gui, 0, y, 'minecraft:arrow', 'Voltar', 'yellow', [], () => vpnAbrir(p, vpnPrincipal)) }

// lista genérica: até 27 opções em 3 linhas, clique aplica e volta ao painel
function vpnLista(p, titulo, ids, icone, nomeDe, aplicar, atual) {
  p.openChestGUI(Text.gold(titulo), 4, gui => {
    ids.forEach((id, k) => {
      let escolhido = id === atual
      vpnBotao(gui, k % 9, Math.floor(k / 9), escolhido ? 'minecraft:lime_dye' : icone(id), nomeDe(id), escolhido ? 'green' : 'white',
        [[escolhido ? 'Atual' : 'Clique para aplicar', escolhido ? 'green' : 'gray']],
        () => { aplicar(id); vpnAbrir(p, vpnPrincipal) })
    })
    vpnVoltar(gui, p, 3)
  })
}

function vpnPrincipal(p) {
  let i = vmInfo(p)
  let VO = i.VO
  p.openChestGUI(Text.gold('Painel da Velária (admin)'), 5, gui => {
    // linha 0: identidade
    vpnBotao(gui, 1, 0, 'minecraft:shield', `Ordem: ${i.ordem && VO ? VO.ordens[i.ordem].nome : 'nenhuma'}`, 'gold',
      [['Troca Ordem, origem do Juramento e árvore', 'gray']],
      () => vpnAbrir(p, q => vpnLista(q, 'Escolha a Ordem', VPN.ordens, o => VO && VO.ordens[o] ? VO.ordens[o].icone : 'minecraft:iron_sword',
        o => VO && VO.ordens[o] ? VO.ordens[o].nome : VPN.bonito(o),
        o => vpnCmd(q, `execute as @p run provar virar ${o}`), i.ordem)))
    vpnBotao(gui, 3, 0, 'minecraft:nether_star', `Graça: ${i.graca && VO ? VO.caminhos[i.graca].deus : 'nenhuma'}`, 'aqua',
      [['Bênção do deus da arma', 'gray']],
      () => vpnAbrir(p, q => vpnLista(q, 'Escolha a Graça', VPN.gracas, g => g === 'nenhuma' ? 'minecraft:glass_bottle' : 'minecraft:nether_star',
        g => VO && VO.caminhos[g] ? `${VO.caminhos[g].nome} (${VO.caminhos[g].deus})` : VPN.bonito(g),
        g => vpnCmd(q, `origin set @p velaria:graca velaria:graca_${g}`), i.graca)))
    vpnBotao(gui, 5, 0, 'minecraft:name_tag', 'Linhagem', 'yellow', [[i.linhagem, 'white']],
      () => vpnAbrir(p, q => vpnLista(q, 'Escolha a Linhagem', VPN.linhagens, () => 'minecraft:name_tag', l => VM.linhagens[`linhagem_${l}`] || VPN.bonito(l),
        l => vpnCmd(q, `origin set @p neoorigins:origin velaria:linhagem_${l}`), null)))
    vpnBotao(gui, 7, 0, 'minecraft:iron_pickaxe', 'Ofício', 'yellow', [[i.oficio, 'white']],
      () => vpnAbrir(p, q => vpnLista(q, 'Escolha o Ofício', VPN.oficios, () => 'minecraft:iron_pickaxe', o => VPN.bonito(o),
        o => vpnCmd(q, `origin set @p neoorigins:class velaria:oficio_${o}`), null)))

    // linha 1: tier
    for (let t = 1; t <= 5; t++) {
      let tt = t
      vpnBotao(gui, 1 + t, 1, t === i.tier ? 'minecraft:lime_concrete' : 'minecraft:gray_concrete', `Tier ${t}`, t === i.tier ? 'green' : 'white',
        [[t === i.tier ? 'Atual' : 'Clique para mudar', 'gray']], () => { vpnCmd(p, `velaria tier @p ${tt}`); vpnAbrir(p, vpnPrincipal) })
    }
    vpnBotao(gui, 0, 1, 'minecraft:compass', 'Tier', 'gold', [['Escolha ao lado →', 'gray']])

    // linha 2: árvore
    vpnBotao(gui, 0, 2, 'minecraft:enchanted_book', 'Árvore da Ordem', 'light_purple', [['Abra com K', 'gray']])
    ;[1, 5, 18].forEach((n, k) => vpnBotao(gui, 2 + k, 2, 'minecraft:experience_bottle', `+${n} ponto(s)`, 'green', [],
      () => { vpnCmd(p, `execute as @p run provar pontos ${n}`); p.closeContainer() }))
    vpnBotao(gui, 6, 2, 'minecraft:tnt', 'Resetar árvore', 'red', [['Devolve os pontos e tira as habilidades', 'gray']],
      () => { if (i.ordem) vpnCmd(p, `puffish_skills category erase @p velaria:ordem_${i.ordem}`); p.closeContainer() })
    vpnBotao(gui, 8, 2, 'minecraft:writable_book', 'Tomos de Técnica', 'gold', [['Devolve os tomos aprendidos', 'gray']],
      () => { vpnCmd(p, 'execute as @p run tecnica'); p.closeContainer() })

    // linha 3: armaduras e teste
    vpnBotao(gui, 1, 3, 'minecraft:armor_stand', 'Armaduras da Ordem', 'gold', [['Clique num conjunto para vestir', 'gray']],
      () => vpnAbrir(p, vpnArmaduras))
    vpnBotao(gui, 3, 3, p.stages.has('velaria_teste') ? 'minecraft:lime_dye' : 'minecraft:gray_dye',
      `Modo teste: ${p.stages.has('velaria_teste') ? 'ligado' : 'desligado'}`, 'yellow', [['Veste e segura itens de qualquer Ordem', 'gray']],
      () => { vpnCmd(p, 'execute as @p run provar modo'); vpnAbrir(p, vpnPrincipal) })
    vpnBotao(gui, 5, 3, 'minecraft:grass_block', p.isCreative() ? 'Modo: criativo' : 'Modo: sobrevivência', 'white', [['Alterna', 'gray']],
      () => { vpnCmd(p, `gamemode ${p.isCreative() ? 'survival' : 'creative'} @p`); vpnAbrir(p, vpnPrincipal) })
    vpnBotao(gui, 7, 3, 'minecraft:golden_apple', 'Curar e saciar', 'green', [],
      () => { vpnCmd(p, 'effect give @p minecraft:instant_health 1 10 true'); vpnCmd(p, 'effect give @p minecraft:saturation 1 10 true'); p.closeContainer() })

    // linha 4: mundo
    vpnBotao(gui, 1, 4, 'minecraft:clock', 'Dia', 'yellow', [], () => { vpnCmd(p, 'time set noon'); p.closeContainer() })
    vpnBotao(gui, 2, 4, 'minecraft:zombie_head', 'Boneco de treino', 'yellow', [['Zumbi parado com 1000 de vida', 'gray'], ['(precisa dificuldade Fácil)', 'dark_gray']],
      () => { vpnCmd(p, `execute at @p run summon minecraft:zombie ^ ^ ^3 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Boneco"',attributes:[{id:"minecraft:generic.max_health",base:1000}],Health:1000f}`); p.closeContainer() })
    vpnBotao(gui, 3, 4, 'minecraft:bone', 'Remover bonecos', 'gray', [], () => { vpnCmd(p, 'kill @e[name=Boneco]'); p.closeContainer() })
    vpnBotao(gui, 5, 4, 'minecraft:iron_sword', 'Dificuldade: Fácil', 'white', [], () => { vpnCmd(p, 'difficulty easy'); p.closeContainer() })
    vpnBotao(gui, 6, 4, 'minecraft:poppy', 'Dificuldade: Pacífico', 'white', [], () => { vpnCmd(p, 'difficulty peaceful'); p.closeContainer() })
    vpnBotao(gui, 7, 4, 'minecraft:lava_bucket', 'Limpar inventário', 'red', [['Apaga tudo do seu inventário', 'gray']],
      () => { vpnCmd(p, 'clear @p'); p.closeContainer() })
    vpnBotao(gui, 8, 4, 'minecraft:barrier', 'Fechar', 'red', [], () => p.closeContainer())
  })
}

function vpnArmaduras(p) {
  let o = VG.velariaOrdem ? VG.velariaOrdem(p) : null
  let lista = (global.VELARIA_ARMADURAS || []).filter(a => !o || a.ordem === o).slice(0, 27)
  p.openChestGUI(Text.gold('Armaduras da Ordem'), 4, gui => {
    lista.forEach((a, k) => {
      vpnBotao(gui, k % 9, Math.floor(k / 9), `kubejs:${a.id}_chestplate`, `${a.nome} T${a.tier}`, 'gold',
        [[vpvLinha(a), 'gray'], ['Clique para vestir', 'yellow']],
        () => { vpnCmd(p, `execute as @p run provar vestir ${a.id}`); p.closeContainer() })
    })
    vpnVoltar(gui, p, 3)
  })
}

ServerEvents.commandRegistry(event => {
  let { commands: Commands } = event
  event.register(Commands.literal('painel').requires(s => s.hasPermission(2)).executes(ctx => {
    let p = ctx.source.player
    try { vpnPrincipal(p) } catch (e) { p.tell(Text.red(`Painel indisponível: ${e}`)) }
    return 1
  }))
})
