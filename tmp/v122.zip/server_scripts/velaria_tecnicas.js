// Velária — Técnicas das Ordens (gerado por tools/gen_arvores.py; não edite à mão)
// Receita: Tomo de Técnica + ingredientes → consumível. O tomo volta para a grade (keepIngredient).
// Uso: clique direito aplica os efeitos. /tecnica devolve o tomo a quem já aprendeu (perdeu, morreu...).
ServerEvents.recipes(event => {
  Object.keys(global.VELARIA_TECNICAS).forEach(o => {
    let t = global.VELARIA_TECNICAS[o]
    let r = event.shapeless(Item.of(`kubejs:${t.consumivel}`, t.qtd), [`kubejs:tecnica_${o}`].concat(t.receita))
      .id(`velaria:tecnica/${t.consumivel}`)
    try { r.keepIngredient(`kubejs:tecnica_${o}`) } catch (e) {
      console.warn(`[Velária] keepIngredient indisponível (${e}); o tomo de ${o} será consumido`)
    }
  })
})

Object.keys(global.VELARIA_TECNICAS).forEach(o => {
  let t = global.VELARIA_TECNICAS[o]
  ItemEvents.rightClicked(`kubejs:${t.consumivel}`, event => {
    let p = event.player
    t.efeitos.forEach(e => p.potionEffects.add(e[0], Math.max(1, e[1]) * 20, e[2]))
    if (!p.isCreative()) event.item.count--
    p.level.playSound(null, p.x, p.y, p.z, 'minecraft:entity.generic.drink', 'players', 0.8, 1.1)
    event.cancel()
  })
})

ServerEvents.commandRegistry(event => {
  let { commands: Commands } = event
  event.register(Commands.literal('tecnica').executes(ctx => {
    let p = ctx.source.player
    let n = 0
    Object.keys(global.VELARIA_TECNICAS).forEach(o => {
      if (p.stages.has(`velaria_tecnica_${o}`) && !p.inventory.hasAnyMatching(s => String(s.id) === `kubejs:tecnica_${o}`)) {
        p.give(Item.of(`kubejs:tecnica_${o}`)); n++
      }
    })
    p.tell(n ? Text.green(`${n} tomo(s) de técnica devolvido(s).`) : Text.gray('Nenhum tomo para devolver.'))
    return 1
  }))
})
