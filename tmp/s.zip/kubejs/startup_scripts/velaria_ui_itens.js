// Velária — itens e bloco dos menus (Diário do Desperto e Mural de Procurados)
// Pasta: kubejs/startup_scripts/ (precisa REINICIAR o jogo)
StartupEvents.registry('block', event => {
  event.create('mural_procurados', 'cardinal')
    .displayName('Mural de Procurados')
    .soundType('wood')
    .hardness(2)
    .resistance(6)
    .tagBlock('minecraft:mineable/axe')
    // textura padrão: kubejs:block/mural_procurados
})

StartupEvents.registry('item', event => {
  event.create('diario_desperto')
    .displayName('Diário do Desperto')
    .maxStackSize(1)
    .tooltip(Text.gray('Clique com o botão direito: Ordem, Graça, honra, tier e procurados.'))
})
