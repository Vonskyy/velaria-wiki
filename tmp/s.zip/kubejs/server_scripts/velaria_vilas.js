// ============================================================
//  Velária MMORPG — VILAS POR NÍVEL + HONRA NO COMÉRCIO
//  Pasta: kubejs/server_scripts/  (recarrega com /reload)
//  Ainda NÃO testado em jogo. Usa a API Java do Minecraft para ofertas e fofocas dos aldeões;
//  se algo mudar na versão, o log avisa e só essa parte desliga.
//
//  Nível da vila = distância do spawn / 80 (1 a 125). Vila a 8.000 blocos = nível 100.
//  - Aldeões, golens e guardas ficam mais fortes conforme o nível.
//  - Aldeões com profissão ganham ofertas extras, pagas em moedas do Lightman's Currency:
//      Nv 20+  compram lingotes dos tiers 1 e 2
//      Nv 40+  vendem Contrato de Caça tier 2
//      Nv 60+  compram troféus de Elite tier 3; vendem o Tomo do Destino
//      Nv 80+  vendem a Carta de Perdão; compram troféus tier 4
//      Nv 100+ vendem a WAYSTONE (única forma de comprar uma)
//      Nv 120+ compram troféus tier 5
//  - Honra (velaria_honra.js): Infame e Procurado não negociam; Suspeito encarece;
//    Honrado e Herói barateiam.
// ============================================================

const VV = {
  centro: { x: 0, z: 0 },           // mesmo centro do velaria_progressao.js
  blocosPorNivel: 80,
  nivelMax: 125,
  fortes: ['minecraft:villager', 'minecraft:iron_golem', 'guardvillagers:guard'],
  ofertas: [
    { nivel: 20, custo: ['kubejs:estanho_ingot', 8], paga: ['lightmanscurrency:coin_iron', 6], usos: 8 },
    { nivel: 20, custo: ['kubejs:mitril_ingot', 4], paga: ['lightmanscurrency:coin_gold', 1], usos: 8 },
    { nivel: 40, custo: ['lightmanscurrency:coin_gold', 3], paga: ['kubejs:contrato_caca_t2', 1], usos: 3 },
    { nivel: 60, custo: ['kubejs:trofeu_elite_t3', 1], paga: ['lightmanscurrency:coin_emerald', 2], usos: 4 },
    { nivel: 60, custo: ['lightmanscurrency:coin_emerald', 5], paga: ['kubejs:tomo_destino', 1], usos: 1 },
    { nivel: 80, custo: ['lightmanscurrency:coin_emerald', 3], paga: ['kubejs:carta_perdao', 1], usos: 2 },
    { nivel: 80, custo: ['kubejs:trofeu_elite_t4', 1], paga: ['lightmanscurrency:coin_diamond', 1], usos: 4 },
    { nivel: 100, custo: ['lightmanscurrency:coin_netherite', 2], custo2: ['lightmanscurrency:coin_diamond', 5],
      paga: ['waystones:waystone', 1], usos: 1 },
    { nivel: 120, custo: ['kubejs:trofeu_elite_t5', 1], paga: ['lightmanscurrency:coin_diamond', 3], usos: 4 }
  ]
}

function vvNivel(e) {
  if (String(e.level.dimension) !== 'minecraft:overworld') return 1
  let dx = e.x - VV.centro.x, dz = e.z - VV.centro.z
  return Math.max(1, Math.min(VV.nivelMax, Math.floor(Math.sqrt(dx * dx + dz * dz) / VV.blocosPorNivel)))
}

// ---------- Moradores mais fortes longe do spawn ----------
EntityEvents.spawned(event => {
  let e = event.entity
  if (VV.fortes.indexOf(String(e.type)) < 0) return
  if (e.tags.contains('velaria_nivelado')) return
  e.addTag('velaria_nivelado')
  let nivel = vvNivel(e)
  e.persistentData.putInt('velaria_nivel', nivel)
  if (nivel < 10) return
  let server = e.server
  server.scheduleInTicks(5, () => {
    let uuid = String(e.uuid)
    if (String(e.type) === 'minecraft:villager') {
      server.runCommandSilent(`attribute ${uuid} minecraft:generic.max_health base set ${20 + Math.round(nivel * 0.6)}`)
      server.runCommandSilent(`attribute ${uuid} minecraft:generic.armor base set ${Math.floor(nivel / 10)}`)
    } else {
      let m = 1 + nivel / 100
      server.runCommandSilent(`attribute ${uuid} minecraft:generic.max_health modifier add velaria:vila ${m - 1} add_multiplied_base`)
      server.runCommandSilent(`attribute ${uuid} minecraft:generic.attack_damage modifier add velaria:vila ${(m - 1) / 1.5} add_multiplied_base`)
    }
    e.health = e.maxHealth
  })
})

// ---------- Java: ofertas e fofocas ----------
let vvJava = null
try {
  vvJava = {
    Offer: Java.loadClass('net.minecraft.world.item.trading.MerchantOffer'),
    Cost: Java.loadClass('net.minecraft.world.item.trading.ItemCost'),
    Optional: Java.loadClass('java.util.Optional'),
    Gossip: Java.loadClass('net.minecraft.world.entity.ai.gossip.GossipType')
  }
} catch (err) {
  console.warn(`[Velária] Ofertas e fofocas de aldeão desligadas: ${err}`)
}

function vvCusto(par) {
  let it = Item.of(par[0])
  if (it.isEmpty()) return null
  return new vvJava.Cost(it.item, par[1])
}

function vvOfertasExtras(v, nivel) {
  if (!vvJava || v.persistentData.getBoolean('velaria_ofertas')) return
  let prof = String(v.villagerData.profession)
  if (prof.indexOf('none') >= 0 || prof.indexOf('nitwit') >= 0) return
  v.persistentData.putBoolean('velaria_ofertas', true)
  let lista = v.getOffers()
  VV.ofertas.forEach(o => {
    if (nivel < o.nivel) return
    let a = vvCusto(o.custo)
    let res = Item.of(o.paga[0], o.paga[1])
    if (!a || res.isEmpty()) return
    let b = o.custo2 ? vvCusto(o.custo2) : null
    lista.add(new vvJava.Offer(a, b ? vvJava.Optional.of(b) : vvJava.Optional.empty(), res, o.usos, 10, 0.05))
  })
}

function vvFofoca(v, p, faixa) {
  if (!vvJava) return
  try {
    if (faixa === 'suspeito') v.getGossips().add(p.uuid, vvJava.Gossip.MINOR_NEGATIVE, 15)
    else if (faixa === 'honrado' || faixa === 'heroi') v.getGossips().add(p.uuid, vvJava.Gossip.MINOR_POSITIVE, 10)
  } catch (err) { /* ignora */ }
}

ItemEvents.entityInteracted(event => {
  let v = event.target
  let tipo = String(v.type)
  if (tipo !== 'minecraft:villager' && tipo !== 'minecraft:wandering_trader') return
  let p = event.player
  let faixa = VG.velariaFaixaHonra ? VG.velariaFaixaHonra(p) : 'neutro'
  if (!p.isCreative() && (faixa === 'infame' || faixa === 'procurado')) {
    p.displayClientMessage(Text.red('O aldeão vira o rosto: "Não negocio com gente da sua laia."'), true)
    event.cancel()
    return
  }
  vvFofoca(v, p, faixa)
  if (tipo === 'minecraft:villager') {
    let nivel = v.persistentData.getInt('velaria_nivel') || vvNivel(v)
    p.displayClientMessage(Text.gold(`Aldeão de vila nível ${nivel}`), true)
    try { vvOfertasExtras(v, nivel) } catch (err) { console.warn(`[Velária] Oferta extra falhou: ${err}`) }
  }
})
