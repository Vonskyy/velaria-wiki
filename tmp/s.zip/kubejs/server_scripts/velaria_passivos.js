// ============================================================
//  Velária MMORPG — EFEITOS PASSIVOS DOS CONJUNTOS (1.1.28)
//  Conjunto completo (4 peças do mesmo id) da Ordem dá um efeito leve e contínuo.
//  Linha de Defesa (Guardiã): sobrevivência. Linha de Ataque: agressão/mobilidade.
// ============================================================
const VPS = {
  // ordem: [efeito da Defesa, efeito do Ataque]  (nível 0 = I)
  guerreiro: ['minecraft:resistance', 'minecraft:strength'],
  paladino: ['minecraft:resistance', 'minecraft:strength'],
  berserker: ['minecraft:resistance', 'minecraft:strength'],
  ladino: ['minecraft:speed', 'minecraft:haste'],
  arqueiro: ['minecraft:speed', 'minecraft:jump_boost'],
  bruxo: ['minecraft:regeneration', 'minecraft:haste'],
  monge: ['minecraft:regeneration', 'minecraft:speed'],
  lamina_arcana: ['minecraft:resistance', 'minecraft:haste'],
  sacerdote: ['minecraft:regeneration', 'minecraft:haste'],
  mago: ['minecraft:resistance', 'minecraft:night_vision'],
  druida: ['minecraft:regeneration', 'minecraft:speed']
}
let VPS_MAPA = null
function vpsMapa() {
  if (VPS_MAPA) return VPS_MAPA
  VPS_MAPA = {}
  ;(global.VELARIA_ARMADURAS || []).forEach(a => { VPS_MAPA[a.id] = a })
  return VPS_MAPA
}
ServerEvents.tick(ev => {
  if (ev.server.tickCount % 40 !== 0) return
  ev.server.players.forEach(p => {
    try {
      let ids = ['head', 'chest', 'legs', 'feet'].map(s => String(p.getItemBySlot(s).id))
      let m = ids[0].match(/^kubejs:(.+)_helmet$/)
      if (!m) return
      let set = m[1]
      if (ids[1] !== `kubejs:${set}_chestplate` || ids[2] !== `kubejs:${set}_leggings` || ids[3] !== `kubejs:${set}_boots`) return
      let a = vpsMapa()[set]
      if (!a || !VPS[a.ordem]) return
      let ef = VPS[a.ordem][a.estilo === 'b' ? 1 : 0]
      let nivel = a.tier >= 5 ? 1 : 0
      p.potionEffects.add(ef, 60, nivel, true, false)
    } catch (e) { }
  })
})
