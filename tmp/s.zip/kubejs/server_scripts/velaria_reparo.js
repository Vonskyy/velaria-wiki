// Velária — tags de reparo das ferramentas do kit (usadas em mmo_conteudo.js: #velaria:reparo/<material>)
ServerEvents.tags('item', event => {
  (global.VELARIA_FERRAMENTAS || []).forEach(f => event.add(`velaria:reparo/${f.id}`, f.repair))
})
