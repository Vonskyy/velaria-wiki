// Velária — FTB Ultimine: nunca em madeira (o Profet's Timber cuida das árvores)
// Tags do FTB Ultimine: ftbultimine:excluded_blocks (bloqueia) e ftbultimine:block_whitelist (se não vazia, só esses)
// Limite global de blocos fica em world/serverconfig/ftbultimine-server.snbt (max_blocks).
// Tiers por jogador (8/16/32/64/128) exigem FTB Ranks — ver LEIA-ME.

ServerEvents.tags('block', event => {
  event.add('ftbultimine:excluded_blocks', [
    '#minecraft:logs',
    '#minecraft:leaves',
    '#minecraft:planks',
    '#minecraft:wooden_slabs',
    '#minecraft:wooden_stairs',
    '#minecraft:wooden_fences',
    '#minecraft:wooden_doors',
    '#minecraft:wooden_trapdoors'
  ])
})
