// ============================================================
//  Velária MMORPG — FORJA (Overgeared)
//  1) Bigorna Estelar: material do tier 5 só é forjado na Bigorna Dracônica (Tier B) posta
//     em cima de uma Base Estelar.
//  2) Armas e armaduras de metal dos outros mods (Epic Knights e addons, Immersive Armors,
//     Fantasy Armor, Samurai Dynasty, Simply Swords, mods de classe...) saem da bancada e
//     passam a ser forjadas na bigorna, com qualidade. A bigorna exigida vem do material:
//     cobre/bronze/ouro = pedra, ferro/aço/diamante = ferreiro, netherite = fornalha,
//     aço de dragão = dracônica.
//  GERADO por tools/build_v5.py
// ============================================================

const VF = {
  t5: ["kubejs:aco_estelar_ingot", "kubejs:alva_estrela_ingot", "kubejs:cometa_ingot", "kubejs:eclipse_lupino_ingot", "kubejs:eclipsita_ingot", "kubejs:estelita_ingot", "kubejs:jade_celestial_ingot", "kubejs:seiva_estelar_ingot", "kubejs:supernova_ingot", "kubejs:vacuita_ingot", "kubejs:vazio_velado_ingot"],
  mods: /^(magistuarmory|slavicarmory|epic_knights[a-z_]*|antiquelegacy|immersive_armors|fantasy_armor|samurai_dynasty|simplyswords|paladins|rogues|berserker_rpg|witcher_rpg|forcemaster_rpg|spellblades[a-z_]*|armory|arsenal|iceandfire):/,
  equipamento: /(helmet|chestplate|leggings|boots|helm|cuirass|hauberk|greaves|sabatons|gauntlet|armet|bascinet|barbute|sallet|kabuto|sword|blade|katana|claymore|axe|hammer|mace|spear|lance|halberd|glaive|dagger|knife|sickle|scythe|rapier|saber|sabre|flail|pike|naginata|odachi|tanto|wakizashi|kanabo|club|cleaver|knuckle|gauntlets|shield)/,
  fora: /(robe|hood|_hat|staff|wand|bow|tome|book|scroll|rune|cloth|wool|leather|silk|paper|banner|hilt|handle|_head$|template|upgrade|pattern|surcoat|cape|cloak|wood|bone|straw|paper|feather|turtle|slime)/,
  bigorna: [[/dragonsteel|dragon_steel/, 'above_b', 6], [/netherite/, 'above_a', 5],
            [/copper|bronze|tin_|stone|wood|gold/, 'stone', 3]],
  padrao: ['iron', 4]
}

// ---------- 1) Bigorna Estelar ----------
BlockEvents.rightClicked('overgeared:tier_b_smithing_anvil', event => {
  let p = event.player
  if (!p || !event.item.hasTag('overgeared:smithing_hammers')) return
  if (String(event.block.down.id) === 'kubejs:base_estelar') return
  let dados = ''
  try { dados = String(event.block.entityData) } catch (e) { return }
  if (VF.t5.some(id => dados.indexOf(id) >= 0)) {
    p.displayClientMessage(Text.red('Material do tier 5: a Bigorna Dracônica precisa estar em cima de uma Base Estelar.'), true)
    event.cancel()
  }
})

// ---------- 2) Equipamento dos outros mods na bigorna ----------
ServerEvents.recipes(event => {
  let novas = []
  try {
    event.forEachRecipe({ type: 'minecraft:crafting_shaped' }, r => {
      let saida = ''
      try { saida = String(r.getOriginalRecipeResult().id) } catch (e) { return }
      if (!VF.mods.test(saida)) return
      let nome = saida.substring(saida.indexOf(':') + 1)
      if (!VF.equipamento.test(nome) || VF.fora.test(nome)) return
      let j
      try { j = JSON.parse(String(r.json)) } catch (e) { return }
      if (!j.pattern || !j.key) return
      let texto = JSON.stringify(j.key) + nome
      let bigorna = VF.padrao
      for (let i = 0; i < VF.bigorna.length; i++) if (VF.bigorna[i][0].test(texto)) { bigorna = [VF.bigorna[i][1], VF.bigorna[i][2]]; break }
      let chave = {}
      Object.keys(j.key).forEach(k => { const v = j.key[k]; chave[k] = Array.isArray(v) ? v[0] : v })
      let res = j.result || {}
      novas.push({ id: String(r.getId()), json: {
        type: 'overgeared:forging', category: /helm|chest|legg|boots|cuirass|hauberk|greaves|sabatons|armet|bascinet|barbute|sallet|kabuto/.test(nome) ? 'ARMORS' : 'misc',
        hammering: bigorna[1], tier: bigorna[0], pattern: j.pattern, key: chave,
        result: { id: res.id || res.item || saida, count: res.count || 1 },
        has_quality: true, needs_minigame: true, show_notification: false } })
    })
  } catch (e) {
    console.warn(`[Velária] Forja: não deu para ler as receitas dos mods (${e})`)
    return
  }
  novas.forEach(n => {
    try {
      event.remove({ id: n.id })
      event.custom(n.json).id(`${n.id.replace(':', '_')}_forja`.replace(/^/, 'velaria:forja/'))
    } catch (e) {
      console.warn(`[Velária] Forja: ${n.id} falhou (${e})`)
    }
  })
  console.info(`[Velária] Forja: ${novas.length} receitas de armas e armaduras de mods passaram para a bigorna`)
})
