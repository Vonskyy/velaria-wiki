// ============================================================
//  Velária MMORPG — CONTRATOS
//  Pasta: kubejs/server_scripts/  (recarrega com /reload)
//  Dados GERADOS por tools/build_mundo4.py. Ainda NÃO testado em jogo.
//
//  Os contratos são itens. O Mercante (banca do Lightman's Currency em Porto Alvorada)
//  e os aldeões de nível alto vendem os contratos; o jogador cumpre e recebe o pagamento.
//  - Coleta: junte os itens, clique com o botão direito segurando o contrato.
//  - Encomenda da Ordem: igual, mas só a própria Ordem cumpre; paga Insígnias da Ordem.
//  - Caça: mate uma Elite do tier do contrato (ou maior) com ele no inventário.
//  - Chefe Lendário: esteja presente na morte de um chefe de tier.
// ============================================================

const VCT = {
 "entrega": {
  "contrato_lenhador": {
   "nome": "Contrato do Lenhador",
   "pede": [
    [
     "#minecraft:logs",
     64,
     "toras"
    ]
   ],
   "paga": [
    [
     "lightmanscurrency:coin_gold",
     3
    ]
   ],
   "honra": 2,
   "tier": 1,
   "ordem": null
  },
  "contrato_fazendeiro": {
   "nome": "Contrato do Fazendeiro",
   "pede": [
    [
     "minecraft:wheat",
     64,
     "trigo"
    ]
   ],
   "paga": [
    [
     "lightmanscurrency:coin_gold",
     2
    ]
   ],
   "honra": 2,
   "tier": 1,
   "ordem": null
  },
  "contrato_pescador": {
   "nome": "Contrato do Pescador",
   "pede": [
    [
     "#minecraft:fishes",
     16,
     "peixes"
    ]
   ],
   "paga": [
    [
     "lightmanscurrency:coin_gold",
     2
    ]
   ],
   "honra": 2,
   "tier": 1,
   "ordem": null
  },
  "contrato_cacador": {
   "nome": "Contrato do Caçador",
   "pede": [
    [
     "minecraft:leather",
     16,
     "couros"
    ]
   ],
   "paga": [
    [
     "lightmanscurrency:coin_gold",
     2
    ]
   ],
   "honra": 2,
   "tier": 1,
   "ordem": null
  },
  "contrato_minerador": {
   "nome": "Contrato do Minerador",
   "pede": [
    [
     "minecraft:raw_iron",
     32,
     "ferro bruto"
    ]
   ],
   "paga": [
    [
     "lightmanscurrency:coin_gold",
     4
    ]
   ],
   "honra": 2,
   "tier": 1,
   "ordem": null
  },
  "contrato_minerador_profundo": {
   "nome": "Contrato da Mina Profunda",
   "pede": [
    [
     "kubejs:mitril_ingot",
     16,
     "lingotes de mitril"
    ]
   ],
   "paga": [
    [
     "lightmanscurrency:coin_emerald",
     2
    ]
   ],
   "honra": 3,
   "tier": 2,
   "ordem": null
  },
  "contrato_joalheiro": {
   "nome": "Contrato do Joalheiro",
   "pede": [
    [
     "kubejs:onix",
     8,
     "ônix"
    ]
   ],
   "paga": [
    [
     "lightmanscurrency:coin_emerald",
     2
    ]
   ],
   "honra": 3,
   "tier": 2,
   "ordem": null
  },
  "contrato_alquimista": {
   "nome": "Contrato do Alquimista",
   "pede": [
    [
     "minecraft:nether_wart",
     32,
     "verrugas"
    ]
   ],
   "paga": [
    [
     "lightmanscurrency:coin_emerald",
     2
    ]
   ],
   "honra": 3,
   "tier": 3,
   "ordem": null
  },
  "contrato_fundicao": {
   "nome": "Contrato da Grande Fundição",
   "pede": [
    [
     "kubejs:adamantita_ingot",
     8,
     "lingotes de adamantita"
    ]
   ],
   "paga": [
    [
     "lightmanscurrency:coin_diamond",
     1
    ]
   ],
   "honra": 4,
   "tier": 3,
   "ordem": null
  },
  "contrato_abismo": {
   "nome": "Contrato do Abismo",
   "pede": [
    [
     "minecraft:echo_shard",
     4,
     "fragmentos de eco"
    ]
   ],
   "paga": [
    [
     "lightmanscurrency:coin_diamond",
     2
    ]
   ],
   "honra": 4,
   "tier": 4,
   "ordem": null
  },
  "contrato_estrela": {
   "nome": "Contrato da Estrela Partida",
   "pede": [
    [
     "kubejs:estelita",
     4,
     "estelitas"
    ]
   ],
   "paga": [
    [
     "lightmanscurrency:coin_netherite",
     1
    ]
   ],
   "honra": 5,
   "tier": 5,
   "ordem": null
  },
  "encomenda_guerreiro": {
   "nome": "Encomenda da Legião de Ferro",
   "pede": [
    [
     "minecraft:iron_ingot",
     16,
     "lingotes de ferro"
    ]
   ],
   "paga": [
    [
     "kubejs:insignia_guerreiro",
     3
    ],
    [
     "lightmanscurrency:coin_gold",
     1
    ]
   ],
   "honra": 1,
   "tier": 1,
   "ordem": "guerreiro"
  },
  "encomenda_paladino": {
   "nome": "Encomenda da Ordem da Aurora",
   "pede": [
    [
     "minecraft:gold_ingot",
     12,
     "lingotes de ouro"
    ]
   ],
   "paga": [
    [
     "kubejs:insignia_paladino",
     3
    ],
    [
     "lightmanscurrency:coin_gold",
     1
    ]
   ],
   "honra": 1,
   "tier": 1,
   "ordem": "paladino"
  },
  "encomenda_sacerdote": {
   "nome": "Encomenda da Chama Branca",
   "pede": [
    [
     "minecraft:golden_carrot",
     8,
     "cenouras douradas"
    ]
   ],
   "paga": [
    [
     "kubejs:insignia_sacerdote",
     3
    ],
    [
     "lightmanscurrency:coin_gold",
     1
    ]
   ],
   "honra": 1,
   "tier": 1,
   "ordem": "sacerdote"
  },
  "encomenda_mago": {
   "nome": "Encomenda da Círculo Arcano",
   "pede": [
    [
     "minecraft:lapis_lazuli",
     32,
     "lápis-lazúli"
    ]
   ],
   "paga": [
    [
     "kubejs:insignia_mago",
     3
    ],
    [
     "lightmanscurrency:coin_gold",
     1
    ]
   ],
   "honra": 1,
   "tier": 1,
   "ordem": "mago"
  },
  "encomenda_ladino": {
   "nome": "Encomenda da Irmandade do Véu",
   "pede": [
    [
     "minecraft:spider_eye",
     16,
     "olhos de aranha"
    ]
   ],
   "paga": [
    [
     "kubejs:insignia_ladino",
     3
    ],
    [
     "lightmanscurrency:coin_gold",
     1
    ]
   ],
   "honra": 1,
   "tier": 1,
   "ordem": "ladino"
  },
  "encomenda_arqueiro": {
   "nome": "Encomenda da Patrulheiros do Vento",
   "pede": [
    [
     "minecraft:feather",
     32,
     "penas"
    ]
   ],
   "paga": [
    [
     "kubejs:insignia_arqueiro",
     3
    ],
    [
     "lightmanscurrency:coin_gold",
     1
    ]
   ],
   "honra": 1,
   "tier": 1,
   "ordem": "arqueiro"
  },
  "encomenda_berserker": {
   "nome": "Encomenda da Clã da Fúria",
   "pede": [
    [
     "minecraft:bone",
     24,
     "ossos"
    ]
   ],
   "paga": [
    [
     "kubejs:insignia_berserker",
     3
    ],
    [
     "lightmanscurrency:coin_gold",
     1
    ]
   ],
   "honra": 1,
   "tier": 1,
   "ordem": "berserker"
  },
  "encomenda_bruxo": {
   "nome": "Encomenda da Escola do Lobo",
   "pede": [
    [
     "minecraft:redstone",
     24,
     "redstone"
    ]
   ],
   "paga": [
    [
     "kubejs:insignia_bruxo",
     3
    ],
    [
     "lightmanscurrency:coin_gold",
     1
    ]
   ],
   "honra": 1,
   "tier": 1,
   "ordem": "bruxo"
  },
  "encomenda_druida": {
   "nome": "Encomenda da Círculo do Carvalho",
   "pede": [
    [
     "#minecraft:saplings",
     32,
     "mudas"
    ]
   ],
   "paga": [
    [
     "kubejs:insignia_druida",
     3
    ],
    [
     "lightmanscurrency:coin_gold",
     1
    ]
   ],
   "honra": 1,
   "tier": 1,
   "ordem": "druida"
  },
  "encomenda_monge": {
   "nome": "Encomenda da Mosteiro do Punho",
   "pede": [
    [
     "minecraft:bamboo",
     48,
     "bambus"
    ]
   ],
   "paga": [
    [
     "kubejs:insignia_monge",
     3
    ],
    [
     "lightmanscurrency:coin_gold",
     1
    ]
   ],
   "honra": 1,
   "tier": 1,
   "ordem": "monge"
  },
  "encomenda_lamina_arcana": {
   "nome": "Encomenda da Lâminas do Crepúsculo",
   "pede": [
    [
     "minecraft:amethyst_shard",
     16,
     "fragmentos de ametista"
    ]
   ],
   "paga": [
    [
     "kubejs:insignia_lamina_arcana",
     3
    ],
    [
     "lightmanscurrency:coin_gold",
     1
    ]
   ],
   "honra": 1,
   "tier": 1,
   "ordem": "lamina_arcana"
  }
 },
 "caca": {
  "contrato_caca_t1": {
   "nome": "Contrato de Caça — Elite Tier 1",
   "paga": [
    [
     "lightmanscurrency:coin_gold",
     6
    ]
   ],
   "honra": 3
  },
  "contrato_caca_t2": {
   "nome": "Contrato de Caça — Elite Tier 2",
   "paga": [
    [
     "lightmanscurrency:coin_emerald",
     1
    ]
   ],
   "honra": 4
  },
  "contrato_caca_t3": {
   "nome": "Contrato de Caça — Elite Tier 3",
   "paga": [
    [
     "lightmanscurrency:coin_emerald",
     3
    ]
   ],
   "honra": 5
  },
  "contrato_caca_t4": {
   "nome": "Contrato de Caça — Elite Tier 4",
   "paga": [
    [
     "lightmanscurrency:coin_diamond",
     1
    ]
   ],
   "honra": 6
  },
  "contrato_caca_t5": {
   "nome": "Contrato de Caça — Elite Tier 5",
   "paga": [
    [
     "lightmanscurrency:coin_diamond",
     3
    ]
   ],
   "honra": 7
  }
 },
 "chefe": {
  "paga": [
   [
    "lightmanscurrency:coin_diamond",
    3
   ]
  ],
  "honra": 6
 }
}

function vcConta(p, ref) {
  let n = 0
  for (let i = 0; i < p.inventory.getContainerSize(); i++) {
    let st = p.inventory.getItem(i)
    if (st.isEmpty() || String(st.id).indexOf('kubejs:contrato') === 0 || String(st.id).indexOf('kubejs:encomenda') === 0) continue
    if (ref.charAt(0) === '#' ? st.hasTag(ref.substring(1)) : String(st.id) === ref) n += st.count
  }
  return n
}

function vcTira(p, ref, qtd) {
  for (let i = 0; i < p.inventory.getContainerSize() && qtd > 0; i++) {
    let st = p.inventory.getItem(i)
    if (st.isEmpty()) continue
    if (!(ref.charAt(0) === '#' ? st.hasTag(ref.substring(1)) : String(st.id) === ref)) continue
    let tira = Math.min(qtd, st.count)
    st.shrink(tira)
    qtd -= tira
  }
}

function vcPaga(p, lista) {
  lista.forEach(it => p.server.runCommandSilent(`give ${p.username} ${it[0]} ${it[1]}`))
}

function vcCumprir(p, item, c) {
  let tier = VG.velariaTier ? VG.velariaTier(p) : 1
  if (tier < c.tier) { p.tell(Text.red(`Este contrato é para quem está no tier ${c.tier} ou acima.`)); return }
  if (c.ordem && (!VG.velariaOrdem || VG.velariaOrdem(p) !== c.ordem)) {
    p.tell(Text.red('Só membros desta Ordem cumprem esta encomenda.')); return
  }
  let faltam = c.pede.filter(x => vcConta(p, x[0]) < x[1])
  if (faltam.length) {
    p.tell(Text.yellow('Faltam: ' + faltam.map(x => `${x[1] - vcConta(p, x[0])} ${x[2]}`).join(', ')))
    return
  }
  c.pede.forEach(x => vcTira(p, x[0], x[1]))
  vcPaga(p, c.paga)
  if (!p.isCreative()) item.shrink(1)
  p.tell(Text.gold(`${c.nome} cumprido.`))
  if (VG.velariaHonra) VG.velariaHonra(p, c.honra, 'contrato cumprido')
}

Object.keys(VCT.entrega).forEach(id => {
  ItemEvents.rightClicked(`kubejs:${id}`, event => vcCumprir(event.player, event.item, VCT.entrega[id]))
})

// Chamado por velaria_elites.js quando uma Elite morre com o jogador presente
VG.velariaContratoCaca = function (p, tierElite) {
  for (let t = Math.min(5, tierElite); t >= 1; t--) {
    let id = `kubejs:contrato_caca_t${t}`
    for (let i = 0; i < p.inventory.getContainerSize(); i++) {
      let st = p.inventory.getItem(i)
      if (String(st.id) !== id) continue
      st.shrink(1)
      let c = VCT.caca[`contrato_caca_t${t}`]
      vcPaga(p, c.paga)
      p.tell(Text.gold(`${c.nome} cumprido.`))
      if (VG.velariaHonra) VG.velariaHonra(p, c.honra, 'caça cumprida')
      return
    }
  }
}

// Chamado por velaria_progressao.js na morte de um chefe de tier
VG.velariaContratoChefe = function (p) {
  for (let i = 0; i < p.inventory.getContainerSize(); i++) {
    let st = p.inventory.getItem(i)
    if (String(st.id) !== 'kubejs:contrato_chefe') continue
    st.shrink(1)
    vcPaga(p, VCT.chefe.paga)
    p.tell(Text.gold('Contrato do Chefe Lendário cumprido.'))
    if (VG.velariaHonra) VG.velariaHonra(p, VCT.chefe.honra, 'chefe lendário')
    return
  }
}
