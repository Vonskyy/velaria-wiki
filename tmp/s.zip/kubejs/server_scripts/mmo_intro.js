// ============================================================
//  Velária MMORPG — introdução de lore no PRIMEIRO login
//  Pasta: kubejs/server_scripts/
//  Mostra um título na tela e conta o começo da história no chat.
//  Para testar de novo: /kubejs stages remove @s velaria_intro
// ============================================================

PlayerEvents.loggedIn(event => {
  let player = event.player
  if (player.stages.has('velaria_intro')) return
  player.stages.add('velaria_intro')

  let nome = player.username
  let server = event.server

  // Espera 3 s para o jogador terminar de carregar o mundo.
  server.scheduleInTicks(60, () => {
    server.runCommandSilent(`title ${nome} times 20 120 40`)
    server.runCommandSilent(`title ${nome} subtitle {"text":"O Silêncio de Mil Anos terminou.","color":"gray","italic":true}`)
    server.runCommandSilent(`title ${nome} title {"text":"VELÁRIA","color":"gold","bold":true}`)
  })

  server.scheduleInTicks(200, () => {
    server.runCommandSilent(`give ${nome} kubejs:diario_desperto 1`)
    player.tell(Text.gold('— Desperto —'))
    player.tell(Text.gray('Você abre os olhos no cais de Porto Alvorada, sem lembrar do próprio nome.'))
    player.tell(Text.gray('Mil anos atrás, a Estrela Partida caiu sobre Velária e o mundo se calou.'))
    player.tell(Text.gray('Agora os dragões voltaram a voar, e as Ordens procuram quem desperta.'))
    player.tell(Text.yellow('Crie seu personagem na tela que se abriu: Linhagem (com seu Ofício), Ordem e a Graça de um deus.'))
    player.tell(Text.yellow('Depois, procure o Mercante de Contratos na praça central. Abra o Diário do Desperto (botão direito) ou use /menu.'))
  })
})
