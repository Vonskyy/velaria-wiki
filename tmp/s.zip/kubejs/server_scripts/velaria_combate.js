// ============================================================
//  Velária — COMBATE PvP E DESLOGAR EM LUTA (substitui o CombatLogX, que não carrega no NeoForge)
//  - Bater ou apanhar de outro jogador marca os dois "em combate" por 15 s.
//  - Quem sai do jogo em combate morre na hora (larga os itens) e o servidor avisa.
//  - Barra de ação mostra a contagem. Admins (op 2) ficam de fora.
// ============================================================

const VCB = { segundos: 15 }

function vcbMarcar(p) {
  if (!p || !p.isPlayer() || p.isCreative() || p.isSpectator()) return
  let fim = p.server.tickCount + VCB.segundos * 20
  if (!p.persistentData.contains('velaria_combate') || p.server.tickCount >= p.persistentData.getInt('velaria_combate')) {
    p.displayClientMessage(Text.red(`⚔ Em combate: não saia do jogo (${VCB.segundos}s)`), true)
  }
  p.persistentData.putInt('velaria_combate', fim)
}

function vcbEmCombate(p) {
  return p.persistentData.contains('velaria_combate') && p.server.tickCount < p.persistentData.getInt('velaria_combate')
}
VG.velariaEmCombate = vcbEmCombate

function vcbAoBater(event) {
  let alvo = event.entity
  let atacante = event.source.player
  if (!alvo || !atacante || !alvo.isPlayer() || atacante === alvo) return
  vcbMarcar(alvo)
  vcbMarcar(atacante)
}

// O nome do evento mudou entre versões do KubeJS: tenta os dois.
try { EntityEvents.afterHurt(vcbAoBater) } catch (e) {
  try { EntityEvents.hurt(vcbAoBater) } catch (e2) { console.warn('[Velária] Combate: evento de dano não encontrado') }
}

PlayerEvents.tick(event => {
  let p = event.player
  if (p.server.tickCount % 20 !== 0 || !p.persistentData.contains('velaria_combate')) return
  let falta = Math.ceil((p.persistentData.getInt('velaria_combate') - p.server.tickCount) / 20)
  if (falta > 0) p.displayClientMessage(Text.red(`⚔ Em combate: ${falta}s`), true)
  else {
    p.persistentData.remove('velaria_combate')
    p.displayClientMessage(Text.green('Fora de combate'), true)
  }
})

PlayerEvents.loggedOut(event => {
  let p = event.player
  if (p.hasPermissions(2) || !vcbEmCombate(p)) return
  p.persistentData.remove('velaria_combate')
  p.server.tell(Text.red(`${p.username} fugiu do combate e pagou com a vida.`))
  p.kill()
})

PlayerEvents.loggedIn(event => {
  event.player.persistentData.remove('velaria_combate')
})
