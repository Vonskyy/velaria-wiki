// ============================================================
//  Velária MMORPG — TIER DO JOGADOR, LIMITE DE DISTÂNCIA E ESTRUTURAS BLOQUEADAS
//  Pasta: kubejs/server_scripts/  (recarrega com /reload)
//  Escrito para KubeJS 1.21.1 (NeoForge) — ainda NÃO testado em jogo.
//
//  Como o jogador sobe de tier (1 a 5) — CADA UM POR SI, sem progresso de time:
//    a) estar PRESENTE (até 48 blocos) na morte de um chefe do tier atual (lista CHEFES abaixo), ou
//    b) participar de abates de Elites do tier atual (velaria_elites.js), sozinho ou em grupo.
//  Só sobe um tier por vez. O FTB Quests fica para a história, sem dar tier.
//  Manual (admin): /velaria tier <jogador> <n>
//  O bloqueio de dimensão (Nether T3, End T5) também é feito aqui (VELARIA.dimensoes).
// ============================================================

const VELARIA = {
  // Centro do mapa: coordenadas de Porto Alvorada (mude para as do seu spawn).
  centro: { x: 0, z: 0 },
  // Raio máximo, em blocos, que cada tier pode andar no Overworld. 0 = sem limite.
  raioPorTier: { 1: 1500, 2: 3000, 3: 5000, 4: 8000, 5: 0 },
  // A partir de quantos blocos antes da fronteira aparece o aviso.
  aviso: 64,
  // Tags de estrutura (pasta data/velaria/tags/worldgen/structure/). Quem tem tier menor é expulso.
  tagsEstrutura: { 2: 'velaria:tier_2', 3: 'velaria:tier_3', 4: 'velaria:tier_4', 5: 'velaria:tier_5' },
  // Tier mínimo por dimensão (quem entra antes volta para o Overworld)
  dimensoes: { 'minecraft:the_nether': 3, 'minecraft:the_end': 5 },
  // Admins (op nível 2), criativo e espectador ignoram tudo.
  ignorarAdmins: true,
  // Checa uma vez por segundo.
  intervalo: 20
}

function velariaTier(player) {
  for (let t = 5; t >= 2; t--) {
    if (player.stages.has(`velaria_tier_${t}`)) return t
  }
  return 1
}
VG.velariaTier = velariaTier

// Jogadores vivos a até "raio" blocos de uma entidade (mesma dimensão)
VG.velariaPerto = function (e, raio) {
  let out = []
  e.level.players.forEach(p => { if (!p.isSpectator() && p.distanceTo(e) <= raio) out.push(p) })
  return out
}

const VELARIA_TITULOS = { 2: 'Entranhas de Velária', 3: 'A Fornalha', 4: 'Os Arautos da Queda', 5: 'A Estrela Partida' }

// Sobe o jogador para o tier "novo" (só se ele estiver exatamente no tier anterior).
VG.velariaSubirTier = function (p, novo) {
  if (novo < 2 || novo > 5 || velariaTier(p) !== novo - 1) return false
  let nome = p.username
  let server = p.server
  p.stages.add(`velaria_tier_${novo}`)
  server.runCommandSilent(`advancement grant ${nome} only velaria:tier/${novo}`)
  server.runCommandSilent(`title ${nome} times 10 100 30`)
  server.runCommandSilent(`title ${nome} subtitle {"text":"${VELARIA_TITULOS[novo]}","color":"gray"}`)
  server.runCommandSilent(`title ${nome} title {"text":"Tier ${novo}","color":"gold","bold":true}`)
  if (VG.velariaDarPontoCaminho) VG.velariaDarPontoCaminho(p, 1)
  server.tell(Text.gold(`${nome} alcançou o Tier ${novo}: ${VELARIA_TITULOS[novo]}.`))
  return true
}

// ---------- Chefes que abrem o próximo tier ----------
// Chave = ID da entidade, valor = tier em que ele é enfrentado (quem está nesse tier sobe +1).
// IDs de mods: confira no jogo com F3 mirando o chefe, ou com /summon <TAB>.
const VELARIA_CHEFES = {
  'mowziesmobs:ferrous_wroughtnaut': 2, 'mowziesmobs:frostmaw': 2, 'minecraft:elder_guardian': 2,
  'bosses_of_mass_destruction:lich': 3, 'bosses_of_mass_destruction:void_blossom': 3,
  'mowziesmobs:umvuthi': 3, 'mowziesmobs:sculptor': 3,
  'bosses_of_mass_destruction:gauntlet': 4, 'bosses_of_mass_destruction:obsidilith': 4,
  'minecraft:wither': 4, 'cataclysm:ignis': 4, 'cataclysm:netherite_monstrosity': 4, 'minecraft:warden': 4
}
VG.VELARIA_CHEFES = VELARIA_CHEFES

EntityEvents.death(event => {
  let e = event.entity
  let tierChefe = VELARIA_CHEFES[String(e.type)]
  if (!tierChefe) return
  VG.velariaPerto(e, 48).forEach(p => {
    if (velariaTier(p) === tierChefe) VG.velariaSubirTier(p, tierChefe + 1)
    if (VG.velariaContratoChefe) VG.velariaContratoChefe(p)
    if (VG.velariaHonra) VG.velariaHonra(p, 5, 'derrotou um chefe')
  })
})

ServerEvents.commandRegistry(event => {
  let { commands: Commands, arguments: Arguments } = event
  event.register(Commands.literal('velaria').requires(s => s.hasPermission(2))
    .then(Commands.literal('tier')
      .then(Commands.argument('alvo', Arguments.PLAYER.create(event))
        .then(Commands.argument('n', Arguments.INTEGER.create(event)).executes(ctx => {
          let alvo = Arguments.PLAYER.getResult(ctx, 'alvo')
          let n = Arguments.INTEGER.getResult(ctx, 'n')
          for (let t = 2; t <= 5; t++) {
            if (t <= n) { alvo.stages.add(`velaria_tier_${t}`); alvo.server.runCommandSilent(`advancement grant ${alvo.username} only velaria:tier/${t}`) }
            else alvo.stages.remove(`velaria_tier_${t}`)
          }
          return 1
        })))))
})

// ---------- Estruturas (via API do Minecraft) ----------
let velariaEstruturasAtivas = true
const VELARIA_TAGS = {}
var VPJ = null
try {
  VPJ = {
    TagKey: Java.loadClass('net.minecraft.tags.TagKey'),
    Registries: Java.loadClass('net.minecraft.core.registries.Registries'),
    RL: Java.loadClass('net.minecraft.resources.ResourceLocation')
  }
  Object.keys(VELARIA.tagsEstrutura).forEach(t => {
    VELARIA_TAGS[t] = VPJ.TagKey.create(VPJ.Registries.STRUCTURE, VPJ.RL.parse(VELARIA.tagsEstrutura[t]))
  })
} catch (e) {
  velariaEstruturasAtivas = false
  console.warn(`[Velária] Bloqueio de estruturas desligado: ${e}`)
}

function tierDaEstrutura(player) {
  if (!velariaEstruturasAtivas) return 0
  try {
    let sm = player.level.structureManager()
    let pos = player.blockPosition()
    for (let t = 5; t >= 2; t--) {
      if (sm['getStructureWithPieceAt(net.minecraft.core.BlockPos,net.minecraft.tags.TagKey)'](pos, VELARIA_TAGS[t]).isValid()) return t
    }
  } catch (e) {
    velariaEstruturasAtivas = false
    console.warn(`[Velária] Bloqueio de estruturas desligado após erro: ${e}`)
  }
  return 0
}

// ---------- Checagem por jogador ----------
PlayerEvents.tick(event => {
  let server = event.server
  if (server.tickCount % VELARIA.intervalo !== 0) return
  let p = event.player
  if (VELARIA.ignorarAdmins && (p.isCreative() || p.isSpectator() || p.hasPermissions(2))) return

  let tier = velariaTier(p)
  let dim = String(p.level.dimension)
  let dados = p.persistentData
  let bloqueio = null

  let tierEstrutura = tierDaEstrutura(p)
  if (tierEstrutura > tier) {
    bloqueio = `Esta masmorra é de Tier ${tierEstrutura}. Você ainda é Tier ${tier}.`
  }

  // Dimensões por tier (substitui o Restage, que passou a exigir o Create)
  let tierDim = VELARIA.dimensoes[dim]
  if (!bloqueio && tierDim && tier < tierDim) {
    bloqueio = `Esta dimensão exige Tier ${tierDim}. Você ainda é Tier ${tier}.`
  }

  if (!bloqueio && dim === 'minecraft:overworld') {
    let raio = VELARIA.raioPorTier[tier] || 0
    if (raio > 0) {
      let dx = p.x - VELARIA.centro.x
      let dz = p.z - VELARIA.centro.z
      let dist = Math.sqrt(dx * dx + dz * dz)
      if (dist > raio) {
        bloqueio = `As terras além de ${raio} blocos de Porto Alvorada exigem Tier ${tier + 1}.`
      } else if (dist > raio - VELARIA.aviso) {
        p.displayClientMessage(Text.yellow(`Fronteira do Tier ${tier}: faltam ${Math.floor(raio - dist)} blocos`), true)
      }
    }
  }

  let nome = p.gameProfile.name
  if (bloqueio) {
    // Volta para o último ponto liberado; sem ponto salvo, volta para perto do spawn.
    if (dados.contains('velaria_ok_x') && dados.getString('velaria_ok_dim') === dim) {
      let x = dados.getDouble('velaria_ok_x').toFixed(2)
      let y = dados.getDouble('velaria_ok_y').toFixed(2)
      let z = dados.getDouble('velaria_ok_z').toFixed(2)
      server.runCommandSilent(`execute in ${dim} run tp ${nome} ${x} ${y} ${z}`)
    } else {
      server.runCommandSilent(`execute in minecraft:overworld run spreadplayers ${VELARIA.centro.x} ${VELARIA.centro.z} 0 16 false ${nome}`)
    }
    let agora = server.tickCount
    if (agora - dados.getInt('velaria_ultimo_aviso') > 100) {
      p.tell(Text.red(bloqueio))
      dados.putInt('velaria_ultimo_aviso', agora)
    }
    return
  }

  // Ponto liberado: guarda como "último lugar seguro".
  dados.putDouble('velaria_ok_x', p.x)
  dados.putDouble('velaria_ok_y', p.y)
  dados.putDouble('velaria_ok_z', p.z)
  dados.putString('velaria_ok_dim', dim)
})

// No login, lembra o jogador do tier atual.
PlayerEvents.loggedIn(event => {
  let p = event.player
  p.tell(Text.gold(`Você é Tier ${velariaTier(p)} em Velária.`))
})
