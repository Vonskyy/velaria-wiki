// ============================================================
//  Velária MMORPG — O MAGO DO IRON'S SPELLS 'N SPELLBOOKS (1.1.19)
//  Pasta: kubejs/server_scripts/  (recarrega com /reload)   GERADO por tools/gen_mago.py
//
//  - Só quem jurou pelo Círculo Arcano conjura magias do Iron's (regras em startup_scripts/velaria_mago_eventos.js).
//  - O Mago não usa armas físicas: cajado (mão principal) e orbe (mão secundária) dão poder mágico.
//  - Caminho Elemental: escolhido na árvore "Caminhos" (tecla K) com o primeiro ponto. Escolha única:
//    Arcano (ender + evocação: o espadachim-mago, com lâminas conjuradas), Fogo, Gelo, Tempestade,
//    Luz, Trevas (sangue + eldritch) ou Natureza. Só as magias da sua escola funcionam.
//  - Círculos: Aprendiz, Adepto, Mago, Mestre, Arquimago (1 ponto por tier). Cada Círculo libera um
//    nível maior de magia (fração do nível máximo de cada feitiço) e +5% de poder da escola por Círculo.
//  - Ao escolher o Caminho, o Mago recebe 2 pergaminhos iniciais da escola.
//  - Segurando o foco (cajado do kit ou do Iron's), partículas da escola saem da mão.
// ============================================================

const VMG = global.VELARIA_MAGO

function vmgEscola(p) {
  let ks = Object.keys(VMG.escolas)
  for (let i = 0; i < ks.length; i++) if (p.stages.has(`velaria_escola_${ks[i]}`)) return ks[i]
  return null
}
function vmgCirculo(p) {
  for (let n = 5; n >= 2; n--) if (p.stages.has(`velaria_circulo_${n}`)) return n
  return 1
}
VG.velariaMagoEscola = vmgEscola
VG.velariaMagoCirculo = vmgCirculo
function vmgEhMago(p) { return VG.velariaOrdem && VG.velariaOrdem(p) === 'mago' }

// Poder da escola por Círculo (+5% por Círculo) e pergaminhos iniciais, conferidos a cada 2 s
PlayerEvents.tick(event => {
  let p = event.player
  if (p.server.tickCount % 40 !== 13) return
  let d = p.persistentData
  let k = vmgEhMago(p) ? vmgEscola(p) : null
  let c = k ? vmgCirculo(p) : 0
  let chave = k ? `${k}:${c}` : ''
  let velha = String(d.getString('velaria_mago_bonus') || '')
  if (chave !== velha) {
    if (velha) {
      let vk = velha.split(':')[0]
      if (VMG.escolas[vk]) VMG.escolas[vk].escolas.forEach(s =>
        p.server.runCommandSilent(`attribute ${p.username} irons_spellbooks:${s}_spell_power modifier remove velaria:circulo`))
    }
    if (k) {
      VMG.escolas[k].escolas.forEach(s =>
        p.server.runCommandSilent(`attribute ${p.username} irons_spellbooks:${s}_spell_power modifier add velaria:circulo ${0.05 * c} add_multiplied_base`))
      if (velha.split(':')[0] !== k) {
        p.server.runCommandSilent(`title ${p.username} times 10 80 20`)
        p.server.runCommandSilent(`title ${p.username} subtitle {"text":"Círculo do ${VMG.circulos[c - 1][0]}","color":"gray"}`)
        p.server.runCommandSilent(`title ${p.username} title {"text":"Caminho: ${VMG.escolas[k].nome}","color":"${VMG.escolas[k].cor}","bold":true}`)
      } else {
        p.tell(Text.lightPurple(`Círculo do ${VMG.circulos[c - 1][0]}: magias até ${Math.round(VMG.circulos[c - 1][1] * 100)}% do nível máximo.`))
      }
    }
    d.putString('velaria_mago_bonus', chave)
  }
  if (k && !d.getBoolean(`velaria_mago_iniciais_${k}`)) {
    d.putBoolean(`velaria_mago_iniciais_${k}`, true)
    VMG.escolas[k].iniciais.forEach(s =>
      p.server.runCommandSilent(`execute as ${p.username} run createScroll irons_spellbooks:${s} 1`))
    p.tell(Text.lightPurple(`O Círculo te entregou 2 pergaminhos de ${VMG.escolas[k].nome}. Inscreva no seu livro de magia na Mesa de Inscrição.`))
  }
})

// Aura do foco: segurando o cajado (do kit ou do Iron's), a escola solta partículas na ponta
PlayerEvents.tick(event => {
  let p = event.player
  if (p.server.tickCount % 10 !== 4) return
  let id = String(p.mainHandItem.id)
  if (!/^kubejs:.*_cajado$|^irons_spellbooks:.*(staff|cane|rod|helve)$/.test(id)) return
  let k = vmgEhMago(p) ? vmgEscola(p) : null
  if (!k) return
  let t = (p.yRot + 35) * Math.PI / 180
  let x = p.x - Math.sin(t) * 0.55, z = p.z + Math.cos(t) * 0.55, y = p.y + 1.45
  try { p.level.spawnParticles(VMG.escolas[k].particula, true, x, y, z, 0.08, 0.08, 0.08, 2, 0.01) } catch (e) { }
})

ServerEvents.commandRegistry(event => {
  let { commands: Commands } = event
  event.register(Commands.literal('caminho_mago').executes(ctx => {
    let p = ctx.source.player
    if (!vmgEhMago(p)) { p.tell(Text.gray('Só para o Círculo Arcano.')); return 0 }
    let k = vmgEscola(p)
    if (!k) { p.tell(Text.yellow('Sem Caminho Elemental ainda: abra a árvore "Caminhos" (tecla K).')); return 0 }
    let c = vmgCirculo(p)
    p.tell(Text.lightPurple(`Caminho: ${VMG.escolas[k].nome} · Círculo do ${VMG.circulos[c - 1][0]} (${c}/5)`))
    p.tell(Text.gray(`Magias até ${Math.round(VMG.circulos[c - 1][1] * 100)}% do nível máximo · +${5 * c}% de poder da escola`))
    return 1
  }))
})
