// ============================================================
//  Velária MMORPG — ELITES (chefes secundários): 10 por dimensão
//  Pasta: kubejs/server_scripts/  (recarrega com /reload)
//  Dados GERADOS por tools/build_mundo4.py. Ainda NÃO testado em jogo.
//
//  Quando um monstro nasce naturalmente, há uma chance pequena de nascer uma Elite junto:
//  nome na cabeça, vida e dano do TIER dela (não da distância), efeitos próprios.
//  - No Overworld, Elites de tier alto só aparecem longe do spawn (distanciaMinima).
//  - Cada Elite tem tempo de espera própria (esperaMin) para não lotar o mapa.
//  Ao morrer, todos os jogadores a até 32 blocos ganham: moedas, troféu, honra,
//  contrato de caça cumprido e um passo no tier (abatesParaSubir Elites do seu tier).
//  O material do tier cai no chão uma vez.
// ============================================================

const VE = {
 "chance": 0.004,
 "esperaMin": 15,
 "distanciaMinima": {
  "1": 0,
  "2": 800,
  "3": 2000,
  "4": 4000,
  "5": 0
 },
 "abatesParaSubir": {
  "1": 3,
  "2": 5,
  "3": 5,
  "4": 6
 },
 "tiers": {
  "1": {
   "vida": 60,
   "dano": 6,
   "armadura": 4,
   "cor": "yellow",
   "moeda": [
    "lightmanscurrency:coin_gold",
    2
   ]
  },
  "2": {
   "vida": 120,
   "dano": 9,
   "armadura": 8,
   "cor": "gold",
   "moeda": [
    "lightmanscurrency:coin_gold",
    5
   ]
  },
  "3": {
   "vida": 220,
   "dano": 13,
   "armadura": 12,
   "cor": "red",
   "moeda": [
    "lightmanscurrency:coin_emerald",
    2
   ]
  },
  "4": {
   "vida": 350,
   "dano": 17,
   "armadura": 16,
   "cor": "dark_purple",
   "moeda": [
    "lightmanscurrency:coin_emerald",
    5
   ]
  },
  "5": {
   "vida": 500,
   "dano": 22,
   "armadura": 20,
   "cor": "aqua",
   "moeda": [
    "lightmanscurrency:coin_diamond",
    2
   ]
  }
 },
 "materiais": {
  "1": [
   "kubejs:estanho_ingot",
   "kubejs:ambar",
   "kubejs:malaquita"
  ],
  "2": [
   "kubejs:mitril_ingot",
   "kubejs:oricalco_ingot",
   "kubejs:ferro_sombrio_ingot",
   "kubejs:cobalto_ingot",
   "kubejs:onix",
   "kubejs:glaciarita"
  ],
  "3": [
   "kubejs:adamantita_ingot",
   "kubejs:vulcanita",
   "kubejs:animita",
   "kubejs:sangrita",
   "kubejs:abissita_ingot",
   "kubejs:tempestita"
  ],
  "4": [
   "kubejs:umbrita_ingot",
   "kubejs:draconita_ingot"
  ],
  "5": [
   "kubejs:estelita_ingot",
   "kubejs:vacuita_ingot"
  ]
 },
 "elites": [
  {
   "id": "rei_carnical",
   "nome": "Rei Carniçal",
   "tipo": "minecraft:zombie",
   "dim": "minecraft:overworld",
   "tier": 1,
   "mult": 1.0,
   "arma": "minecraft:iron_sword",
   "efeitos": [
    [
     "minecraft:speed",
     0
    ]
   ],
   "extra": ""
  },
  {
   "id": "matriarca_teias",
   "nome": "Matriarca das Teias",
   "tipo": "minecraft:spider",
   "dim": "minecraft:overworld",
   "tier": 1,
   "mult": 1.0,
   "arma": null,
   "efeitos": [
    [
     "minecraft:speed",
     1
    ]
   ],
   "extra": ""
  },
  {
   "id": "arqueiro_velho",
   "nome": "Ossudo, o Arqueiro Velho",
   "tipo": "minecraft:skeleton",
   "dim": "minecraft:overworld",
   "tier": 1,
   "mult": 0.9,
   "arma": "minecraft:bow",
   "efeitos": [],
   "extra": ""
  },
  {
   "id": "bruxa_pantano",
   "nome": "Bruxa do Pântano Negro",
   "tipo": "minecraft:witch",
   "dim": "minecraft:overworld",
   "tier": 2,
   "mult": 1.0,
   "arma": null,
   "efeitos": [
    [
     "minecraft:resistance",
     0
    ]
   ],
   "extra": ""
  },
  {
   "id": "senhor_dunas",
   "nome": "Senhor das Dunas",
   "tipo": "minecraft:husk",
   "dim": "minecraft:overworld",
   "tier": 2,
   "mult": 1.1,
   "arma": "minecraft:golden_axe",
   "efeitos": [
    [
     "minecraft:strength",
     0
    ]
   ],
   "extra": ""
  },
  {
   "id": "afogado_coroado",
   "nome": "Afogado Coroado",
   "tipo": "minecraft:drowned",
   "dim": "minecraft:overworld",
   "tier": 2,
   "mult": 1.0,
   "arma": "minecraft:trident",
   "efeitos": [],
   "extra": ""
  },
  {
   "id": "capitao_vorn",
   "nome": "Capitão Saqueador Vorn",
   "tipo": "minecraft:pillager",
   "dim": "minecraft:overworld",
   "tier": 2,
   "mult": 1.0,
   "arma": "minecraft:crossbow",
   "efeitos": [
    [
     "minecraft:speed",
     0
    ]
   ],
   "extra": ""
  },
  {
   "id": "carrasco_mansao",
   "nome": "Carrasco da Mansão",
   "tipo": "minecraft:vindicator",
   "dim": "minecraft:overworld",
   "tier": 3,
   "mult": 1.0,
   "arma": "minecraft:diamond_axe",
   "efeitos": [],
   "extra": ""
  },
  {
   "id": "gelo_que_anda",
   "nome": "Gelo-que-Anda",
   "tipo": "minecraft:stray",
   "dim": "minecraft:overworld",
   "tier": 3,
   "mult": 1.0,
   "arma": "minecraft:bow",
   "efeitos": [
    [
     "minecraft:resistance",
     0
    ]
   ],
   "extra": ""
  },
  {
   "id": "devastador_anciao",
   "nome": "Devastador Ancião",
   "tipo": "minecraft:ravager",
   "dim": "minecraft:overworld",
   "tier": 4,
   "mult": 1.2,
   "arma": null,
   "efeitos": [],
   "extra": ""
  },
  {
   "id": "piglin_usurario",
   "nome": "Piglin Usurário",
   "tipo": "minecraft:piglin",
   "dim": "minecraft:the_nether",
   "tier": 3,
   "mult": 0.9,
   "arma": "minecraft:golden_sword",
   "efeitos": [
    [
     "minecraft:speed",
     0
    ]
   ],
   "extra": ""
  },
  {
   "id": "bruto_sanguinario",
   "nome": "Bruto Sanguinário",
   "tipo": "minecraft:piglin_brute",
   "dim": "minecraft:the_nether",
   "tier": 3,
   "mult": 1.1,
   "arma": "minecraft:golden_axe",
   "efeitos": [
    [
     "minecraft:strength",
     0
    ]
   ],
   "extra": ""
  },
  {
   "id": "matriarca_hoglin",
   "nome": "Matriarca Hoglin",
   "tipo": "minecraft:hoglin",
   "dim": "minecraft:the_nether",
   "tier": 3,
   "mult": 1.2,
   "arma": null,
   "efeitos": [],
   "extra": ""
  },
  {
   "id": "ghast_chorao",
   "nome": "Ghast Chorão",
   "tipo": "minecraft:ghast",
   "dim": "minecraft:the_nether",
   "tier": 3,
   "mult": 0.8,
   "arma": null,
   "efeitos": [],
   "extra": ""
  },
  {
   "id": "blaze_coroado",
   "nome": "Blaze Coroado",
   "tipo": "minecraft:blaze",
   "dim": "minecraft:the_nether",
   "tier": 3,
   "mult": 0.9,
   "arma": null,
   "efeitos": [
    [
     "minecraft:resistance",
     0
    ]
   ],
   "extra": ""
  },
  {
   "id": "magma_primordial",
   "nome": "Magma Primordial",
   "tipo": "minecraft:magma_cube",
   "dim": "minecraft:the_nether",
   "tier": 3,
   "mult": 1.0,
   "arma": null,
   "efeitos": [],
   "extra": "Size:4"
  },
  {
   "id": "arauto_almas",
   "nome": "Arauto do Vale das Almas",
   "tipo": "minecraft:skeleton",
   "dim": "minecraft:the_nether",
   "tier": 3,
   "mult": 1.0,
   "arma": "minecraft:bow",
   "efeitos": [
    [
     "minecraft:fire_resistance",
     0
    ]
   ],
   "extra": ""
  },
  {
   "id": "carrasco_murcho",
   "nome": "Carrasco Murcho",
   "tipo": "minecraft:wither_skeleton",
   "dim": "minecraft:the_nether",
   "tier": 4,
   "mult": 1.0,
   "arma": "minecraft:netherite_sword",
   "efeitos": [],
   "extra": ""
  },
  {
   "id": "zoglin_pestilento",
   "nome": "Zoglin Pestilento",
   "tipo": "minecraft:zoglin",
   "dim": "minecraft:the_nether",
   "tier": 4,
   "mult": 1.1,
   "arma": null,
   "efeitos": [
    [
     "minecraft:speed",
     0
    ]
   ],
   "extra": ""
  },
  {
   "id": "rei_zumbificado",
   "nome": "Rei Zumbificado",
   "tipo": "minecraft:zombified_piglin",
   "dim": "minecraft:the_nether",
   "tier": 4,
   "mult": 1.2,
   "arma": "minecraft:golden_sword",
   "efeitos": [
    [
     "minecraft:strength",
     0
    ]
   ],
   "extra": ""
  },
  {
   "id": "sentinela_vazio",
   "nome": "Sentinela do Vazio",
   "tipo": "minecraft:enderman",
   "dim": "minecraft:the_end",
   "tier": 5,
   "mult": 1.0,
   "arma": null,
   "efeitos": [],
   "extra": ""
  },
  {
   "id": "guardiao_purpur",
   "nome": "Guardião de Purpur",
   "tipo": "minecraft:shulker",
   "dim": "minecraft:the_end",
   "tier": 5,
   "mult": 0.6,
   "arma": null,
   "efeitos": [
    [
     "minecraft:resistance",
     1
    ]
   ],
   "extra": ""
  },
  {
   "id": "rainha_endermite",
   "nome": "Rainha Endermite",
   "tipo": "minecraft:endermite",
   "dim": "minecraft:the_end",
   "tier": 5,
   "mult": 0.6,
   "arma": null,
   "efeitos": [
    [
     "minecraft:speed",
     1
    ]
   ],
   "extra": ""
  },
  {
   "id": "fantasma_vazio",
   "nome": "Fantasma do Vazio",
   "tipo": "minecraft:phantom",
   "dim": "minecraft:the_end",
   "tier": 5,
   "mult": 0.8,
   "arma": null,
   "efeitos": [],
   "extra": "Size:5"
  },
  {
   "id": "arauto_estelar",
   "nome": "Arauto Estelar",
   "tipo": "minecraft:enderman",
   "dim": "minecraft:the_end",
   "tier": 5,
   "mult": 1.2,
   "arma": null,
   "efeitos": [
    [
     "minecraft:strength",
     1
    ]
   ],
   "extra": ""
  },
  {
   "id": "vigia_etereo",
   "nome": "Vigia Etéreo",
   "tipo": "minecraft:vex",
   "dim": "minecraft:the_end",
   "tier": 5,
   "mult": 0.6,
   "arma": "minecraft:diamond_sword",
   "efeitos": [],
   "extra": ""
  },
  {
   "id": "cavaleiro_sem_retorno",
   "nome": "Cavaleiro Sem Retorno",
   "tipo": "minecraft:wither_skeleton",
   "dim": "minecraft:the_end",
   "tier": 5,
   "mult": 1.1,
   "arma": "minecraft:netherite_sword",
   "efeitos": [
    [
     "minecraft:speed",
     0
    ]
   ],
   "extra": ""
  },
  {
   "id": "evocador_exilado",
   "nome": "Evocador Exilado",
   "tipo": "minecraft:evoker",
   "dim": "minecraft:the_end",
   "tier": 5,
   "mult": 0.9,
   "arma": null,
   "efeitos": [
    [
     "minecraft:resistance",
     0
    ]
   ],
   "extra": ""
  },
  {
   "id": "tempestade_errante",
   "nome": "Tempestade Errante",
   "tipo": "minecraft:breeze",
   "dim": "minecraft:the_end",
   "tier": 5,
   "mult": 0.9,
   "arma": null,
   "efeitos": [],
   "extra": ""
  },
  {
   "id": "executor_do_fim",
   "nome": "Executor do Fim",
   "tipo": "minecraft:vindicator",
   "dim": "minecraft:the_end",
   "tier": 5,
   "mult": 1.1,
   "arma": "minecraft:netherite_axe",
   "efeitos": [],
   "extra": ""
  }
 ]
}

function veCentro() { return { x: 0, z: 0 } }  // mesmo centro do velaria_progressao.js

function veNbt(el) {
  let t = VE.tiers[el.tier]
  let vida = Math.round(t.vida * el.mult)
  let nome = JSON.stringify({ text: el.nome, color: t.cor, bold: true })
  let attrs = [
    `{id:"minecraft:generic.max_health",base:${vida}.0d}`,
    `{id:"minecraft:generic.attack_damage",base:${t.dano}.0d}`,
    `{id:"minecraft:generic.armor",base:${t.armadura}.0d}`,
    `{id:"minecraft:generic.follow_range",base:48.0d}`,
    `{id:"minecraft:generic.knockback_resistance",base:0.6d}`
  ].join(',')
  let efeitos = el.efeitos.map(e => `{id:"${e[0]}",amplifier:${e[1]}b,duration:-1,show_particles:0b}`).join(',')
  let mao = el.arma ? `{id:"${el.arma}",count:1}` : '{}'
  let nbt = `{CustomName:'${nome}',CustomNameVisible:1b,PersistenceRequired:1b,` +
    `Tags:["velaria_elite","velaria_elite_${el.id}","velaria_visto"],Health:${vida}.0f,` +
    `attributes:[${attrs}],HandItems:[${mao},{}],HandDropChances:[0.0f,0.0f]`
  if (efeitos) nbt += `,active_effects:[${efeitos}]`
  if (el.extra) nbt += `,${el.extra}`
  return nbt + '}'
}

EntityEvents.spawned(event => {
  let e = event.entity
  if (!e || e.isPlayer() || !e.isLiving()) return
  let tags = e.tags
  if (tags.contains('velaria_visto') || tags.contains('velaria_elite')) return
  e.addTag('velaria_visto')
  let monstro = false
  try { monstro = e.isMonster() } catch (err) { return }
  if (!monstro || Math.random() > VE.chance) return

  let dim = String(e.level.dimension)
  let c = veCentro()
  let dist = Math.sqrt((e.x - c.x) * (e.x - c.x) + (e.z - c.z) * (e.z - c.z))
  let server = e.server
  let agora = server.tickCount
  let dados = server.persistentData
  let elegiveis = VE.elites.filter(el => el.dim === dim &&
    (dim !== 'minecraft:overworld' || dist >= VE.distanciaMinima[el.tier]) &&
    agora - dados.getInt(`velaria_elite_cd_${el.id}`) > VE.esperaMin * 1200)
  if (!elegiveis.length) return
  let el = elegiveis[Math.floor(Math.random() * elegiveis.length)]
  dados.putInt(`velaria_elite_cd_${el.id}`, agora)
  let x = Math.floor(e.x), y = Math.floor(e.y), z = Math.floor(e.z)
  server.scheduleInTicks(2, () => {
    server.runCommandSilent(`execute in ${dim} run summon ${el.tipo} ${x} ${y} ${z} ${veNbt(el)}`)
  })
})

EntityEvents.death(event => {
  let e = event.entity
  if (!e.tags.contains('velaria_elite')) return
  let el = null
  VE.elites.forEach(x => { if (e.tags.contains(`velaria_elite_${x.id}`)) el = x })
  if (!el) return
  let t = VE.tiers[el.tier]

  // Material do tier cai uma vez
  let mats = VE.materiais[el.tier]
  let mat = mats[Math.floor(Math.random() * mats.length)]
  e.block.popItem(Item.of(mat, 1 + Math.floor(Math.random() * 3)))

  VG.velariaPerto(e, 32).forEach(p => {
    let nome = p.username
    p.server.runCommandSilent(`give ${nome} ${t.moeda[0]} ${t.moeda[1]}`)
    p.server.runCommandSilent(`give ${nome} kubejs:trofeu_elite_t${el.tier} 1`)
    if (VG.velariaHonra) VG.velariaHonra(p, 2, `derrotou ${el.nome}`)
    if (VG.velariaContratoCaca) VG.velariaContratoCaca(p, el.tier)
    // Progresso de tier por Elites (cada um por si, precisa estar presente)
    if (VG.velariaTier && VG.velariaTier(p) === el.tier && el.tier < 5) {
      let d = p.persistentData
      let chave = `velaria_elites_t${el.tier}`
      let n = d.getInt(chave) + 1
      let meta = VE.abatesParaSubir[el.tier]
      if (n >= meta) { d.putInt(chave, 0); VG.velariaSubirTier(p, el.tier + 1) }
      else { d.putInt(chave, n); p.tell(Text.gray(`Elites do tier ${el.tier}: ${n}/${meta} para subir de tier.`)) }
    }
  })
})

// /velaria elite <id> : invoca uma Elite na sua posição (teste)
ServerEvents.commandRegistry(event => {
  let { commands: Commands, arguments: Arguments } = event
  event.register(Commands.literal('velaria').requires(s => s.hasPermission(2))
    .then(Commands.literal('elite')
      .then(Commands.argument('id', Arguments.STRING.create(event)).executes(ctx => {
        let p = ctx.source.player
        let id = String(Arguments.STRING.getResult(ctx, 'id'))
        let el = null
        VE.elites.forEach(x => { if (x.id === id) el = x })
        if (!el) { p.tell(VE.elites.map(x => x.id).join(', ')); return 0 }
        p.server.runCommandSilent(`execute in ${p.level.dimension} run summon ${el.tipo} ${Math.floor(p.x)} ${Math.floor(p.y)} ${Math.floor(p.z)} ${veNbt(el)}`)
        return 1
      }))))
})
