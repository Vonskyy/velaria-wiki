// ============================================================
//  Velária MMORPG — HONRA, PROCURADOS E CAÇADA DE JOGADORES
//  Pasta: kubejs/server_scripts/  (recarrega com /reload)
//  Ainda NÃO testado em jogo.
//
//  Honra vai de -100 a +100 e começa em 0.
//  Sobe: contratos, Elites, chefes, illagers e matar Procurados.
//  Desce: matar aldeões, golens, guardas, mercadores e jogadores inocentes.
//  Volta devagar para perto de 0 com o tempo online (+1 a cada 20 min, só se negativa).
//
//  Faixas (efeitos nas vilas ficam em velaria_vilas.js):
//    Herói (60+)       Herói da Vila permanente (descontos); 85+ nível II
//    Honrado (30 a 59) aldeões dão desconto aos poucos
//    Neutro (-9 a 29)
//    Suspeito (-29 a -10) aldeões cobram mais a cada conversa
//    Infame (-59 a -30)   aldeões se recusam a negociar
//    Procurado (-60 ou menos) golens e guardas atacam; vale recompensa para caçadores
//
//  Recompensa: quem mata um Procurado com a "Licença de Caçador" no inventário recebe
//  moedas de ouro (10 + 1 por ponto abaixo de -60). O Procurado volta para -40.
// ============================================================

const VH = {
  faixas: [
    { id: 'heroi', nome: 'Herói', min: 60, cor: 'gold' },
    { id: 'honrado', nome: 'Honrado', min: 30, cor: 'green' },
    { id: 'neutro', nome: 'Neutro', min: -9, cor: 'white' },
    { id: 'suspeito', nome: 'Suspeito', min: -29, cor: 'yellow' },
    { id: 'infame', nome: 'Infame', min: -59, cor: 'red' },
    { id: 'procurado', nome: 'Procurado', min: -100, cor: 'dark_red' }
  ],
  // Mudança de honra ao matar cada tipo de entidade
  mortes: {
    'minecraft:villager': -15, 'minecraft:wandering_trader': -10, 'minecraft:iron_golem': -10,
    'guardvillagers:guard': -10,
    'minecraft:pillager': 1, 'minecraft:vindicator': 1, 'minecraft:evoker': 2, 'minecraft:ravager': 2,
    'minecraft:illusioner': 2, 'minecraft:witch': 1
  },
  matarInocente: -12,     // jogador Neutro ou melhor
  matarSuspeito: -4,      // jogador Suspeito ou Infame
  matarProcurado: 8,
  guardas: ['minecraft:iron_golem', 'guardvillagers:guard'],
  raioGuardas: 24
}

function vhGet(p) { return p.persistentData.getInt('velaria_honra') }

function vhFaixa(h) {
  for (let i = 0; i < VH.faixas.length; i++) if (h >= VH.faixas[i].min) return VH.faixas[i]
  return VH.faixas[VH.faixas.length - 1]
}

VG.velariaFaixaHonra = function (p) { return vhFaixa(vhGet(p)).id }

VG.velariaHonra = function (p, delta, motivo) {
  let d = p.persistentData
  let antes = d.getInt('velaria_honra')
  let depois = Math.max(-100, Math.min(100, antes + delta))
  if (depois === antes) return
  d.putInt('velaria_honra', depois)
  let sinal = delta > 0 ? '+' : ''
  p.displayClientMessage(Text.of(`${sinal}${delta} de honra (${motivo}) → ${depois}`).color(delta > 0 ? 'green' : 'red'), true)
  let fa = vhFaixa(antes), fd = vhFaixa(depois)
  if (fa.id !== fd.id) {
    p.tell(Text.of(`Sua reputação agora é: ${fd.nome} (${depois}).`).color(fd.cor))
    if (fd.id === 'procurado') {
      p.server.tell(Text.darkRed(`${p.username} agora é PROCURADO. Caçadores com licença recebem recompensa. Veja /procurados`))
    }
  }
}

function vhRecompensa(h) { return 10 + Math.max(0, -h - 60) }

VG.velariaHonraInfo = function (p) {
  let h = vhGet(p)
  let f = vhFaixa(h)
  return { h: h, id: f.id, nome: f.nome, cor: f.cor, recompensa: vhRecompensa(h) }
}

// ---------- Registro dos Procurados (vale também para quem está offline; usado pelo mural) ----------
function vhLerRegistro(server) {
  try { return JSON.parse(String(server.persistentData.getString('velaria_procurados') || '{}')) } catch (e) { return {} }
}
function vhGravarRegistro(server, reg) { server.persistentData.putString('velaria_procurados', JSON.stringify(reg)) }

function vhAtualizarRegistro(p) {
  let reg = vhLerRegistro(p.server)
  let h = vhGet(p)
  let nome = String(p.username)
  if (vhFaixa(h).id === 'procurado') {
    reg[nome] = { h: h, recompensa: vhRecompensa(h), x: Math.round(p.x / 100) * 100, z: Math.round(p.z / 100) * 100,
      dim: String(p.level.dimension).replace('minecraft:', '') }
  } else if (reg[nome]) {
    delete reg[nome]
  } else return
  vhGravarRegistro(p.server, reg)
}

// Lista ordenada pela recompensa (maior primeiro)
VG.velariaProcurados = function (server) {
  let reg = vhLerRegistro(server)
  return Object.keys(reg).map(n => Object.assign({ nome: n }, reg[n])).sort((a, b) => b.recompensa - a.recompensa)
}

function vhTemLicenca(p) {
  for (let i = 0; i < p.inventory.getContainerSize(); i++) {
    if (p.inventory.getItem(i).id === 'kubejs:licenca_cacador') return true
  }
  return false
}

// ---------- Mortes ----------
EntityEvents.death(event => {
  let vitima = event.entity
  let assassino = event.source.player
  if (!assassino || assassino === vitima) return

  if (vitima.isPlayer()) {
    let hv = vhGet(vitima)
    let fv = vhFaixa(hv)
    if (fv.id === 'procurado') {
      VG.velariaHonra(assassino, VH.matarProcurado, `caçou ${vitima.username}`)
      if (vhTemLicenca(assassino)) {
        let valor = vhRecompensa(hv)
        assassino.server.runCommandSilent(`give ${assassino.username} lightmanscurrency:coin_gold ${valor}`)
        assassino.server.tell(Text.gold(`${assassino.username} cobrou a recompensa por ${vitima.username}: ${valor} moedas de ouro.`))
      } else {
        assassino.tell(Text.gray('Sem a Licença de Caçador, a recompensa não foi paga.'))
      }
      vitima.persistentData.putInt('velaria_honra', -40)
      vhAtualizarRegistro(vitima)
      vitima.tell(Text.yellow('Você foi caçado. Sua honra voltou para -40 (Infame).'))
    } else if (fv.id === 'neutro' || fv.id === 'honrado' || fv.id === 'heroi') {
      VG.velariaHonra(assassino, VH.matarInocente, `matou ${vitima.username}, inocente`)
    } else {
      VG.velariaHonra(assassino, VH.matarSuspeito, `matou ${vitima.username}`)
    }
    return
  }

  let delta = VH.mortes[String(vitima.type)]
  if (!delta) return
  if (delta > 0) {
    // Limite: no máximo +1 de honra por minuto vindo de illagers
    let d = assassino.persistentData
    let agora = assassino.server.tickCount
    if (agora - d.getInt('velaria_honra_illager') < 1200) return
    d.putInt('velaria_honra_illager', agora)
  }
  VG.velariaHonra(assassino, delta, delta > 0 ? 'protegeu as vilas' : 'atacou uma vila')
})

// ---------- A cada 5 s: Herói, guardas contra Procurados, honra voltando com o tempo ----------
PlayerEvents.tick(event => {
  let p = event.player
  if (p.server.tickCount % 100 !== 13) return
  let h = vhGet(p)
  let f = vhFaixa(h)
  let nome = p.username
  vhAtualizarRegistro(p)

  if (f.id === 'heroi') {
    p.server.runCommandSilent(`effect give ${nome} minecraft:hero_of_the_village 8 ${h >= 85 ? 1 : 0} true`)
  }

  if (f.id === 'procurado' && !p.isCreative()) {
    try {
      p.level.getEntitiesWithin(p.boundingBox.inflate(VH.raioGuardas)).forEach(e => {
        if (VH.guardas.indexOf(String(e.type)) >= 0) e.setTarget(p)
      })
    } catch (err) { /* sem guardas por perto ou API diferente */ }
  }

  if (h < 0) {
    let d = p.persistentData
    let t = d.getInt('velaria_honra_tempo') + 100
    if (t >= 24000) { d.putInt('velaria_honra_tempo', 0); VG.velariaHonra(p, 1, 'o tempo cura') }
    else d.putInt('velaria_honra_tempo', t)
  }
})

// ---------- Carta de Perdão ----------
ItemEvents.rightClicked('kubejs:carta_perdao', event => {
  let p = event.player
  if (vhGet(p) >= 0) { p.tell(Text.gray('Sua honra não precisa de perdão.')); return }
  VG.velariaHonra(p, 25, 'perdão comprado')
  if (!p.isCreative()) event.item.shrink(1)
})

// ---------- Comandos ----------
ServerEvents.commandRegistry(event => {
  let { commands: Commands, arguments: Arguments } = event

  event.register(Commands.literal('honra').executes(ctx => {
    let p = ctx.source.player
    let h = vhGet(p)
    let f = vhFaixa(h)
    p.tell(Text.of(`Honra: ${h} — ${f.nome}`).color(f.cor))
    return 1
  }))

  event.register(Commands.literal('procurados').executes(ctx => {
    let quem = ctx.source.player
    let n = 0
    quem.server.players.forEach(p => {
      let h = vhGet(p)
      if (vhFaixa(h).id !== 'procurado') return
      n++
      let x = Math.round(p.x / 100) * 100, z = Math.round(p.z / 100) * 100
      let dim = String(p.level.dimension).replace('minecraft:', '')
      quem.tell(Text.darkRed(`${p.username} — honra ${h} — recompensa ${vhRecompensa(h)} ouro — visto perto de ${x}, ${z} (${dim})`))
    })
    if (n === 0) quem.tell(Text.green('Nenhum Procurado online.'))
    return 1
  }))

  event.register(Commands.literal('velaria').requires(s => s.hasPermission(2))
    .then(Commands.literal('honra')
      .then(Commands.argument('alvo', Arguments.PLAYER.create(event))
        .then(Commands.argument('valor', Arguments.INTEGER.create(event)).executes(ctx => {
          let alvo = Arguments.PLAYER.getResult(ctx, 'alvo')
          alvo.persistentData.putInt('velaria_honra', Arguments.INTEGER.getResult(ctx, 'valor'))
          return 1
        })))))
})
