// ============================================================
//  Velária MMORPG — A ESTRELA PARTIDA: o Dragão do End na lore
//  Pasta: kubejs/server_scripts/  (recarrega com /reload)
//
//  - O dragão ganha nome (aparece na barra de chefe): a Primeira Filha da Estrela.
//  - Quem estiver perto na morte ganha honra e recompensa; o primeiro abate de cada
//    jogador dá um prêmio extra e é anunciado para o servidor.
//  - O visual vem do pacote de recursos (Ender Dragon Reborn + EMF/ETF) e a luta do
//    datapack True Ending; este script não depende de nenhum dos dois.
//  Ainda NÃO testado em jogo.
// ============================================================

const VD = {
  nome: 'Astraeth, a Primeira Filha da Estrela',
  // Quem está a até X blocos do dragão quando ele morre recebe a recompensa
  raio: 160,
  honra: 15,
  recompensa: [['kubejs:moeda_estelar', 1]],
  primeiroAbate: [['kubejs:tomo_destino', 1], ['minecraft:dragon_head', 1]],
  // Vida extra por jogador no End além do primeiro (0.25 = +25% cada). 0 = desligado.
  // Deixe 0 se usar o True Ending, que já aumenta a vida do dragão.
  vidaExtraPorJogador: 0
}

EntityEvents.spawned('minecraft:ender_dragon', event => {
  let e = event.entity
  try { e.setCustomName(Text.lightPurple(VD.nome)) } catch (err) { console.warn('[Velária] Dragão: nome não aplicado') }
  if (VD.vidaExtraPorJogador <= 0) return
  let server = event.server
  server.scheduleInTicks(20, () => {
    let n = 0
    e.level.players.forEach(p => { if (!p.isSpectator()) n++ })
    if (n <= 1) return
    let vida = Math.round(200 * (1 + VD.vidaExtraPorJogador * (n - 1)))
    server.runCommandSilent(`attribute ${e.uuid} minecraft:generic.max_health base set ${vida}`)
    try { e.setHealth(vida) } catch (err) { /* sem vida cheia: o dragão regenera com os cristais */ }
  })
})

EntityEvents.death('minecraft:ender_dragon', event => {
  let e = event.entity
  let server = event.server
  let perto = VG.velariaPerto ? VG.velariaPerto(e, VD.raio) : []
  perto.forEach(p => {
    let nome = p.username
    VD.recompensa.forEach(it => server.runCommandSilent(`give ${nome} ${it[0]} ${it[1]}`))
    if (VG.velariaHonra) VG.velariaHonra(p, VD.honra, 'derrubou a Primeira Filha da Estrela')
    if (VG.velariaContratoChefe) VG.velariaContratoChefe(p)
    let d = p.persistentData
    if (!d.getBoolean('velaria_dragao_abatido')) {
      d.putBoolean('velaria_dragao_abatido', true)
      VD.primeiroAbate.forEach(it => server.runCommandSilent(`give ${nome} ${it[0]} ${it[1]}`))
      server.tell(Text.lightPurple(`${nome} derrubou ${VD.nome} pela primeira vez. O coração da Estrela pulsa mais fraco.`))
    }
    server.runCommandSilent(`title ${nome} times 10 100 30`)
    server.runCommandSilent(`title ${nome} subtitle {"text":"O coração da Estrela silencia... por enquanto","color":"gray"}`)
    server.runCommandSilent(`title ${nome} title {"text":"A Estrela Partida","color":"light_purple","bold":true}`)
  })
})
