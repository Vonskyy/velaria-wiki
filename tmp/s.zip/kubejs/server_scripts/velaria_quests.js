// ============================================================
//  Velária MMORPG — PONTE ENTRE OS STAGES E O FTB QUESTS
//  Pasta: kubejs/server_scripts/
//
//  O FTB Quests não lê os stages do KubeJS sem mod extra. Então, a cada 5 s,
//  cada stage importante vira uma conquista escondida (velaria:q/...), e as
//  quests usam tarefas de conquista. As conquistas ficam em data/velaria/advancement/q.
//  Gerado junto com o livro (tools/quests.py).
// ============================================================

const VQ_ORDENS = ['guerreiro', 'paladino', 'sacerdote', 'mago', 'ladino', 'arqueiro', 'berserker',
  'bruxo', 'druida', 'monge', 'lamina_arcana']
const VQ_OFICIOS = ['minerador', 'lenhador', 'ferreiro', 'cozinheiro', 'mercador', 'fazendeiro',
  'herbalista', 'criador', 'pescador', 'pedreiro', 'explorador', 'domador', 'errante']

function vqDar(p, chave) {
  let d = p.persistentData
  let marca = `velaria_q_${chave}`
  if (d.getBoolean(marca)) return
  p.server.runCommandSilent(`advancement grant ${p.username} only velaria:q/${chave}`)
  d.putBoolean(marca, true)
}

function vqTirar(p, chave) {
  let d = p.persistentData
  let marca = `velaria_q_${chave}`
  if (!d.getBoolean(marca)) return
  p.server.runCommandSilent(`advancement revoke ${p.username} only velaria:q/${chave}`)
  d.putBoolean(marca, false)
}

function vqSincronizar(p) {
  let algumaOrdem = false
  VQ_ORDENS.forEach(o => {
    if (p.stages.has(`velaria_ordem_${o}`)) { vqDar(p, `ordem_${o}`); algumaOrdem = true }
    else vqTirar(p, `ordem_${o}`)
  })
  if (algumaOrdem) vqDar(p, 'ordem')
  VQ_OFICIOS.forEach(o => {
    if (p.stages.has(`velaria_oficio_${o}`)) vqDar(p, `oficio_${o}`)
  })
  if (p.persistentData.getString('velaria_graca')) vqDar(p, 'graca')
  if (p.persistentData.getBoolean('velaria_dragao_abatido')) vqDar(p, 'dragao')
}

PlayerEvents.loggedIn(event => {
  event.server.scheduleInTicks(60, () => vqSincronizar(event.player))
})

PlayerEvents.tick(event => {
  let p = event.player
  if (p.age % 100 !== 0) return
  vqSincronizar(p)
})
