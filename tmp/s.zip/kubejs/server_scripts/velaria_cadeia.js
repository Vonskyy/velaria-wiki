// ============================================================
//  Velária MMORPG — CADEIA DE PICARETAS
//  Cada minério só sai com a picareta do minério anterior (ou melhor).
//  GERADO por tools/build_v5.py
// ============================================================

const VELARIA_CADEIA = {"req": {"kubejs:estanho_ore": 2, "kubejs:ambar_ore": 4, "kubejs:malaquita_ore": 5, "kubejs:mitril_ore": 6, "kubejs:deepslate_mitril_ore": 6, "kubejs:oricalco_ore": 10, "kubejs:ferro_sombrio_ore": 9, "kubejs:cobalto_ore": 7, "kubejs:onix_ore": 11, "kubejs:glaciarita_ore": 8, "kubejs:adamantita_ore": 17, "kubejs:vulcanita_ore": 16, "kubejs:animita_ore": 14, "kubejs:sangrita_ore": 13, "kubejs:abissita_ore": 18, "kubejs:tempestita_ore": 19, "kubejs:umbrita_ore": 20, "kubejs:draconita_ore": 21, "kubejs:estelita_ore": 23, "kubejs:vacuita_ore": 24, "kubejs:viridita_ore": 22, "kubejs:eclipsita_ore": 25, "kubejs:ouro_rosa_ore": 16, "minecraft:coal_ore": 0, "minecraft:deepslate_coal_ore": 0, "minecraft:copper_ore": 1, "minecraft:deepslate_copper_ore": 1, "minecraft:iron_ore": 3, "minecraft:deepslate_iron_ore": 3, "minecraft:gold_ore": 4, "minecraft:deepslate_gold_ore": 4, "minecraft:redstone_ore": 4, "minecraft:deepslate_redstone_ore": 4, "minecraft:lapis_ore": 4, "minecraft:deepslate_lapis_ore": 4, "minecraft:emerald_ore": 6, "minecraft:deepslate_emerald_ore": 6, "minecraft:diamond_ore": 12, "minecraft:deepslate_diamond_ore": 12, "minecraft:nether_quartz_ore": 13, "minecraft:nether_gold_ore": 13, "minecraft:ancient_debris": 15, "#c:ores/tin": 2, "#c:ores/silver": 4, "#c:ores/ruby": 6, "#c:ores/sapphire": 6, "#c:ores/topaz": 6, "#c:ores/citrine": 6, "#c:ores/jade": 6, "#c:ores/tanzanite": 6, "#c:ores/peridot": 6, "#c:ores/amethyst": 6}, "nomeMinerio": {"kubejs:estanho_ore": "Estanho", "kubejs:ambar_ore": "Âmbar", "kubejs:malaquita_ore": "Malaquita", "kubejs:mitril_ore": "Mitril", "kubejs:deepslate_mitril_ore": "Mitril", "kubejs:oricalco_ore": "Oricalco", "kubejs:ferro_sombrio_ore": "Ferro Sombrio", "kubejs:cobalto_ore": "Cobalto", "kubejs:onix_ore": "Ônix", "kubejs:glaciarita_ore": "Glaciarita", "kubejs:adamantita_ore": "Adamantita", "kubejs:vulcanita_ore": "Vulcanita", "kubejs:animita_ore": "Animita", "kubejs:sangrita_ore": "Sangrita", "kubejs:abissita_ore": "Abissita", "kubejs:tempestita_ore": "Tempestita", "kubejs:umbrita_ore": "Umbrita", "kubejs:draconita_ore": "Draconita", "kubejs:estelita_ore": "Estelita", "kubejs:vacuita_ore": "Vacuíta", "kubejs:viridita_ore": "Viridita", "kubejs:eclipsita_ore": "Eclipsita", "kubejs:ouro_rosa_ore": "Ouro Rosa", "minecraft:coal_ore": "Carvão", "minecraft:deepslate_coal_ore": "Carvão", "minecraft:copper_ore": "Cobre", "minecraft:deepslate_copper_ore": "Cobre", "minecraft:iron_ore": "Ferro", "minecraft:deepslate_iron_ore": "Ferro", "minecraft:gold_ore": "Ouro", "minecraft:deepslate_gold_ore": "Ouro", "minecraft:redstone_ore": "Redstone", "minecraft:deepslate_redstone_ore": "Redstone", "minecraft:lapis_ore": "Lápis-lazúli", "minecraft:deepslate_lapis_ore": "Lápis-lazúli", "minecraft:emerald_ore": "Esmeralda", "minecraft:deepslate_emerald_ore": "Esmeralda", "minecraft:diamond_ore": "Diamante", "minecraft:deepslate_diamond_ore": "Diamante", "minecraft:nether_quartz_ore": "Minérios do Nether", "minecraft:nether_gold_ore": "Minérios do Nether", "minecraft:ancient_debris": "Detrito Ancestral", "#c:ores/tin": "Estanho de outros mods", "#c:ores/silver": "Prata", "#c:ores/ruby": "Gemas", "#c:ores/sapphire": "Gemas", "#c:ores/topaz": "Gemas", "#c:ores/citrine": "Gemas", "#c:ores/jade": "Gemas", "#c:ores/tanzanite": "Gemas", "#c:ores/peridot": "Gemas", "#c:ores/amethyst": "Gemas"}, "picaretas": [{"id": "madeira", "nome": "Madeira"}, {"id": "pedra", "nome": "Pedra"}, {"id": "cobre", "nome": "Cobre"}, {"id": "estanho", "nome": "Estanho"}, {"id": "ferro", "nome": "Ferro"}, {"id": "ambar", "nome": "Âmbar"}, {"id": "malaquita", "nome": "Malaquita"}, {"id": "mitril", "nome": "Mitril"}, {"id": "cobalto", "nome": "Cobalto"}, {"id": "glaciarita", "nome": "Glaciarita"}, {"id": "ferro_sombrio", "nome": "Ferro Sombrio"}, {"id": "oricalco", "nome": "Oricalco"}, {"id": "onix", "nome": "Ônix"}, {"id": "diamante", "nome": "Diamante"}, {"id": "sangrita", "nome": "Sangrita"}, {"id": "animita", "nome": "Animita"}, {"id": "netherite", "nome": "Netherite"}, {"id": "vulcanita", "nome": "Vulcanita"}, {"id": "adamantita", "nome": "Adamantita"}, {"id": "abissita", "nome": "Abissita"}, {"id": "tempestita", "nome": "Tempestita"}, {"id": "umbrita", "nome": "Umbrita"}, {"id": "draconita", "nome": "Draconita"}, {"id": "viridita", "nome": "Viridita"}, {"id": "estelita", "nome": "Estelita"}, {"id": "vacuita", "nome": "Vacuíta"}, {"id": "eclipsita", "nome": "Eclipsita"}]}

function velariaReqDoBloco(block) {
  let id = String(block.id)
  if (VELARIA_CADEIA.req[id] !== undefined) return [VELARIA_CADEIA.req[id], VELARIA_CADEIA.nomeMinerio[id]]
  for (let ref in VELARIA_CADEIA.req) {
    if (ref.startsWith('#') && block.hasTag(ref.substring(1))) return [VELARIA_CADEIA.req[ref], VELARIA_CADEIA.nomeMinerio[ref]]
  }
  return null
}

BlockEvents.broken(event => {
  let p = event.player
  if (!p || p.isCreative()) return
  if (!event.block.hasTag('velaria:minerio_controlado')) return
  let ferramenta = p.mainHandItem
  if (ferramenta.isCorrectToolForDrops(event.block.blockState)) return
  let req = velariaReqDoBloco(event.block)
  if (!req) return
  let picareta = VELARIA_CADEIA.picaretas[req[0]].nome
  p.displayClientMessage(Text.red(`${req[1]}: precisa de picareta de ${picareta} ou melhor.`), true)
  event.cancel()
})
