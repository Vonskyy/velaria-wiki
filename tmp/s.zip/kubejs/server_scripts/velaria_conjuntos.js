// ============================================================
//  Velária MMORPG — CONJUNTOS DE ARMADURA DE OUTROS MODS
//  (Samurai Dynasty, Epic Knights e addons, Immersive Armors, Fantasy Armor...)
//  Pasta: kubejs/server_scripts/  (recarrega com /reload)
//
//  Como funciona (a cada 2 s, só nas peças VESTIDAS):
//  - Cada conjunto temático só pode ser vestido pelas Ordens da lista. Carregar,
//    guardar e vender pode: a peça só sai do corpo e vai para a mochila.
//  - As 4 peças do mesmo conjunto dão um bônus de conjunto.
//  - Trava de tier: peça de netherite de qualquer mod só no tier 3, e assim por diante.
//  - Slots de aparência do Cosmetic Armor ficam de fora: lá vale qualquer visual.
//  Os IDs dos mods foram deduzidos pelos nomes. Confira no jogo (F3+H mostra o ID
//  na dica do item) e ajuste os padrões abaixo. Ainda NÃO testado em jogo.
// ============================================================

const VC = {
  // true = peça acima do tier do jogador sai do corpo
  travaDeTier: true,
  // Material no ID → tier mínimo. Itens do kit (kubejs:) e vanilla (minecraft:) ficam de fora:
  // o kit já é travado pela cadeia de picaretas e o vanilla é livre.
  tierPorMaterial: [
    { padrao: /dragonsteel|dragon_steel/, tier: 4 },
    { padrao: /netherite|mastercrafted|grandmaster|billporon/, tier: 3 },
    { padrao: /diamond|jade/, tier: 2 },
    // Armaduras dos mods de classe que equivalem a diamante (antes ficavam livres no tier 1)
    { padrao: /crusader|prior_robe|assassin|^rogues:berserker|ranger|(arcane|fire|frost)_robe|northling|warlord|enhanced_|superior_|phasleb|aken|lightbringer|absolution|onslaught|slayer|riftstalker|tempest|smouldering|rimeweave/, tier: 2 }
  ],
  // Mods de classe já seguem o Juramento (velaria_ordens.js); os conjuntos não mexem neles.
  ignorar: /^(kubejs|minecraft|wizards|elemental_wizards_rpg|paladins|rogues|archers|berserker_rpg|witcher_rpg|forcemaster_rpg|druids|spellblades?[a-z_]*|armory):/,
  // "padrao" é testado só no nome do item (depois do ":"), para o nome do mod não atrapalhar
  // (ex.: samurai_dynasty:ninja_helmet é Shinobi, não Samurai). "ids" é testado no ID inteiro.
  // Vale o PRIMEIRO conjunto que casar. O "cavaleiro" fica por último porque pega todo o
  // resto do Epic Knights.
  conjuntos: [
    { id: 'samurai', nome: 'Samurai', mods: 'Samurai Dynasty',
      padrao: /samurai|kabuto|yoroi|menpo|daimyo|ronin|shogun/,
      ordens: ['guerreiro', 'lamina_arcana', 'monge'],
      bonus: [['minecraft:generic.attack_speed', 0.1, 'add_multiplied_base']], texto: '+10% velocidade de ataque' },
    { id: 'shinobi', nome: 'Shinobi', mods: 'Samurai Dynasty',
      padrao: /ninja|shinobi|kunoichi/,
      ordens: ['ladino', 'monge'],
      bonus: [['minecraft:generic.movement_speed', 0.1, 'add_multiplied_base']], texto: '+10% velocidade' },
    { id: 'druzhina', nome: 'Druzhina', mods: 'Epic Knights: Slavic Armory',
      padrao: /slavic|shishak|kolchuga|bekhter|yushman|bakhter|druzhin|bogatyr|boyar|kalantar|misyurka/,
      ordens: ['berserker', 'bruxo'],
      bonus: [['minecraft:generic.attack_damage', 0.05, 'add_multiplied_base']], texto: '+5% de dano' },
    { id: 'nordico', nome: 'Nórdico', mods: 'Immersive Armors (Warrior), Epic Knights: Dark Ages',
      padrao: /viking|norse|nordic|vendel|spangenhelm|gjermundbu|valsgarde|jarl/, ids: /^immersive_armors:warrior_/,
      ordens: ['berserker', 'guerreiro'],
      bonus: [['minecraft:generic.max_health', 4, 'add_value']], texto: '+2 corações' },
    { id: 'legiao', nome: 'Legião Antiga', mods: 'Epic Knights: Antique Legacy',
      padrao: /corinthian|hoplite|spartan|lorica|galea|legion|centurion|chalcidian|linothorax|thracian|gladiator|myrmidon|phalanx/,
      ordens: ['guerreiro', 'paladino'],
      bonus: [['minecraft:generic.armor', 2, 'add_value']], texto: '+2 de armadura' },
    { id: 'sagrado', nome: 'Sagrado', mods: 'Immersive Armors (Divine), Fantasy Armor',
      padrao: /holy|seraph|angel|saint/, ids: /^immersive_armors:divine_/,
      ordens: ['sacerdote', 'paladino'],
      bonus: [['spell_power:healing', 2, 'add_value']], texto: '+2 de poder de cura' },
    { id: 'arcano', nome: 'Mantos Arcanos', mods: 'Immersive Armors (Robe), Fantasy Armor',
      padrao: /wizard|warlock|sorcer|archmage|(^|_)mage_|witch_hat|cultist|necromancer/, ids: /^immersive_armors:robe_/,
      ordens: ['mago', 'sacerdote', 'druida'],
      bonus: [['spell_power:arcane', 2, 'add_value']], texto: '+2 de poder arcano' },
    { id: 'sombras', nome: 'Sombras', mods: 'Fantasy Armor, outros',
      padrao: /assassin|thief|shadow|plague|stalker|bandit|executioner/,
      ordens: ['ladino', 'bruxo', 'arqueiro'],
      bonus: [['minecraft:generic.attack_speed', 0.05, 'add_multiplied_base'], ['minecraft:generic.movement_speed', 0.05, 'add_multiplied_base']],
      texto: '+5% velocidade e +5% velocidade de ataque' },
    { id: 'selvagem', nome: 'Selvagem', mods: 'Immersive Armors (Bone, Wooden), outros',
      padrao: /antler|ranger|hunter|druidic|thorn/, ids: /^immersive_armors:(bone|wooden)_/,
      ordens: ['druida', 'arqueiro', 'berserker'],
      bonus: [['minecraft:generic.max_health', 2, 'add_value'], ['minecraft:generic.knockback_resistance', 0.1, 'add_value']],
      texto: '+1 coração e +10% resistência a empurrão' },
    { id: 'cavaleiro', nome: 'Cavaleiro', mods: 'Epic Knights (+ Addon), Immersive Armors (Heavy), Fantasy Armor',
      padrao: /knight|armet|crusader|gothic|maximilian|bascinet|barbute|sallet|great_?helm|jousting|templar/,
      ids: /^magistuarmory:|^immersive_armors:heavy_/,
      ordens: ['paladino', 'guerreiro'],
      bonus: [['minecraft:generic.knockback_resistance', 0.2, 'add_value'], ['minecraft:generic.armor_toughness', 2, 'add_value']],
      texto: '+20% resistência a empurrão e +2 de dureza' }
  ]
}
VG.VELARIA_CONJUNTOS = VC

const VC_SLOTS = (() => {
  try {
    return (c => [c.HEAD, c.CHEST, c.LEGS, c.FEET])(Java.loadClass('net.minecraft.world.entity.EquipmentSlot'))
  } catch (e) {
    // Sem a classe: o KubeJS converte o nome do slot ('head', 'chest'...) sozinho
    console.info(`[Velária] Conjuntos: usando nomes de slot (${e})`)
    return ['head', 'chest', 'legs', 'feet']
  }
})()

const vcCache = {}
function vcConjunto(id) {
  if (vcCache[id] !== undefined) return vcCache[id]
  let achou = null
  if (!VC.ignorar.test(id)) {
    let nome = id.indexOf(':') >= 0 ? id.substring(id.indexOf(':') + 1) : id
    for (let i = 0; i < VC.conjuntos.length; i++) {
      let c = VC.conjuntos[i]
      if (c.padrao.test(nome) || (c.ids && c.ids.test(id))) { achou = c; break }
    }
  }
  vcCache[id] = achou
  return achou
}
VG.velariaConjuntoDe = vcConjunto

function vcTierMinimo(id) {
  if (/^(kubejs|minecraft):/.test(id)) return 1
  for (let i = 0; i < VC.tierPorMaterial.length; i++) {
    if (VC.tierPorMaterial[i].padrao.test(id)) return VC.tierPorMaterial[i].tier
  }
  return 1
}

function vcPorId(id) {
  for (let i = 0; i < VC.conjuntos.length; i++) if (VC.conjuntos[i].id === id) return VC.conjuntos[i]
  return null
}

function vcNomesOrdens(c) {
  let VO = VG.VELARIA_VO
  return c.ordens.map(o => (VO && VO.ordens[o]) ? VO.ordens[o].nome : o).join(', ')
}

// Conjuntos que a Ordem pode vestir (usado pelo Diário e pelo /conjuntos)
VG.velariaConjuntosDaOrdem = function (o) {
  return VC.conjuntos.filter(c => o && c.ordens.indexOf(o) >= 0)
}

// Tira a peça do corpo e põe na mochila (ou no chão, se a mochila estiver cheia)
function vcTirar(p, i, st) {
  let copia = st.copy()
  p.setItemSlot(VC_SLOTS[i], Item.empty)
  for (let k = 9; k < 36; k++) {
    if (p.inventory.getItem(k).isEmpty()) { p.inventory.setItem(k, copia); return }
  }
  p.drop(copia, false)
}

function vcLigar(p, c) {
  c.bonus.forEach(b => p.server.runCommandSilent(`attribute ${p.username} ${b[0]} modifier add velaria:conjunto ${b[1]} ${b[2]}`))
  p.persistentData.putString('velaria_conjunto', c.id)
  p.displayClientMessage(Text.gold(`Conjunto ${c.nome} completo: ${c.texto}`), true)
}

function vcDesligar(p, id) {
  let c = vcPorId(id)
  if (c) c.bonus.forEach(b => p.server.runCommandSilent(`attribute ${p.username} ${b[0]} modifier remove velaria:conjunto`))
  p.persistentData.putString('velaria_conjunto', '')
}

PlayerEvents.tick(event => {
  let p = event.player
  if (!VC_SLOTS || p.server.tickCount % 40 !== 23) return
  if (p.isCreative() || p.isSpectator() || p.stages.has('velaria_teste')) return
  let o = VG.velariaOrdem ? VG.velariaOrdem(p) : null
  let tier = VG.velariaTier ? VG.velariaTier(p) : 1
  let vestidos = []
  let aviso = null
  for (let i = 0; i < 4; i++) {
    let st = p.getItemBySlot(VC_SLOTS[i])
    if (!st || st.isEmpty()) { vestidos.push(null); continue }
    let id = String(st.id)
    let c = vcConjunto(id)
    if (c && (!o || c.ordens.indexOf(o) < 0)) {
      vcTirar(p, i, st)
      aviso = Text.red(`Armadura ${c.nome}: só para ${vcNomesOrdens(c)}. Use no slot de aparência.`)
      vestidos.push(null)
      continue
    }
    let minimo = VC.travaDeTier ? vcTierMinimo(id) : 1
    if (minimo > tier) {
      vcTirar(p, i, st)
      aviso = Text.red(`Essa peça exige tier ${minimo} (você está no tier ${tier}).`)
      vestidos.push(null)
      continue
    }
    vestidos.push(c ? c.id : null)
  }
  if (aviso) p.displayClientMessage(aviso, true)

  // Bônus: as 4 peças do mesmo conjunto
  let completo = (vestidos[0] && vestidos.every(v => v === vestidos[0])) ? vestidos[0] : ''
  let ativo = String(p.persistentData.getString('velaria_conjunto') || '')
  if (completo !== ativo) {
    if (ativo) vcDesligar(p, ativo)
    let c = vcPorId(completo)
    if (c) vcLigar(p, c)
  }
})

// Depois de reiniciar, o bônus é refeito na próxima checagem
PlayerEvents.loggedIn(event => {
  let ativo = String(event.player.persistentData.getString('velaria_conjunto') || '')
  if (ativo) vcDesligar(event.player, ativo)
})

ServerEvents.commandRegistry(event => {
  let { commands: Commands } = event
  event.register(Commands.literal('conjuntos').executes(ctx => {
    let p = ctx.source.player
    let o = VG.velariaOrdem ? VG.velariaOrdem(p) : null
    if (!o) { p.tell(Text.gray('Escolha uma Ordem para ver os conjuntos que pode vestir.')); return 0 }
    p.tell(Text.gold('Conjuntos que sua Ordem pode vestir:'))
    VG.velariaConjuntosDaOrdem(o).forEach(c => p.tell(Text.yellow(`• ${c.nome} (${c.mods}): 4 peças = ${c.texto}`)))
    p.tell(Text.gray('Os outros conjuntos podem ser usados no slot de aparência.'))
    return 1
  }))
})
