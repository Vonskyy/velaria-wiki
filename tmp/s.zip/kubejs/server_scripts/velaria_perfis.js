// ============================================================
//  Velária MMORPG — PERFIL DE ARMADURA (1.1.19: agora nos próprios itens)
//  Os bônus de perfil passaram para startup_scripts/velaria_atributos.js e aparecem na dica da peça.
//  Este script só remove os modificadores antigos (velaria:perfil) de quem jogou antes da mudança.
//  GERADO por tools/build_v5.py
// ============================================================

const VP_ATTRS_VELHOS = ["irons_spellbooks:cooldown_reduction", "irons_spellbooks:max_mana", "irons_spellbooks:spell_power", "irons_spellbooks:spell_resist", "minecraft:generic.attack_damage", "minecraft:generic.attack_speed", "minecraft:generic.knockback_resistance", "minecraft:generic.max_health", "minecraft:generic.movement_speed", "mrpg_lib:rage_modifier", "ranged_weapon:damage", "ranged_weapon:haste", "spell_engine:evasion_chance", "spell_power:arcane", "spell_power:critical_chance", "spell_power:fire", "spell_power:frost", "spell_power:haste", "spell_power:healing", "spell_power:nature", "witcher_rpg:adrenaline_modifier", "witcher_rpg:sign_intensity"]

PlayerEvents.loggedIn(event => {
  let p = event.player
  if (p.persistentData.getBoolean('velaria_perfil_limpo')) return
  VP_ATTRS_VELHOS.forEach(a => p.server.runCommandSilent(`attribute ${p.username} ${a} modifier remove velaria:perfil`))
  p.persistentData.putBoolean('velaria_perfil_limpo', true)
})
