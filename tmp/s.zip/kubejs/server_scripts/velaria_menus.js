// ============================================================
//  Velária MMORPG — MENUS (Diário do Desperto) e MURAL DE PROCURADOS
//  Pasta: kubejs/server_scripts/  (recarrega com /reload)
//  Ainda NÃO testado em jogo. Tudo do lado do servidor: o jogador não instala nada.
//
//  1) Diário do Desperto: clique com o botão direito no item (ou /menu). Abre um baú-menu com
//     Ordem, caminhos, Graça, honra e tier, e um botão para o mural.
//     Usa o menu de baú do KubeJS (openChestGUI). Se a versão não tiver, o menu sai no chat
//     com botões clicáveis.
//  2) Mural de Procurados: bloco para pôr em vilas e cidades. Clique abre a lista com a cara
//     de cada Procurado. Na frente do bloco aparecem cartazes "PROCURADO" com a cabeça do
//     jogador, o nome e a recompensa, como nos animes. Atualiza a cada 30 s.
//     Coloque o mural numa parede com espaço livre de 3 blocos de largura na frente.
// ============================================================

const VM = {
  linhagens: {
    linhagem_humano: 'Humano de Alvorada', linhagem_anao: 'Anão das Profundezas', linhagem_elfo: 'Elfo do Bosque Prateado',
    linhagem_draconato: 'Sangue de Wyrm', linhagem_tritao: 'Filho da Maré', linhagem_gigante: 'Gigante das Montanhas',
    linhagem_pequenino: 'Pequenino das Colinas', linhagem_vampiro: 'Filho da Noite', linhagem_orc: 'Orc das Cinzas',
    linhagem_feerico: 'Feérico', linhagem_forjado: 'Forjado', linhagem_salamandrino: 'Salamandrino', linhagem_drow: 'Elfo da Noite'
  },
  raios: { 1: 1500, 2: 3000, 3: 5000, 4: 8000, 5: 0 },
  elitesPara: { 1: 3, 2: 5, 3: 5, 4: 6 },
  cartazes: 3,                      // quantos cartazes o mural mostra
  corPapel: -1517392,               // ARGB do fundo do cartaz (0xFFE8D9B0)
  giroTexto: 0,                     // se o cartaz aparecer de costas, troque para 180
  giroCabeca: 180,                  // se a cabeça aparecer de costas, troque para 0
  atualizarCada: 600                // ticks (600 = 30 s)
}

// ---------- Itens de menu (componentes 1.21) ----------
// Texto JSON pronto para ir dentro de '...' em SNBT (escapa \\ e ')
function vmSnbt(json) { return json.replace(/\\/g, '\\\\').replace(/'/g, "\\'") }

function vmTexto(t, cor, extra) {
  let o = { text: t, color: cor || 'white', italic: false }
  if (extra) Object.assign(o, extra)
  return vmSnbt(JSON.stringify(o))
}

function vmItem(id, nome, cor, lore, extra) {
  let linhas = (lore || []).map(l => `'${vmTexto(l[0], l[1] || 'gray')}'`).join(',')
  let comp = `minecraft:custom_name='${vmTexto(nome, cor, { bold: true })}'`
  if (linhas) comp += `,minecraft:lore=[${linhas}]`
  if (extra) comp += `,${extra}`
  return Item.of(`${id}[${comp}]`)
}

function vmCabeca(nome, titulo, cor, lore) {
  return vmItem('minecraft:player_head', titulo, cor, lore, `minecraft:profile={name:"${nome}"}`)
}

const VM_OFICIOS = {
  minerador: 'Minerador', lenhador: 'Lenhador', ferreiro: 'Ferreiro', cozinheiro: 'Cozinheiro',
  mercador: 'Mercador', fazendeiro: 'Fazendeiro', herbalista: 'Herbalista', criador: 'Criador',
  pescador: 'Pescador', pedreiro: 'Pedreiro', explorador: 'Explorador', domador: 'Domador', errante: 'Sem Ofício'
}

function vmFechar(p) { try { p.closeMenu() } catch (e) { try { p.doCloseContainer() } catch (e2) { } } }
// ---------- Dados do jogador ----------
function vmInfo(p) {
  let VO = VG.VELARIA_VO
  let d = p.persistentData
  let o = VG.velariaOrdem ? VG.velariaOrdem(p) : null
  let tier = VG.velariaTier ? VG.velariaTier(p) : 1
  let honra = VG.velariaHonraInfo ? VG.velariaHonraInfo(p) : { h: 0, nome: 'Neutro', cor: 'white', id: 'neutro' }
  let g = VG.velariaGraca ? VG.velariaGraca(p) : null
  let of = String(d.getString('velaria_oficio') || '')
  return {
    oficio: of ? VM_OFICIOS[of] || of : 'escolhido junto da Linhagem',
    VO: VO, ordem: o, tier: tier, honra: honra,
    linhagem: VM.linhagens[String(d.getString('velaria_linhagem') || '')] || 'escolhida na tela do NeoOrigins',
    graca: g && VO && VO.caminhos[g] ? g : null,
    pontos: d.getInt('velaria_pontos'),
    elites: tier < 5 ? d.getInt(`velaria_elites_t${tier}`) : 0
  }
}

// ---------- Diário (menu principal) ----------
VG.velariaMenu = function (p) {
  let i = vmInfo(p)
  try {
    p.openChestGUI(Text.gold('Diário do Desperto'), 4, gui => {
      let VO = i.VO
      let ord = i.ordem && VO ? VO.ordens[i.ordem] : null

      gui.getSlot(1, 0).setItem(vmItem('minecraft:name_tag', 'Linhagem', 'yellow', [[i.linhagem, 'white'], [`Ofício: ${i.oficio}`, 'gray']]))

      gui.getSlot(3, 0).setItem(ord
        ? vmItem('minecraft:shield', ord.nome, 'gold', [[`Classe: ${ord.classe}`, 'white'],
          [`Armadura: ${VO.arquetipos[ord.arquetipo]}`, 'gray'], ['Itens de outras Ordens caem do inventário.', 'dark_gray']])
        : vmItem('minecraft:barrier', 'Sem Ordem', 'red', [['Escolha na tela do NeoOrigins.', 'gray']]))

      let g0 = VG.velariaGraca ? VG.velariaGraca(p) : null
      if (i.graca) {
        let c = VO.caminhos[i.graca]
        gui.getSlot(5, 0).setItem(vmItem('minecraft:nether_star', `Graça de ${c.deus}`, 'aqua', [
          [`Deus ${c.panteao}`, 'gray'], ['Bênção menor: sempre ativa', 'white'],
          [ord && ord.caminhos.indexOf(i.graca) >= 0 ? `Bênção maior com ${c.nome.toLowerCase()} na mão` : 'Sua Ordem não usa a arma deste deus', 'white'],
          [p.stages.has('velaria_devocao') ? 'Devoção: bônus dobrado' : 'Devoção ainda trancada', 'dark_aqua']]))
      } else {
        gui.getSlot(5, 0).setItem(vmItem('minecraft:glass_bottle', 'Sem Graça', 'gray', [[g0 === 'nenhuma' ? 'Você renunciou aos deuses.' : 'Escolha na tela de criação do personagem.', 'dark_gray']]))
      }

      let ih = { heroi: 'minecraft:golden_apple', honrado: 'minecraft:emerald', neutro: 'minecraft:paper',
        suspeito: 'minecraft:redstone', infame: 'minecraft:rotten_flesh', procurado: 'minecraft:wither_skeleton_skull' }
      gui.getSlot(7, 0).setItem(vmItem(ih[i.honra.id] || 'minecraft:paper', `Honra: ${i.honra.h}`, i.honra.cor, [
        [`Reputação: ${i.honra.nome}`, 'white'],
        [i.honra.id === 'procurado' ? `Sua cabeça vale ${i.honra.recompensa} moedas de ouro` : 'Contratos e Elites aumentam a honra', 'gray']]))

      // Caminhos
      if (ord) {
        ord.caminhos.forEach((c, k) => {
          let cm = VO.caminhos[c]
          let aberto = p.stages.has(`velaria_caminho_${c}`)
          let icone = cm.kjs.length ? `kubejs:cobre_${cm.kjs[0]}` : 'minecraft:blaze_rod'
          let slot = gui.getSlot(2 + k * 2, 1)
          slot.setItem(vmItem(aberto ? icone : 'minecraft:gray_dye', `Caminho: ${cm.nome}`, aberto ? 'green' : 'gray', [
            [aberto ? 'Destrancado' : 'Trancado', aberto ? 'green' : 'red'], [`Patrono: ${cm.deus}`, 'gray'],
            [aberto ? '' : (VG.VELARIA_COMANDO_CAMINHO ? `Clique para destrancar (${i.pontos} ponto(s))` : 'Destranque na árvore "Caminhos"'), 'yellow']]))
          if (!aberto && VG.VELARIA_COMANDO_CAMINHO) {
            slot.setLeftClicked(() => { vmFechar(p); p.server.runCommandSilent(`execute as ${p.username} run caminho ${c}`) })
          }
        })
      }

      // Tier
      let raio = VM.raios[i.tier]
      let lore = [[raio ? `Pode andar até ${raio} blocos do spawn` : 'Sem limite de distância', 'white']]
      if (i.tier < 5) lore.push([`Elites do tier ${i.tier}: ${i.elites}/${VM.elitesPara[i.tier]}`, 'gray'], ['Ou esteja presente na morte de um chefe do seu tier', 'gray'])
      gui.getSlot(4, 2).setItem(vmItem('minecraft:compass', `Tier ${i.tier}`, 'gold', lore))

      // Conjuntos de armadura (velaria_conjuntos.js)
      if (ord && VG.velariaConjuntosDaOrdem) {
        let lista = VG.velariaConjuntosDaOrdem(i.ordem)
        let ativo = String(p.persistentData.getString('velaria_conjunto') || '')
        let linhas = lista.map(c => [`${c.nome}: ${c.texto}`, c.id === ativo ? 'green' : 'white'])
        linhas.push(['4 peças do mesmo conjunto ativam o bônus', 'gray'], ['Outros conjuntos: só no slot de aparência', 'dark_gray'])
        gui.getSlot(6, 2).setItem(vmItem('minecraft:armor_stand', 'Conjuntos da Ordem', 'gold', linhas))
      }

      // Botões
      let mural = gui.getSlot(2, 3)
      mural.setItem(vmItem('minecraft:wither_skeleton_skull', 'Mural de Procurados', 'dark_red', [['Clique para ver', 'gray']]))
      mural.setLeftClicked(() => { vmFechar(p); p.server.scheduleInTicks(1, () => VG.velariaMuralGUI(p)) })
      let fechar = gui.getSlot(6, 3)
      fechar.setItem(vmItem('minecraft:barrier', 'Fechar', 'red', []))
      fechar.setLeftClicked(() => vmFechar(p))
    })
  } catch (err) {
    vmMenuChat(p, i)
  }
}

// Plano B: menu no chat com botões clicáveis
function vmMenuChat(p, i) {
  p.tell(Text.gold('— Diário do Desperto —'))
  p.tell(Text.yellow(`Linhagem: ${i.linhagem} · Ofício: ${i.oficio}`))
  if (i.ordem) p.tell(Text.yellow(`Ordem: ${i.VO.ordens[i.ordem].nome} (${i.VO.ordens[i.ordem].classe})`))
  if (i.graca) p.tell(Text.aqua(`Graça de ${i.VO.caminhos[i.graca].deus}: ${i.VO.caminhos[i.graca].nome}`))
  p.tell(Text.of(`Honra: ${i.honra.h} (${i.honra.nome}) · Tier ${i.tier}`).color(i.honra.cor))
  try {
    p.tell(Text.of('[Procurados]').darkRed().clickRunCommand('/procurados').append(Text.of('  '))
      .append(Text.of('[Graça]').aqua().clickRunCommand('/graca')).append(Text.of('  '))
      .append(Text.of('[Conjuntos]').gold().clickRunCommand('/conjuntos')))
  } catch (e) { p.tell(Text.gray('Comandos: /procurados, /graca, /honra, /conjuntos')) }
}

// ---------- Mural (lista) ----------
VG.velariaMuralGUI = function (p) {
  let lista = VG.velariaProcurados ? VG.velariaProcurados(p.server) : []
  try {
    p.openChestGUI(Text.darkRed('PROCURADOS'), 3, gui => {
      if (!lista.length) {
        gui.getSlot(4, 1).setItem(vmItem('minecraft:paper', 'Nenhum procurado', 'green', [['Velária está em paz... por enquanto.', 'gray']]))
        return
      }
      lista.slice(0, 27).forEach((q, k) => {
        gui.getSlot(k % 9, Math.floor(k / 9)).setItem(vmCabeca(q.nome, `PROCURADO: ${q.nome}`, 'dark_red', [
          ['Vivo ou morto', 'dark_gray'], [`Recompensa: ${q.recompensa} moedas de ouro`, 'gold'],
          [`Honra: ${q.h}`, 'red'], [`Visto perto de ${q.x}, ${q.z} (${q.dim})`, 'gray'],
          ['Precisa da Licença de Caçador para cobrar', 'dark_gray']]))
      })
    })
  } catch (err) {
    p.server.runCommandSilent(`execute as ${p.username} run procurados`)
  }
}

// ---------- O diário não se perde: volta ao renascer e a quem não tiver ----------
function vmGarantirDiario(p) {
  if (!p.inventory.hasAnyMatching(st => String(st.id) === 'kubejs:diario_desperto')) p.give('kubejs:diario_desperto')
}
PlayerEvents.respawned(event => vmGarantirDiario(event.player))
PlayerEvents.loggedIn(event => { if (event.player.stages.has('velaria_intro')) vmGarantirDiario(event.player) })

// ---------- Abrir pelos itens, pelo bloco e por comando ----------
ItemEvents.rightClicked('kubejs:diario_desperto', event => VG.velariaMenu(event.player))

BlockEvents.rightClicked('kubejs:mural_procurados', event => {
  if (String(event.hand) !== 'MAIN_HAND') return
  VG.velariaMuralGUI(event.player)
})

ServerEvents.commandRegistry(event => {
  let { commands: Commands } = event
  event.register(Commands.literal('menu').executes(ctx => { VG.velariaMenu(ctx.source.player); return 1 }))
  event.register(Commands.literal('diario').executes(ctx => { VG.velariaMenu(ctx.source.player); return 1 }))
  event.register(Commands.literal('mural').executes(ctx => { VG.velariaMuralGUI(ctx.source.player); return 1 }))
})

// ---------- Cartazes na frente do mural ----------
function vmLerMurais(server) {
  try { return JSON.parse(String(server.persistentData.getString('velaria_murais') || '[]')) } catch (e) { return [] }
}
function vmGravarMurais(server, lista) { server.persistentData.putString('velaria_murais', JSON.stringify(lista)) }
function vmTag(m) { return `velaria_mural_${m.dim.replace(/[^a-z0-9]/g, '')}_${m.x}_${m.y}_${m.z}`.replace(/-/g, 'm') }

const VM_DIR = { north: [0, -1, 180], south: [0, 1, 0], west: [-1, 0, 90], east: [1, 0, -90] }

BlockEvents.placed('kubejs:mural_procurados', event => {
  let b = event.block
  let facing = 'north'
  try { facing = String(b.properties.get('facing') || 'north') } catch (e) { /* bloco sem direção */ }
  let lista = vmLerMurais(event.server)
  lista.push({ dim: String(event.level.dimension), x: b.x, y: b.y, z: b.z, facing: facing })
  vmGravarMurais(event.server, lista)
  event.server.scheduleInTicks(5, () => vmDesenhar(event.server, lista[lista.length - 1], true))
})

BlockEvents.broken('kubejs:mural_procurados', event => {
  let b = event.block
  let dim = String(event.level.dimension)
  let lista = vmLerMurais(event.server)
  let fica = lista.filter(m => !(m.dim === dim && m.x === b.x && m.y === b.y && m.z === b.z))
  lista.filter(m => fica.indexOf(m) < 0).forEach(m => vmApagar(event.server, m))
  vmGravarMurais(event.server, fica)
})

function vmApagar(server, m) {
  server.runCommandSilent(`execute in ${m.dim} positioned ${m.x} ${m.y} ${m.z} if loaded ~ ~ ~ run kill @e[tag=${vmTag(m)},distance=..6]`)
}

function vmCartaz(q) {
  if (!q) return JSON.stringify([{ text: 'NENHUM PROCURADO\n', color: 'dark_green', bold: true },
    { text: 'Velária está em paz...\npor enquanto.', color: 'dark_gray' }])
  return JSON.stringify([
    { text: 'PROCURADO\n', color: 'dark_red', bold: true },
    { text: `${q.nome}\n`, color: 'black', bold: true },
    { text: 'VIVO OU MORTO\n', color: 'dark_gray' },
    { text: `${q.recompensa} moedas de ouro\n`, color: 'gold', bold: true },
    { text: `Visto perto de ${q.x}, ${q.z}`, color: 'dark_gray' }
  ])
}

function vmDesenhar(server, m, forcar) {
  let dir = VM_DIR[m.facing] || VM_DIR.north
  let tag = vmTag(m)
  let lista = VG.velariaProcurados ? VG.velariaProcurados(server).slice(0, VM.cartazes) : []
  let assinatura = JSON.stringify(lista.map(q => [q.nome, q.recompensa, q.x, q.z]))
  if (!forcar && m.assinatura === assinatura) return
  m.assinatura = assinatura
  let base = `execute in ${m.dim} positioned ${m.x} ${m.y} ${m.z} if loaded ~ ~ ~ if block ~ ~ ~ kubejs:mural_procurados run`
  server.runCommandSilent(`${base} kill @e[tag=${tag},distance=..6]`)
  let n = Math.max(1, lista.length)
  let lado = [-dir[1], dir[0]]                    // vetor lateral (perpendicular à frente)
  for (let k = 0; k < n; k++) {
    let q = lista[k]
    let off = (k - (n - 1) / 2) * 1.05
    let cx = m.x + 0.5 + dir[0] * 0.53 + lado[0] * off
    let cz = m.z + 0.5 + dir[1] * 0.53 + lado[1] * off
    let yaw = dir[2] + VM.giroTexto
    let texto = vmSnbt(vmCartaz(q))
    server.runCommandSilent(`${base} summon minecraft:text_display ${cx.toFixed(3)} ${(m.y + 0.05).toFixed(3)} ${cz.toFixed(3)} ` +
      `{Tags:["${tag}"],Rotation:[${yaw}f,0f],billboard:"fixed",background:${VM.corPapel},line_width:110,` +
      `transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]},` +
      `text:'${texto}'}`)
    if (q) {
      server.runCommandSilent(`${base} summon minecraft:item_display ${cx.toFixed(3)} ${(m.y + 0.78).toFixed(3)} ${cz.toFixed(3)} ` +
        `{Tags:["${tag}"],Rotation:[${yaw + VM.giroCabeca}f,0f],billboard:"fixed",item_display:"fixed",` +
        `transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]},` +
        `item:{id:"minecraft:player_head",count:1,components:{"minecraft:profile":{name:"${q.nome}"}}}}`)
    }
  }
}

// Atualiza os cartazes quando a lista muda (e de 5 em 5 min mesmo sem mudança, para chunks recarregados)
ServerEvents.tick(event => {
  let server = event.server
  if (server.tickCount % VM.atualizarCada !== 0) return
  let forcar = server.tickCount % (VM.atualizarCada * 10) === 0
  let lista = vmLerMurais(server)
  if (!lista.length) return
  lista.forEach(m => vmDesenhar(server, m, forcar))
  vmGravarMurais(server, lista)
})

// ---------- Receitas ----------
ServerEvents.recipes(event => {
  event.shaped('kubejs:mural_procurados', ['PPP', 'PWP', 'PPP'], { P: 'minecraft:paper', W: '#minecraft:planks' })
  event.shapeless('kubejs:diario_desperto', ['minecraft:book', 'minecraft:compass'])
})
