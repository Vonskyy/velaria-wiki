// priority: 1000
// Velária — objeto compartilhado entre os scripts de servidor.
// O KubeJS 2101.7 não deixa scripts de servidor escreverem em 'global'; todos usam VG.
var VG = VG || {}
