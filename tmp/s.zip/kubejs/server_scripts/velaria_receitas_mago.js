// ============================================================
//  Velária MMORPG — RECEITAS DO MAGO (Iron's Spells 'n Spellbooks) — 1.1.19
//  Pasta: kubejs/server_scripts/  (recarrega com /reload)
//  - Livros de magia em escada: cada livro usa o material do Mago daquele tier e o livro anterior.
//    T1 Diário Frágil (Âmbar Rúnico) → T2 Tomo de Ferro (Cobalto Rúnico) → T3 Livro do Aprendiz (Adamantita)
//    → T4 Livro Encantado (Umbra Arcana) → T5 Códice Ancestral (Vacuíta)
//  - O Mitril do Iron's vira o Mitril de Velária (o minério do Iron's não nasce mais).
//  - Cajados, varinhas e mantos do Wizards saem do jogo (o Mago agora é do Iron's).
// ============================================================

ServerEvents.recipes(event => {
  const LIVROS = [
    ['irons_spellbooks:copper_spell_book', 'kubejs:ambar_runico_ingot', 'minecraft:book'],
    ['irons_spellbooks:iron_spell_book', 'kubejs:cobalto_runico_ingot', 'irons_spellbooks:copper_spell_book'],
    ['irons_spellbooks:gold_spell_book', 'kubejs:adamantita_ingot', 'irons_spellbooks:iron_spell_book'],
    ['irons_spellbooks:diamond_spell_book', 'kubejs:umbra_arcana_ingot', 'irons_spellbooks:gold_spell_book'],
    ['irons_spellbooks:netherite_spell_book', 'kubejs:vacuita_ingot', 'irons_spellbooks:diamond_spell_book']
  ]
  LIVROS.forEach((l, i) => {
    event.remove({ output: l[0] })
    let chaves = { M: l[1], P: i < 3 ? 'minecraft:paper' : 'irons_spellbooks:magic_cloth', B: l[2] }
    event.shaped(l[0], ['MPM', 'PBP', 'MPM'], chaves).id(`velaria:mago/livro_t${i + 1}`)
  })

  // Mitril do Iron's = Mitril de Velária
  try {
    event.replaceInput({ mod: 'irons_spellbooks' }, 'irons_spellbooks:mithril_ingot', 'kubejs:mitril_ingot')
    event.replaceInput({ mod: 'irons_spellbooks' }, 'irons_spellbooks:mithril_scrap', 'kubejs:mitril_ingot')
    event.replaceInput({ mod: 'irons_spellbooks' }, '#c:ingots/mithril', 'kubejs:mitril_ingot')
  } catch (e) { console.warn(`[Velária] Mago: troca do mitril falhou (${e})`) }
  event.shapeless('irons_spellbooks:mithril_ingot', ['kubejs:mitril_ingot']).id('velaria:mago/mitril_iron')

  // Wizards fora: o Mago é do Iron's
  event.remove({ output: /^wizards:.*(staff|wand|robe)/ })
})
