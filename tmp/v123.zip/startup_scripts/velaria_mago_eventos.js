// ============================================================
//  Velária — O MAGO DO IRON'S SPELLS: REGRAS DE LANÇAR (1.1.19)  GERADO por tools/gen_mago.py
//  Pasta: kubejs/startup_scripts/  (precisa REINICIAR)
//  - Só quem jurou pelo Círculo Arcano conjura magias do Iron's (livro, pergaminho ou cajado).
//  - Só as magias da escola do Caminho Elemental escolhido funcionam (e só elas são inscritas).
//  - O Círculo (1 a 5) limita o nível da magia a uma fração do nível máximo de cada feitiço.
//  O resto (bônus por Círculo, pergaminhos, aura do cajado, /caminho_mago) está em server_scripts/velaria_mago.js
// ============================================================

global.VELARIA_MAGO = { escolas: {"arcano": {"nome": "Arcano", "escolas": ["ender", "evocation"], "cor": "#b04ae0", "particula": "minecraft:portal", "iniciais": ["magic_missile", "teleport"]}, "fogo": {"nome": "Fogo", "escolas": ["fire"], "cor": "#ff6a1a", "particula": "minecraft:flame", "iniciais": ["firebolt", "burning_dash"]}, "gelo": {"nome": "Gelo", "escolas": ["ice"], "cor": "#7fd8ff", "particula": "minecraft:snowflake", "iniciais": ["icicle", "frost_step"]}, "tempestade": {"nome": "Tempestade", "escolas": ["lightning"], "cor": "#ffe85a", "particula": "minecraft:electric_spark", "iniciais": ["electrocute", "charge"]}, "luz": {"nome": "Luz", "escolas": ["holy"], "cor": "#fff2b0", "particula": "minecraft:end_rod", "iniciais": ["heal", "wisp"]}, "trevas": {"nome": "Trevas", "escolas": ["blood", "eldritch"], "cor": "#8a1030", "particula": "minecraft:soul", "iniciais": ["blood_slash", "blood_needles"]}, "natureza": {"nome": "Natureza", "escolas": ["nature"], "cor": "#5ac83a", "particula": "minecraft:spore_blossom_air", "iniciais": ["poison_arrow", "root"]}}, circulos: [["Aprendiz", 0.25], ["Adepto", 0.45], ["Mago", 0.65], ["Mestre", 0.85], ["Arquimago", 1.0]] }

;(function () {
  let M = global.VELARIA_MAGO
  let escola = p => {
    let ks = Object.keys(M.escolas)
    for (let i = 0; i < ks.length; i++) if (p.stages.has(`velaria_escola_${ks[i]}`)) return ks[i]
    return null
  }
  let circulo = p => {
    for (let n = 5; n >= 2; n--) if (p.stages.has(`velaria_circulo_${n}`)) return n
    return 1
  }
  let ehMago = p => p.stages.has('velaria_ordem_mago')
  let livre = p => p.isSpectator()  // criativo NÃO libera: cada mago só usa a própria escola, até em teste
  let aviso = (p, txt) => { try { p.displayClientMessage(Text.red(txt), true) } catch (e) { } }
  let escolaDe = st => { try { return String(st.getId().getPath()) } catch (e) { return '' } }

  let antesDeLancar = e => {
    let p = e.getEntity()
    if (!p || !p.isPlayer() || livre(p)) return
    if (!ehMago(p)) {
      e.setCanceled(true)
      aviso(p, 'Só quem jurou pelo Círculo Arcano conjura magias do grimório.')
      return
    }
    let k = escola(p)
    if (!k) {
      e.setCanceled(true)
      aviso(p, 'Escolha seu Caminho Elemental na árvore "Caminhos" (tecla K).')
      return
    }
    if (M.escolas[k].escolas.indexOf(escolaDe(e.getSchoolType())) < 0) {
      e.setCanceled(true)
      aviso(p, `Essa magia é de outra escola. Seu caminho: ${M.escolas[k].nome}.`)
    }
  }
  let nivel = e => {
    let p = e.getEntity()
    if (!p || !p.isPlayer() || livre(p) || !ehMago(p)) return
    let c = circulo(p)
    let teto = Math.max(1, Math.ceil(e.getSpell().getMaxLevel() * M.circulos[c - 1][1]))
    if (e.getLevel() > teto) e.setLevel(teto)
  }
  let inscrever = e => {
    let p = e.getEntity()
    if (!p || !p.isPlayer() || livre(p)) return
    let k = ehMago(p) ? escola(p) : null
    let esc = ''
    try { esc = escolaDe(e.getSpellData().getSpell().getSchoolType()) } catch (x) { }
    if (!k || M.escolas[k].escolas.indexOf(esc) < 0) {
      e.setCanceled(true)
      aviso(p, k ? `Você só inscreve magias de ${M.escolas[k].nome}.` : 'Só o Mago com Caminho escolhido inscreve magias.')
    }
  }
  let liga = (classe, fn) => {
    try {
      NativeEvents.onEvent(Java.loadClass(classe), e => {
        try { fn(e) } catch (x) { console.warn(`[Velária] Mago (${classe}): ${x}`) }
      })
    } catch (e) {
      console.warn(`[Velária] Mago: evento ${classe} indisponível (${e})`)
    }
  }
  liga('io.redspace.ironsspellbooks.api.events.SpellPreCastEvent', antesDeLancar)
  liga('io.redspace.ironsspellbooks.api.events.ModifySpellLevelEvent', nivel)
  liga('io.redspace.ironsspellbooks.api.events.InscribeSpellEvent', inscrever)
  console.info('[Velária] Mago: eventos do Iron\'s Spells ligados')
})()
